import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";

interface ThemeToggleProps {
  className?: string;
}

export function ThemeToggle({ className }: ThemeToggleProps) {
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === "dark";

  return (
    <div className={cn("flex items-center", className)}>
      <div
        className={cn(
          "relative flex h-9 w-[4.5rem] cursor-pointer items-center rounded-full p-1 transition-colors duration-300",
          isDark ? "bg-muted" : "bg-muted"
        )}
        onClick={() => setTheme(isDark ? "light" : "dark")}
        role="button"
        tabIndex={0}
      >
        {/* Sliding indicator */}
        <div
          className={cn(
            "absolute h-7 w-7 rounded-full shadow-sm transition-all duration-300 ease-in-out",
            isDark
              ? "right-1 bg-primary"
              : "left-1 bg-background"
          )}
        />

        {/* Icons */}
        <div className="relative z-10 flex w-full justify-between">
          <div className="flex h-7 w-7 items-center justify-center">
            <Sun
              className={cn(
                "h-4 w-4 transition-colors duration-300",
                isDark ? "text-muted-foreground/60" : "text-muted-foreground"
              )}
            />
          </div>
          <div className="flex h-7 w-7 items-center justify-center">
            <Moon
              className={cn(
                "h-4 w-4 transition-colors duration-300",
                isDark ? "text-primary-foreground" : "text-muted-foreground/60"
              )}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
