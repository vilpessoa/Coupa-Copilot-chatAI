import { useState } from "react";
import { Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
  user: {
    full_name: string;
    avatar_url?: string | null;
    role?: string;
  };
  size?: "sm" | "md" | "lg";
  showBadge?: boolean;
  className?: string;
}

const SIZES = {
  sm: { container: "h-8 w-8", text: "text-xs", badge: "h-3.5 w-3.5", badgeIcon: "h-2 w-2", badgeBorder: "border" },
  md: { container: "h-12 w-12", text: "text-sm", badge: "h-4.5 w-4.5", badgeIcon: "h-2.5 w-2.5", badgeBorder: "border-[1.5px]" },
  lg: { container: "h-20 w-20", text: "text-xl", badge: "h-6 w-6", badgeIcon: "h-3 w-3", badgeBorder: "border-2" },
};

// Deterministic color from name
const PALETTE = [
  "bg-blue-500", "bg-emerald-500", "bg-amber-500", "bg-rose-500",
  "bg-violet-500", "bg-cyan-500", "bg-pink-500", "bg-teal-500",
  "bg-indigo-500", "bg-orange-500",
];

function hashName(name: string): number {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = ((hash << 5) - hash + name.charCodeAt(i)) | 0;
  }
  return Math.abs(hash);
}

function getInitials(name: string): string {
  if (!name?.trim()) return "U";
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function UserAvatar({ user, size = "sm", showBadge = true, className }: UserAvatarProps) {
  const [imgError, setImgError] = useState(false);
  const s = SIZES[size];
  const initials = getInitials(user.full_name);
  const colorClass = PALETTE[hashName(user.full_name) % PALETTE.length];
  const hasImage = user.avatar_url && !imgError;
  const isAdmin = user.role === "admin";

  return (
    <div className={cn("relative inline-flex shrink-0", className)}>
      <div className={cn("rounded-full flex items-center justify-center overflow-hidden", s.container, !hasImage && colorClass)}>
        {hasImage ? (
          <img
            src={user.avatar_url!}
            alt={user.full_name}
            className="h-full w-full object-cover"
            onError={() => setImgError(true)}
          />
        ) : (
          <span className={cn("font-semibold text-white select-none", s.text)}>
            {initials}
          </span>
        )}
      </div>
      {showBadge && isAdmin && (
        <div
          className={cn(
            "absolute -bottom-0.5 -right-0.5 rounded-full bg-[#0062AA] flex items-center justify-center",
            s.badgeBorder,
            "border-background",
            size === "sm" ? "h-3.5 w-3.5" : size === "md" ? "h-[18px] w-[18px]" : "h-6 w-6"
          )}
        >
          <Shield className={cn("text-white", s.badgeIcon)} />
        </div>
      )}
    </div>
  );
}
