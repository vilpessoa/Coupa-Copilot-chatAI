import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Marquee } from "@/components/ui/marquee";

const conversations = [
  { name: "Carla Mendes", initials: "CM", dept: "Compras", body: "Qual o status da minha requisição #4521?" },
  { name: "Rafael Costa", initials: "RC", dept: "Financeiro", body: "Quantas aprovações pendentes eu tenho?" },
  { name: "Juliana Rocha", initials: "JR", dept: "Supply Chain", body: "Quem aprovou a PO do fornecedor ABC?" },
  { name: "Pedro Almeida", initials: "PA", dept: "TI", body: "Qual o prazo de entrega do pedido #7832?" },
  { name: "Fernanda Lima", initials: "FL", dept: "Jurídico", body: "Me mostre os contratos que vencem este mês" },
  { name: "Lucas Oliveira", initials: "LO", dept: "Financeiro", body: "Qual o total gasto com fornecedor XYZ no Q1?" },
  { name: "Mariana Silva", initials: "MS", dept: "Compras", body: "Como faço para criar uma nova requisição?" },
  { name: "Thiago Santos", initials: "TS", dept: "Compliance", body: "Quais são as políticas de compra vigentes?" },
  { name: "Ana Beatriz", initials: "AB", dept: "Financeiro", body: "Tem alguma fatura pendente de aprovação?" },
];

const col1 = conversations.slice(0, 3);
const col2 = conversations.slice(3, 6);
const col3 = conversations.slice(6, 9);
const col4 = [...conversations.slice(0, 2), conversations[8]];

function ChatCard({ name, initials, dept, body }: (typeof conversations)[number]) {
  return (
    <div className="w-full p-4 border border-foreground/[0.08] rounded-xl bg-foreground/[0.03]">
      <div className="flex items-center gap-3 mb-3">
        <Avatar className="h-8 w-8">
          <AvatarFallback className="text-[11px] bg-blue-500/20 text-blue-400 font-medium">
            {initials}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="text-sm font-medium text-foreground/90 truncate">{name}</p>
          <p className="text-xs text-foreground/50">{dept}</p>
        </div>
      </div>
      <p className="text-sm text-foreground/60 leading-relaxed">{body}</p>
    </div>
  );
}

export function DisplayCards() {
  return (
    <div
      className="relative flex w-full flex-col items-center justify-center py-8"
      style={{
        maskImage:
          "radial-gradient(ellipse 70% 50% at 50% 50%, black 30%, transparent 100%)",
        WebkitMaskImage:
          "radial-gradient(ellipse 70% 50% at 50% 50%, black 30%, transparent 100%)",
      }}
    >
      <div
        className="flex h-[600px] w-[1100px] flex-row gap-4"
        style={{
          transform: "rotate(4deg) skewY(-6deg) skewX(-4deg) scale(0.85)",
        }}
      >
        <Marquee vertical pauseOnHover repeat={4} className="flex-1 [--duration:25s] !p-0 !border-0">
          {col1.map((c) => <ChatCard key={c.name} {...c} />)}
        </Marquee>
        <Marquee vertical pauseOnHover reverse repeat={4} className="flex-1 [--duration:28s] !p-0 !border-0">
          {col2.map((c) => <ChatCard key={c.name} {...c} />)}
        </Marquee>
        <Marquee vertical pauseOnHover repeat={4} className="flex-1 [--duration:22s] !p-0 !border-0">
          {col3.map((c) => <ChatCard key={c.name} {...c} />)}
        </Marquee>
        <Marquee vertical pauseOnHover reverse repeat={4} className="flex-1 [--duration:26s] !p-0 !border-0">
          {col4.map((c) => <ChatCard key={c.name} {...c} />)}
        </Marquee>
      </div>
    </div>
  );
}
