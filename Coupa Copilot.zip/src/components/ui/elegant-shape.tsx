import { motion, useReducedMotion } from "framer-motion";

interface ElegantShapeProps {
  className?: string;
  delay?: number;
  width?: number;
  height?: number;
  rotate?: number;
  gradient?: string;
}

export function ElegantShape({
  className = "",
  delay = 0,
  width = 400,
  height = 100,
  rotate = 0,
  gradient = "from-blue-500/[0.15]",
}: ElegantShapeProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className={`absolute ${className}`}>
      <motion.div
        initial={
          prefersReducedMotion
            ? { opacity: 1 }
            : { opacity: 0, y: -150, rotate: rotate - 15 }
        }
        animate={
          prefersReducedMotion
            ? { opacity: 1 }
            : { opacity: 1, y: 0, rotate }
        }
        transition={{
          duration: 2.4,
          delay,
          ease: [0.23, 0.86, 0.39, 0.96],
          opacity: { duration: 1.2 },
        }}
        style={{ willChange: "transform" }}
      >
        <motion.div
          animate={
            prefersReducedMotion
              ? {}
              : { y: [0, 15, 0] }
          }
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{ width, height }}
          className="relative"
        >
          <div
            className={`absolute inset-0 rounded-full bg-gradient-to-r ${gradient} to-transparent backdrop-blur-[2px] border-2 border-white/[0.15] shadow-[0_8px_32px_0_rgba(255,255,255,0.1)] after:content-[''] after:absolute after:inset-0 after:rounded-full after:bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.2),transparent_70%)]`}
          />
        </motion.div>
      </motion.div>
    </div>
  );
}
