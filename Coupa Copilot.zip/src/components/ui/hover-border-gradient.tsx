'use client'

import React, { useState, useRef, useCallback } from 'react'
import { cn } from '@/lib/utils'

export function HoverBorderGradient({
  children,
  containerClassName,
  className,
  as: Element = 'button',
  ...props
}: React.PropsWithChildren<
  {
    as?: React.ElementType
    containerClassName?: string
    className?: string
  } & React.HTMLAttributes<HTMLElement>
>) {
  const [hovered, setHovered] = useState(false)
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 })
  const containerRef = useRef<HTMLElement>(null)

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!containerRef.current) return
    const rect = containerRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setMousePos({ x, y })
  }, [])

  const glowBg = hovered
    ? `radial-gradient(circle at ${mousePos.x}% ${mousePos.y}%, hsl(0,0%,100%) 0%, rgba(255,255,255,0.4) 40%, transparent 70%)`
    : 'transparent'

  return (
    <Element
      ref={containerRef}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onMouseMove={handleMouseMove}
      className={cn(
        'relative flex h-min w-fit flex-col flex-nowrap content-center items-center justify-center gap-10 overflow-visible rounded-full border border-foreground/[0.08] bg-background/40 box-decoration-clone p-px backdrop-blur-sm transition duration-500 hover:bg-background/60',
        containerClassName
      )}
      {...props}
    >
      <div
        className={cn(
          'z-10 w-auto rounded-[inherit] bg-background px-4 py-2 text-foreground',
          className
        )}
      >
        {children}
      </div>
      <div
        className="absolute inset-0 z-0 flex-none overflow-hidden rounded-[inherit]"
        style={{
          background: glowBg,
          filter: 'blur(2px)',
          transition: 'background 150ms ease',
        }}
      />
      <div className='absolute inset-0.5 z-[1] flex-none rounded-[100px] bg-background' />
    </Element>
  )
}
