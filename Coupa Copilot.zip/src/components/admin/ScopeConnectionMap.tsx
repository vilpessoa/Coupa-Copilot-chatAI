import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, GitBranch, ArrowRight } from "lucide-react";

interface ApiScope {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
}

interface ScopeConnection {
  id: string;
  source_scope_id: string;
  target_scope_id: string;
  relationship: string;
  description: string;
}

// ─── SVG Diagram ───
function ConnectionDiagram({ scopes, connections }: { scopes: ApiScope[]; connections: ScopeConnection[] }) {
  const scopeMap = useMemo(() => new Map(scopes.map(s => [s.id, s])), [scopes]);

  // Build adjacency to determine layout
  const { nodes, positions } = useMemo(() => {
    const connectedIds = new Set<string>();
    connections.forEach(c => { connectedIds.add(c.source_scope_id); connectedIds.add(c.target_scope_id); });

    const connected = scopes.filter(s => connectedIds.has(s.id));
    const unconnected = scopes.filter(s => !connectedIds.has(s.id));
    const allNodes = [...connected, ...unconnected];

    const NODE_W = 180;
    const NODE_H = 54;
    const GAP_X = 60;
    const GAP_Y = 70;
    const COLS = Math.min(4, Math.max(2, Math.ceil(Math.sqrt(allNodes.length))));

    const pos = new Map<string, { x: number; y: number }>();
    allNodes.forEach((s, i) => {
      const col = i % COLS;
      const row = Math.floor(i / COLS);
      pos.set(s.id, { x: 40 + col * (NODE_W + GAP_X), y: 40 + row * (NODE_H + GAP_Y) });
    });

    return { nodes: allNodes, positions: pos };
  }, [scopes, connections]);

  const NODE_W = 180;
  const NODE_H = 54;
  const rows = Math.ceil(nodes.length / Math.min(4, Math.max(2, Math.ceil(Math.sqrt(nodes.length)))));
  const cols = Math.min(4, Math.max(2, Math.ceil(Math.sqrt(nodes.length))));
  const svgW = 40 + cols * (NODE_W + 60);
  const svgH = 40 + rows * (NODE_H + 70) + 20;

  if (nodes.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground text-sm">
        Nenhum escopo cadastrado.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-border bg-muted/20 p-2">
      <svg width={svgW} height={svgH} className="min-w-full">
        <defs>
          <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" className="fill-primary" />
          </marker>
        </defs>

        {/* Arrows */}
        {connections.map(conn => {
          const from = positions.get(conn.source_scope_id);
          const to = positions.get(conn.target_scope_id);
          if (!from || !to) return null;

          const x1 = from.x + NODE_W;
          const y1 = from.y + NODE_H / 2;
          const x2 = to.x;
          const y2 = to.y + NODE_H / 2;

          // If target is to the left, connect from bottom/top
          let fx = x1, fy = y1, tx = x2, ty = y2;
          if (to.x <= from.x) {
            fx = from.x + NODE_W / 2;
            fy = from.y + NODE_H;
            tx = to.x + NODE_W / 2;
            ty = to.y;
          }

          const mx = (fx + tx) / 2;
          const my = (fy + ty) / 2;

          return (
            <g key={conn.id}>
              <line x1={fx} y1={fy} x2={tx} y2={ty} className="stroke-primary" strokeWidth="1.5" markerEnd="url(#arrowhead)" strokeDasharray={conn.relationship === 'relacionado' ? '4 2' : undefined} />
              <rect x={mx - conn.relationship.length * 3.2} y={my - 9} width={conn.relationship.length * 6.4 + 8} height={18} rx="4" className="fill-background stroke-border" strokeWidth="0.5" />
              <text x={mx} y={my + 4} textAnchor="middle" className="fill-muted-foreground text-[10px]" style={{ fontSize: '10px' }}>
                {conn.relationship}
              </text>
            </g>
          );
        })}

        {/* Nodes */}
        {nodes.map(scope => {
          const pos = positions.get(scope.id);
          if (!pos) return null;
          return (
            <g key={scope.id}>
              <rect
                x={pos.x} y={pos.y} width={NODE_W} height={NODE_H} rx="8"
                className={`stroke-border ${scope.is_active ? 'fill-card' : 'fill-muted/50'}`}
                strokeWidth="1.5"
              />
              <text x={pos.x + NODE_W / 2} y={pos.y + 20} textAnchor="middle" className="fill-foreground font-medium" style={{ fontSize: '11px' }}>
                {(scope.description || scope.name).length > 24 ? (scope.description || scope.name).slice(0, 22) + '…' : (scope.description || scope.name)}
              </text>
              <text x={pos.x + NODE_W / 2} y={pos.y + 34} textAnchor="middle" className="fill-muted-foreground" style={{ fontSize: '8px', fontFamily: 'monospace' }}>
                {scope.name.length > 26 ? scope.name.slice(0, 24) + '…' : scope.name}
              </text>
              <text x={pos.x + NODE_W / 2} y={pos.y + 46} textAnchor="middle" className="fill-muted-foreground" style={{ fontSize: '8px' }}>
                {scope.is_active ? '● ativo' : '○ inativo'}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ─── Main Component ───
export default function ScopeConnectionMap({ scopes }: { scopes: ApiScope[] }) {
  const [connections, setConnections] = useState<ScopeConnection[]>([]);
  const [loading, setLoading] = useState(true);

  // Form state
  const [sourceId, setSourceId] = useState("");
  const [targetId, setTargetId] = useState("");
  const [relationship, setRelationship] = useState("gera");
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    fetchConnections();
  }, []);

  const fetchConnections = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("scope_connections")
      .select("*")
      .order("created_at", { ascending: true });
    if (!error && data) setConnections(data);
    setLoading(false);
  };

  const addConnection = async () => {
    if (!sourceId || !targetId || sourceId === targetId) {
      toast.error("Selecione dois escopos diferentes.");
      return;
    }
    setAdding(true);
    const { error } = await supabase.from("scope_connections").insert({
      source_scope_id: sourceId,
      target_scope_id: targetId,
      relationship: relationship.trim() || "relacionado",
    });
    if (error) {
      toast.error(error.message.includes("unique") ? "Conexão já existe." : error.message);
    } else {
      toast.success("Conexão criada!");
      setSourceId("");
      setTargetId("");
      setRelationship("gera");
      await fetchConnections();
    }
    setAdding(false);
  };

  const deleteConnection = async (id: string) => {
    const { error } = await supabase.from("scope_connections").delete().eq("id", id);
    if (!error) {
      setConnections(prev => prev.filter(c => c.id !== id));
      toast.success("Conexão removida");
    }
  };

  const scopeMap = useMemo(() => new Map(scopes.map(s => [s.id, s])), [scopes]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <GitBranch className="h-5 w-5" /> Mapa de Conexões entre Escopos
        </CardTitle>
        <CardDescription>
          Defina como os escopos se relacionam (ex: Requisição → gera → Pedido de Compra). O assistente usará estas conexões para cruzar dados automaticamente.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Form */}
        <div className="flex items-end gap-2 pb-3 border-b border-border flex-wrap">
          <div className="space-y-1 min-w-[140px] flex-1">
            <label className="text-xs font-medium text-muted-foreground">Escopo Origem</label>
            <select
              value={sourceId}
              onChange={(e) => setSourceId(e.target.value)}
              className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
            >
              <option value="">Selecionar...</option>
              {scopes.map(s => (
                <option key={s.id} value={s.id}>{s.description || s.name} ({s.name})</option>
              ))}
            </select>
          </div>

          <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0 mb-2" />

          <div className="space-y-1 min-w-[100px]">
            <label className="text-xs font-medium text-muted-foreground">Relação</label>
            <Input
              value={relationship}
              onChange={(e) => setRelationship(e.target.value)}
              placeholder="gera"
              className="text-sm w-28"
            />
          </div>

          <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0 mb-2" />

          <div className="space-y-1 min-w-[140px] flex-1">
            <label className="text-xs font-medium text-muted-foreground">Escopo Destino</label>
            <select
              value={targetId}
              onChange={(e) => setTargetId(e.target.value)}
              className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
            >
              <option value="">Selecionar...</option>
              {scopes.map(s => (
                <option key={s.id} value={s.id}>{s.description || s.name} ({s.name})</option>
              ))}
            </select>
          </div>

          <Button onClick={addConnection} disabled={adding || !sourceId || !targetId} size="sm" className="gap-1.5 shrink-0">
            {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Conectar
          </Button>
        </div>

        {/* Connection list */}
        {loading ? (
          <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : connections.length > 0 ? (
          <>
            <div className="space-y-2">
              {connections.map(conn => {
                const src = scopeMap.get(conn.source_scope_id);
                const tgt = scopeMap.get(conn.target_scope_id);
                return (
                  <div key={conn.id} className="flex items-center gap-2 p-2 rounded-lg border border-border bg-muted/30 text-sm">
                    <div className="min-w-0">
                      <span className="text-xs font-medium">{src?.description || src?.name || '?'}</span>
                      <span className="block font-mono text-[10px] text-muted-foreground">{src?.name}</span>
                    </div>
                    <span className="text-muted-foreground shrink-0">→</span>
                    <span className="text-xs text-primary font-medium shrink-0">{conn.relationship}</span>
                    <span className="text-muted-foreground shrink-0">→</span>
                    <div className="min-w-0">
                      <span className="text-xs font-medium">{tgt?.description || tgt?.name || '?'}</span>
                      <span className="block font-mono text-[10px] text-muted-foreground">{tgt?.name}</span>
                    </div>
                    <div className="flex-1" />
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => deleteConnection(conn.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                );
              })}
            </div>

            {/* SVG Diagram */}
            <div className="pt-2">
              <p className="text-xs font-medium text-muted-foreground mb-2">Diagrama visual</p>
              <ConnectionDiagram scopes={scopes} connections={connections} />
            </div>
          </>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">
            Nenhuma conexão cadastrada. Use o formulário acima para conectar escopos.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
