import { useLocation } from "react-router-dom";
import { NavLink } from "@/components/NavLink";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  useSidebar } from
"@/components/ui/sidebar";
import { Database, MessageSquareText, Settings2, Users, Shield, Palette } from "lucide-react";

const navItems = [
{ title: "Base de Conhecimento", url: "/admin", icon: Database, enabled: true },
{ title: "Refinar Prompt", url: "/admin/prompt", icon: MessageSquareText, enabled: true },
{ title: "Design System", url: "/admin/design", icon: Palette, enabled: true },
{ title: "Configuração API", url: "/admin/api", icon: Settings2, enabled: true },
{ title: "Usuários", url: "/admin/users", icon: Users, enabled: true },
{ title: "Funções", url: "/admin/roles", icon: Shield, enabled: false }];


export function AdminNav() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border px-4 py-3">
        {!collapsed &&
        <span className="text-sm font-semibold text-sidebar-foreground">Painel de administração</span>
        }
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Módulos</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) =>
              <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild disabled={!item.enabled}>
                    {item.enabled ?
                  <NavLink
                    to={item.url}
                    end={item.url === "/admin"}
                    className="hover:bg-sidebar-accent/50"
                    activeClassName="bg-sidebar-accent text-sidebar-accent-foreground font-medium">
                    
                        <item.icon className="h-4 w-4 mr-2 shrink-0" />
                        {!collapsed && <span>{item.title}</span>}
                      </NavLink> :

                  <span className="flex items-center opacity-40 cursor-not-allowed">
                        <item.icon className="h-4 w-4 mr-2 shrink-0" />
                        {!collapsed &&
                    <span className="flex items-center gap-2">
                            {item.title}
                            <span className="text-[10px] bg-muted px-1.5 py-0.5 rounded">Em breve</span>
                          </span>
                    }
                      </span>
                  }
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>);

}