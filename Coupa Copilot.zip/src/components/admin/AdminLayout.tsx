import { Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/use-auth";
import { useUser } from "@/contexts/UserContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminNav } from "./AdminNav";
import { ArrowLeft, LogOut, Shield } from "lucide-react";

export default function AdminLayout() {
  const { user, signOut } = useAuth();
  const { isAdmin } = useUser();
  const navigate = useNavigate();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AdminNav />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 border-b border-border bg-card flex items-center justify-between px-4 shrink-0">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="mr-1" />
              <Button variant="ghost" size="sm" onClick={() => navigate("/chat")} className="gap-1.5 text-muted-foreground">
                <ArrowLeft className="h-4 w-4" />
                Chat
              </Button>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted-foreground hidden sm:inline">{user?.email?.split("@")[0]}</span>
              {isAdmin && (
                <Badge variant="outline" className="text-xs gap-1 border-primary/30 text-primary">
                  <Shield className="h-3 w-3" /> Admin
                </Badge>
              )}
              <Button variant="ghost" size="icon" onClick={signOut} title="Sair">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
