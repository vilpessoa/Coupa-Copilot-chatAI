import { useState, useEffect, useRef, useCallback } from "react";
import { Mic, MicOff, Send } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useDesignConfig } from "@/hooks/use-design-config";

const PLACEHOLDERS = [
  "Como criar uma requisição de compra?",
  "Explique o fluxo de aprovação...",
  "Como consultar meus pedidos?",
  "Quais são as políticas de despesas?",
  "Como funciona o catálogo de fornecedores?",
  "Resuma este documento",
];

interface ChatInputProps {
  onSend: (message: string) => void;
  isLoading: boolean;
}

function useSpeechRecognition(onTranscript: (text: string) => void) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    setIsSupported(!!SR);
    if (SR) {
      const recognition = new SR();
      recognition.lang = "pt-BR";
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let finalTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript) {
          onTranscript(finalTranscript);
        }
      };

      recognition.onerror = (event: Event & { error: string }) => {
        console.error("Speech recognition error:", event.error);
        if (event.error === "not-allowed") {
          toast.error("Permissão de microfone negada. Habilite nas configurações do navegador.");
        } else if (event.error !== "aborted") {
          toast.error("Erro no reconhecimento de voz. Tente novamente.");
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [onTranscript]);

  const toggle = useCallback(() => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch {
        toast.error("Não foi possível iniciar o reconhecimento de voz.");
      }
    }
  }, [isListening]);

  return { isListening, isSupported, toggle };
}

export function ChatInput({ onSend, isLoading }: ChatInputProps) {
  const [input, setInput] = useState("");
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [showPlaceholder, setShowPlaceholder] = useState(true);
  const [isActive, setIsActive] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const { config } = useDesignConfig();
  const agentName = config.app_name || "Coupa Copilot";

  const handleTranscript = useCallback((text: string) => {
    setInput(prev => prev + (prev && !prev.endsWith(" ") ? " " : "") + text);
    setIsActive(true);
    inputRef.current?.focus();
  }, []);

  const { isListening, isSupported, toggle: toggleMic } = useSpeechRecognition(handleTranscript);

  const handleSubmit = () => {
    if (!input.trim() || isLoading) return;
    onSend(input.trim());
    setInput("");
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
      inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, 120) + "px";
    }
  }, [input]);

  useEffect(() => {
    if (isActive || input) return;
    const interval = setInterval(() => {
      setShowPlaceholder(false);
      setTimeout(() => {
        setPlaceholderIndex((prev) => (prev + 1) % PLACEHOLDERS.length);
        setShowPlaceholder(true);
      }, 400);
    }, 3000);
    return () => clearInterval(interval);
  }, [isActive, input]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        if (!input) setIsActive(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [input]);

  const placeholderContainerVariants = {
    initial: {},
    animate: { transition: { staggerChildren: 0.02 } },
    exit: { transition: { staggerChildren: 0.012, staggerDirection: -1 } },
  };

  const letterVariants = {
    initial: { opacity: 0, filter: "blur(8px)", y: 8 },
    animate: {
      opacity: 1, filter: "blur(0px)", y: 0,
      transition: { opacity: { duration: 0.2 }, filter: { duration: 0.3 }, y: { type: "spring" as const, stiffness: 80, damping: 20 } },
    },
    exit: {
      opacity: 0, filter: "blur(8px)", y: -8,
      transition: { opacity: { duration: 0.15 }, filter: { duration: 0.2 }, y: { type: "spring" as const, stiffness: 80, damping: 20 } },
    },
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 pb-4">
      <div
        ref={wrapperRef}
        className="relative rounded-full border border-border/40 bg-card shadow-lg overflow-hidden"
        onClick={() => {
          if (!isActive) {
            setIsActive(true);
            inputRef.current?.focus();
          }
        }}
      >
        <div className="flex items-center gap-2 px-4 py-2.5">
          <div className="relative flex-1 min-w-0">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onFocus={() => setIsActive(true)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              rows={1}
              className="w-full resize-none border-0 outline-none bg-transparent text-sm text-foreground placeholder:text-transparent py-1"
              style={{ position: "relative", zIndex: 1 }}
            />
            <div className="absolute inset-0 flex items-center pointer-events-none" style={{ zIndex: 0 }}>
              <AnimatePresence mode="wait">
                {showPlaceholder && !isActive && !input && (
                  <motion.span
                    key={placeholderIndex}
                    variants={placeholderContainerVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                    className="text-sm text-muted-foreground flex"
                  >
                    {PLACEHOLDERS[placeholderIndex].split("").map((char, i) => (
                      <motion.span key={i} variants={letterVariants}>
                        {char === " " ? "\u00A0" : char}
                      </motion.span>
                    ))}
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Mic button */}
          <button
            className={cn(
              "shrink-0 p-1.5 rounded-full transition-colors relative",
              isListening
                ? "text-destructive"
                : "text-muted-foreground hover:text-foreground",
              !isSupported && "opacity-40 cursor-not-allowed"
            )}
            onClick={(e) => {
              e.stopPropagation();
              toggleMic();
            }}
            disabled={!isSupported || isLoading}
            title={
              !isSupported
                ? "Navegador não suporta reconhecimento de voz"
                : isListening
                  ? "Clique para parar"
                  : "Clique para falar"
            }
            tabIndex={-1}
          >
            {isListening ? (
              <>
                <MicOff className="h-4 w-4 relative z-10" />
                <span className="absolute inset-0 rounded-full bg-destructive/20 animate-pulse" />
              </>
            ) : (
              <Mic className="h-4 w-4" />
            )}
          </button>

          <button
            onClick={handleSubmit}
            disabled={!input.trim() || isLoading}
            className={cn(
              "shrink-0 flex h-8 w-8 items-center justify-center rounded-full transition-all duration-200",
              input.trim() && !isLoading
                ? "bg-primary text-primary-foreground hover:bg-primary/90 shadow-md"
                : "bg-muted text-muted-foreground cursor-not-allowed"
            )}
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground text-center mt-6">
        {agentName} pode cometer erros. Verifique as informações importantes.
      </p>
    </div>
  );
}
