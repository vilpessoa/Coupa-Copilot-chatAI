import { motion } from "framer-motion";

interface SuggestedQuestionsProps {
  questions: string[];
  onSelect: (question: string) => void;
}

// Sanitize interrogative prefixes into imperative commands
function sanitize(text: string): string {
  return text
    .replace(/^(Você )?(quer|deseja|gostaria)( que eu| saber| ver)?\.?\s*/i, "")
    .replace(/^(Quer que eu|Posso te|Você está tentando)\s*/i, "")
    .replace(/\?$/, "")
    .replace(/^./, c => c.toUpperCase())
    .trim();
}

export function SuggestedQuestions({ questions, onSelect }: SuggestedQuestionsProps) {
  if (!questions.length) return null;

  const cleaned = questions.map(sanitize).filter(Boolean);

  return (
    <div className="flex flex-wrap gap-2 justify-start px-4 py-2">
      {cleaned.map((q, i) => (
        <motion.button
          key={i}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2, delay: i * 0.06 }}
          onClick={() => onSelect(q)}
          className="px-3 py-1.5 rounded-lg border border-primary/20 bg-card text-xs text-foreground
            hover:bg-primary hover:text-primary-foreground hover:border-primary
            transition-all duration-200"
        >
          {q}
        </motion.button>
      ))}
    </div>
  );
}
