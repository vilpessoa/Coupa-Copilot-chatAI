import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import {
  Lightbulb,
  FileText,
  Users,
  BarChart3,
  ClipboardCheck,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  Package } from
"lucide-react";
import { cn } from "@/lib/utils";

interface Tip {
  id: string;
  title: string;
  description: string;
  icon: string;
}

const ICON_MAP: Record<string, React.ElementType> = {
  lightbulb: Lightbulb,
  "file-text": FileText,
  users: Users,
  "bar-chart-3": BarChart3,
  "clipboard-check": ClipboardCheck,
  sparkles: Sparkles,
  "shield-check": ShieldCheck,
  "trending-up": TrendingUp,
  package: Package
};

export function TipsCarousel() {
  const [tips, setTips] = useState<Tip[]>([]);

  useEffect(() => {
    supabase.
    from("tips" as any).
    select("id, title, description, icon").
    eq("is_active", true).
    order("priority").
    then(({ data }) => {
      if (data) setTips(data as any);
    });
  }, []);

  if (!tips.length) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.7 }}
      className="w-full"
      style={{
        maskImage: "linear-gradient(to right, transparent, black 8%, black 92%, transparent)",
        WebkitMaskImage: "linear-gradient(to right, transparent, black 8%, black 92%, transparent)",
      }}>
      
      <div className="overflow-hidden">
        <div
          className="flex gap-3 animate-scroll hover:[animation-play-state:paused]"
          style={{ width: "max-content" }}>
          {[...tips, ...tips].map((tip, index) => {
            const Icon = ICON_MAP[tip.icon] || Lightbulb;
            return (
              <div
                key={`${tip.id}-${index}`}
                className="w-[170px] flex-shrink-0 rounded-2xl border border-border bg-card shadow-sm p-4 space-y-2 transition-all duration-200 hover:scale-[1.02] hover:shadow-md">
                
                <div className="flex items-center gap-2">
                  <div className="flex items-center justify-center h-8 w-8 rounded-xl bg-primary/10">
                    <Icon className="h-4.5 w-4.5 text-primary" />
                  </div>
                  <span className="text-sm font-semibold text-foreground leading-tight">
                    {tip.title}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {tip.description}
                </p>
              </div>);
          })}
        </div>
      </div>
    </motion.div>);
}