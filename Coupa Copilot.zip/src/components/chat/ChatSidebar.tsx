import { useState } from "react";
import { Conversation } from "@/types/chat";
import { Plus, Trash2, MessageSquare, PanelLeftClose, Search, Pencil, Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { isToday, isYesterday, subDays, isAfter } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";

interface ChatSidebarProps {
  conversations: Conversation[];
  activeId?: string;
  onSelect: (conversation: Conversation) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

function groupConversations(conversations: Conversation[]) {
  const today: Conversation[] = [];
  const yesterday: Conversation[] = [];
  const last7Days: Conversation[] = [];
  const older: Conversation[] = [];
  const sevenDaysAgo = subDays(new Date(), 7);

  conversations.forEach(c => {
    const date = new Date(c.updated_at || c.created_at);
    if (isToday(date)) today.push(c);
    else if (isYesterday(date)) yesterday.push(c);
    else if (isAfter(date, sevenDaysAgo)) last7Days.push(c);
    else older.push(c);
  });

  return { today, yesterday, last7Days, older };
}

function ConversationGroup({
  label,
  conversations,
  activeId,
  onSelect,
  onDelete,
  onRename,
}: {
  label: string;
  conversations: Conversation[];
  activeId?: string;
  onSelect: (c: Conversation) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
}) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  if (!conversations.length) return null;

  const startEdit = (c: Conversation, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(c.id);
    setEditTitle(c.title);
  };

  const confirmEdit = (id: string) => {
    if (editTitle.trim()) onRename(id, editTitle.trim());
    setEditingId(null);
  };

  return (
    <div className="mb-4">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 mb-1.5">
        {label}
      </p>
      {conversations.map(c => (
        <div
          key={c.id}
          onMouseEnter={() => setHoveredId(c.id)}
          onMouseLeave={() => setHoveredId(null)}
          onClick={() => editingId !== c.id && onSelect(c)}
          className={cn(
            "flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer text-sm transition-colors group",
            activeId === c.id
              ? "bg-primary/10 text-primary font-medium"
              : "text-foreground hover:bg-muted"
          )}
        >
          <MessageSquare className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
          {editingId === c.id ? (
            <form
              className="flex items-center gap-1 flex-1 min-w-0"
              onSubmit={(e) => { e.preventDefault(); confirmEdit(c.id); }}
            >
              <input
                autoFocus
                value={editTitle}
                onChange={e => setEditTitle(e.target.value)}
                className="flex-1 min-w-0 bg-background border border-border rounded px-1.5 py-0.5 text-sm"
                onClick={e => e.stopPropagation()}
              />
              <button type="submit" className="p-0.5" onClick={e => e.stopPropagation()}>
                <Check className="h-3.5 w-3.5 text-emerald-500" />
              </button>
              <button type="button" className="p-0.5" onClick={e => { e.stopPropagation(); setEditingId(null); }}>
                <X className="h-3.5 w-3.5 text-muted-foreground" />
              </button>
            </form>
          ) : (
            <>
              <span className="truncate flex-1">{c.title}</span>
              {hoveredId === c.id && (
                <div className="flex items-center gap-0.5">
                  <button
                    onClick={(e) => startEdit(c, e)}
                    className="p-0.5 rounded hover:bg-accent/50 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); onDelete(c.id); }}
                    className="p-0.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      ))}
    </div>
  );
}

export function ChatSidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
  isOpen,
  onClose,
}: ChatSidebarProps) {
  const [search, setSearch] = useState("");

  const filtered = search.trim()
    ? conversations.filter(c => c.title.toLowerCase().includes(search.toLowerCase()))
    : conversations;

  const groups = groupConversations(filtered);

  const handleRename = async (id: string, title: string) => {
    await supabase.from("conversations").update({ title }).eq("id", id);
    // Update local state via parent - for now trigger conversations reload
    // The conversations prop comes from parent so we can't update directly
    // Simple workaround: update the DOM optimistically
    const conv = conversations.find(c => c.id === id);
    if (conv) conv.title = title;
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40"
            onClick={onClose}
          />
        )}
      </AnimatePresence>

      <motion.aside
        initial={false}
        animate={{ x: isOpen ? 0 : -384 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className={cn(
          "fixed z-50 h-full w-80 flex flex-col border-r border-border glass"
        )}
      >
        <div className="flex items-center justify-between p-3 border-b border-border">
          <button
            onClick={onNew}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors flex-1 justify-center"
          >
            <Plus className="h-4 w-4" />
            Nova conversa
          </button>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-muted transition-colors ml-2"
          >
            <PanelLeftClose className="h-4 w-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-3 py-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar conversas..."
              className="w-full pl-8 pr-3 py-1.5 text-sm rounded-lg border border-border bg-background placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-2">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-center px-4">
              <MessageSquare className="h-8 w-8 text-muted-foreground/40 mb-2" />
              <p className="text-sm text-muted-foreground">
                {search ? "Nenhuma conversa encontrada." : "Nenhuma conversa ainda."}
              </p>
              {!search && (
                <p className="text-xs text-muted-foreground/60">
                  Comece perguntando algo!
                </p>
              )}
            </div>
          ) : (
            <>
              <ConversationGroup label="Hoje" conversations={groups.today} activeId={activeId} onSelect={onSelect} onDelete={onDelete} onRename={handleRename} />
              <ConversationGroup label="Ontem" conversations={groups.yesterday} activeId={activeId} onSelect={onSelect} onDelete={onDelete} onRename={handleRename} />
              <ConversationGroup label="Últimos 7 dias" conversations={groups.last7Days} activeId={activeId} onSelect={onSelect} onDelete={onDelete} onRename={handleRename} />
              <ConversationGroup label="Mais antigos" conversations={groups.older} activeId={activeId} onSelect={onSelect} onDelete={onDelete} onRename={handleRename} />
            </>
          )}
        </div>
      </motion.aside>
    </>
  );
}
