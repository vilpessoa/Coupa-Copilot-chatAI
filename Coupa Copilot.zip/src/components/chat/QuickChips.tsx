import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";

interface QuickChipsProps {
  onSelect: (question: string) => void;
}

const FALLBACK_CHIPS = [
  "Minhas aprovações pendentes",
  "Status dos meus pedidos",
  "Resumo de gastos do mês",
];

export function QuickChips({ onSelect }: QuickChipsProps) {
  const [chips, setChips] = useState<string[]>(FALLBACK_CHIPS);

  useEffect(() => {
    supabase
      .from("suggested_questions")
      .select("question")
      .eq("is_active", true)
      .order("priority")
      .limit(4)
      .then(({ data }) => {
        if (data?.length) setChips(data.map((d) => d.question));
      });
  }, []);

  return (
    <div className="flex flex-wrap justify-center gap-2 px-4 pb-2">
      {chips.map((chip, i) => (
        <motion.button
          key={chip}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          onClick={() => onSelect(chip)}
          className="text-xs px-3 py-1.5 rounded-full border border-border bg-background hover:bg-muted text-foreground transition-colors shadow-sm"
        >
          {chip}
        </motion.button>
      ))}
    </div>
  );
}
