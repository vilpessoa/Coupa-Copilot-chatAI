import { motion } from "framer-motion";
import { ClipboardCheck, FileText, Truck } from "lucide-react";

interface StatusCardsProps {
  onSelect: (question: string) => void;
}

const STATUS_ITEMS = [
  {
    icon: ClipboardCheck,
    label: "Aprovações pendentes",
    value: "—",
    question: "Quais são minhas aprovações pendentes?",
    color: "text-amber-500",
    bg: "bg-amber-500/10",
  },
  {
    icon: FileText,
    label: "Requisições abertas",
    value: "—",
    question: "Quantas requisições abertas eu tenho?",
    color: "text-blue-500",
    bg: "bg-blue-500/10",
  },
  {
    icon: Truck,
    label: "Pedidos em trânsito",
    value: "—",
    question: "Quais pedidos estão em trânsito?",
    color: "text-emerald-500",
    bg: "bg-emerald-500/10",
  },
];

export function StatusCards({ onSelect }: StatusCardsProps) {
  return (
    <div className="grid grid-cols-3 gap-3 w-full">
      {STATUS_ITEMS.map((item, i) => (
        <motion.button
          key={item.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.5 + i * 0.1 }}
          onClick={() => onSelect(item.question)}
          className="flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4
            hover:border-primary/40 hover:shadow-md transition-all duration-200 group"
        >
          <div className={`flex items-center justify-center h-10 w-10 rounded-lg ${item.bg}`}>
            <item.icon className={`h-5 w-5 ${item.color}`} />
          </div>
          <span className="text-xs text-muted-foreground font-medium text-center leading-tight group-hover:text-foreground transition-colors">
            {item.label}
          </span>
        </motion.button>
      ))}
    </div>
  );
}
