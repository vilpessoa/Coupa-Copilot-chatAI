import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Message } from "@/types/chat";
import { ExternalLink, ThumbsUp, ThumbsDown, Copy, Check, Database, FileText, Sparkles, Globe, RefreshCw } from "lucide-react";
import { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider } from "@/components/ui/tooltip";
import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useDesignConfig } from "@/hooks/use-design-config";
import { useUser } from "@/contexts/UserContext";
import { UserAvatar } from "@/components/UserAvatar";
import coupaLogo from "@/assets/Coupa_logo_white.svg";

interface ChatMessageProps {
  message: Message;
  isStreaming?: boolean;
  onFollowUp?: (question: string) => void;
  onRetry?: () => void;
}

export function ChatMessage({ message, isStreaming, onFollowUp, onRetry }: ChatMessageProps) {
  const { config } = useDesignConfig();
  const { profile } = useUser();
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<"positive" | "negative" | null>(null);
  const isUser = message.role === "user";
  const isError = message.metadata?.is_error;
  const botAvatar = config.bot_avatar_url || coupaLogo;

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFeedback = useCallback(async (rating: "positive" | "negative") => {
    if (feedback) return;
    setFeedback(rating);
    await supabase.from("message_feedback" as any).upsert({
      message_id: message.id,
      rating,
    } as any);
  }, [feedback, message.id]);

  // Parse follow-up suggestions from content
  const followUps = message.metadata?.follow_ups || [];

  // Build source badges from source_types array (or fallback to single source_type)
  const SOURCE_BADGE_MAP: Record<string, { icon: typeof Sparkles; text: string; className: string }> = {
    general: { icon: Sparkles, text: "Pensado pela IA", className: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400" },
    knowledge_base: { icon: FileText, text: "Base de conhecimento", className: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400" },
    coupa_api: { icon: Database, text: "Dados em tempo real", className: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" },
    web: { icon: Globe, text: "Buscado na internet", className: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400" },
  };

  const rawTypes = message.metadata?.source_types
    || (message.metadata?.source_type ? [message.metadata.source_type] : []);
  // Deduplicate and map to badge configs
  const sourceBadges = [...new Set(rawTypes)]
    .map(t => SOURCE_BADGE_MAP[t])
    .filter(Boolean);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn("flex w-full gap-3 group", isUser ? "justify-end" : "justify-start")}
    >
      {/* Bot avatar */}
      {!isUser && (
        <div className="h-[34px] w-[34px] rounded-full bg-primary flex items-center justify-center shrink-0 mt-1 overflow-hidden">
          <img src={botAvatar} alt="AI" className={config.bot_avatar_url ? "h-full w-full object-cover" : "h-[18px] w-[18px]"} />
        </div>
      )}

      <div className="flex flex-col gap-2 max-w-[80%] md:max-w-[70%]">
        <div
          className={cn(
            "px-4 py-3 relative",
            isUser
              ? "rounded-2xl rounded-tr-none bg-primary text-primary-foreground"
              : "rounded-2xl rounded-tl-none bg-gradient-to-br from-coupa-purple-50 to-coupa-neutral-100 dark:from-muted dark:to-card text-foreground shadow-md border border-border/50"
          )}
        >

          {isUser ? (
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div className="prose prose-sm max-w-none dark:prose-invert prose-p:leading-7 prose-p:my-3 prose-li:my-1.5 prose-li:leading-7 prose-headings:mt-5 prose-headings:mb-2 prose-headings:font-bold prose-h3:text-[15px] prose-h3:text-foreground prose-h2:text-base prose-ul:my-3 prose-ol:my-3 prose-ol:pl-6 prose-ul:pl-6 prose-ol:!list-decimal prose-ul:!list-disc [&_ol>li]:!list-item [&_ul>li]:!list-item prose-pre:bg-coupa-neutral-800 prose-pre:text-coupa-neutral-100 prose-code:text-primary prose-headings:text-foreground prose-strong:text-foreground prose-table:border-collapse prose-th:border prose-th:border-border prose-th:bg-muted prose-th:px-3 prose-th:py-2 prose-th:text-left prose-th:text-xs prose-th:font-semibold prose-td:border prose-td:border-border prose-td:px-3 prose-td:py-2 prose-td:text-sm prose-tr:even:bg-muted/50 [&>*+*]:mt-3 [&_ol>li]:pl-1 [&_ul>li]:pl-1 [&_ol_ol]:mt-2 [&_ul_ul]:mt-2">
              <div className="overflow-x-auto">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {message.content}
                </ReactMarkdown>
              </div>
              {isStreaming && (
                <span className="inline-flex items-center gap-1 ml-1 align-middle">
                  <span className="typing-dot h-1.5 w-1.5 rounded-full bg-primary inline-block" />
                  <span className="typing-dot h-1.5 w-1.5 rounded-full bg-primary inline-block" />
                  <span className="typing-dot h-1.5 w-1.5 rounded-full bg-primary inline-block" />
                </span>
              )}
            </div>
          )}

          {/* Source type badges */}
          {!isUser && sourceBadges.length > 0 && !isStreaming && !(rawTypes.length === 1 && rawTypes[0] === "general" && (!message.sources || message.sources.length === 0)) && (
            <div className="flex items-center justify-between mt-2">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Fonte</span>
              <div className="flex items-center gap-1.5">
                <TooltipProvider delayDuration={200}>
                  {sourceBadges.map((badge, i) => (
                    <Tooltip key={i}>
                      <TooltipTrigger asChild>
                        <div className={cn("h-6 w-6 rounded-full flex items-center justify-center cursor-default", badge.className)}>
                          <badge.icon className="h-3.5 w-3.5" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="text-xs">
                        {badge.text}
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </TooltipProvider>
              </div>
            </div>
          )}

          {/* Source citations */}
          {!isUser && message.sources && message.sources.length > 0 && !isStreaming && (
            <div className={cn("space-y-1.5", sourceBadges.length > 0 ? "mt-1" : "mt-3 pt-2 border-t border-border/30")}>
              {sourceBadges.length === 0 && <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Fontes</p>}
              {message.sources.slice(0, 3).map((source, i) => (
                <a key={i} href={source.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs text-primary hover:underline transition-colors">
                  <ExternalLink className="h-3 w-3 shrink-0" />
                  <span className="truncate">{source.title}</span>
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Follow-up suggestions */}
        {!isUser && !isStreaming && followUps.length > 0 && (
          <div className="flex flex-wrap gap-2 pl-1">
            {followUps.map((q, i) => (
              <button
                key={i}
                onClick={() => onFollowUp?.(q)}
                className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-full border border-border bg-background hover:bg-muted text-foreground transition-colors shadow-sm"
              >
                <Sparkles className="h-3 w-3 text-primary" />
                {q}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* User avatar */}
      {isUser && (
        profile ? (
          <div className="shrink-0 mt-1">
            <UserAvatar user={{ full_name: profile.full_name, avatar_url: profile.avatar_url, role: profile.role }} size="sm" />
          </div>
        ) : (
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center shrink-0 mt-1">
            <span className="text-xs font-semibold text-muted-foreground">U</span>
          </div>
        )
      )}
    </motion.div>
  );
}
