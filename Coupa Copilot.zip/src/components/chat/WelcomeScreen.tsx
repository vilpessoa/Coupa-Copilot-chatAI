import { motion } from "framer-motion";
import coupaLogo from "@/assets/Coupa_logo_white.svg";
import { useDesignConfig } from "@/hooks/use-design-config";
import { useUser } from "@/contexts/UserContext";
import { getFirstName } from "@/lib/utils";
import { TipsCarousel } from "./TipsCarousel";
function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Bom dia";
  if (hour < 18) return "Boa tarde";
  return "Boa noite";
}

interface WelcomeScreenProps {
  onSelectQuestion: (question: string) => void;
}

export function WelcomeScreen({ onSelectQuestion }: WelcomeScreenProps) {
  const { config } = useDesignConfig();
  const { profile } = useUser();
  const botAvatar = config.bot_avatar_url || coupaLogo;
  const appName = config.app_name || "Coupa Copilot";
  const nameParts = appName.split(" ");
  const firstWord = nameParts[0];
  const rest = nameParts.slice(1).join(" ");

  const greeting = getGreeting();
  const userName = getFirstName(profile?.full_name || profile?.email?.split("@")[0] || "");

  return (
    <div className="flex flex-col items-center justify-center flex-1 px-4 py-4 gap-8 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-3xl w-full"
      >
        {/* Dobra 2 - Hero */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="inline-flex items-center justify-center h-20 w-20 rounded-2xl bg-primary mb-4 shadow-lg overflow-hidden p-0"
        >
          <img src={botAvatar} alt={appName} className={config.bot_avatar_url ? "h-full w-full object-cover" : "h-10 w-10"} />
        </motion.div>

        {userName && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-sm text-muted-foreground mb-1"
          >
            {greeting}, <span className="font-semibold text-foreground">{userName}</span>
          </motion.p>
        )}

        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-2">
          <span className="gradient-text">{firstWord}</span>{" "}
          {rest && <span className="text-foreground">{rest}</span>}
        </h1>

        <p className="text-xs font-light tracking-wide text-muted-foreground mb-0 max-w-md mx-auto leading-relaxed">
          {config.welcome_subtitle || "Seu assistente inteligente para a plataforma Coupa. Selecione uma ação rápida ou digite sua pergunta."}
        </p>
      </motion.div>


      {/* Dobra 5 - Dicas */}
      <div className="max-w-3xl w-full overflow-hidden mx-auto">
        <TipsCarousel />
      </div>
    </div>
  );
}
