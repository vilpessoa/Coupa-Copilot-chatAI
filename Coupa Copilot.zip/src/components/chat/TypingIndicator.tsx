import { motion } from "framer-motion";
import coupaLogo from "@/assets/Coupa_logo_white.svg";
import { useDesignConfig } from "@/hooks/use-design-config";

export function TypingIndicator() {
  const { config } = useDesignConfig();

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex justify-start items-start gap-3"
    >
      <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-1 overflow-hidden">
        {config.bot_avatar_url ? (
          <img src={config.bot_avatar_url} alt="AI" className="h-full w-full object-cover" />
        ) : (
          <img src={coupaLogo} alt="AI" className="h-4 w-4" />
        )}
      </div>
      <div className="bg-gradient-to-br from-coupa-purple-50 to-coupa-neutral-100 dark:from-muted dark:to-card rounded-2xl px-5 py-3 shadow-md border border-border/50">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <div className="typing-dot h-2 w-2 rounded-full bg-primary" />
            <div className="typing-dot h-2 w-2 rounded-full bg-primary" />
            <div className="typing-dot h-2 w-2 rounded-full bg-primary" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
