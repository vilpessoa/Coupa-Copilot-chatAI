type StreamChatParams = {
  messages: { role: "user" | "assistant"; content: string }[];
  onDelta: (text: string) => void;
  onDone: () => void;
  onError?: (error: string) => void;
  onCourtesyEnd?: () => void;
};

export type StreamResult = {
  sources: { title: string; url: string; relevance_score: number }[];
  confidence: string;
  source_type?: "coupa_api" | "knowledge_base" | "general" | "web";
  source_types?: string[];
  follow_ups?: string[];
};

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

const MAX_RETRIES = 3;
const BASE_DELAY_MS = 1000;
const STREAM_TIMEOUT_MS = 90_000; // 90s client-side timeout

async function fetchWithRetry(url: string, options: RequestInit, retries = MAX_RETRIES): Promise<Response> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const resp = await fetch(url, options);
      
      // Don't retry client errors (except 429 and 5xx)
      if (resp.ok || (resp.status >= 400 && resp.status < 500 && resp.status !== 429)) {
        return resp;
      }

      // 429: respect Retry-After header if present
      if (resp.status === 429 && attempt < retries) {
        const retryAfter = resp.headers.get("Retry-After");
        const delay = retryAfter ? parseInt(retryAfter, 10) * 1000 : BASE_DELAY_MS * Math.pow(2, attempt);
        console.warn(`Rate limited (429). Retrying in ${delay}ms (attempt ${attempt + 1}/${retries})`);
        await sleep(delay);
        continue;
      }

      // 5xx: retry with backoff
      if (resp.status >= 500 && attempt < retries) {
        const delay = BASE_DELAY_MS * Math.pow(2, attempt);
        console.warn(`Server error (${resp.status}). Retrying in ${delay}ms (attempt ${attempt + 1}/${retries})`);
        await sleep(delay);
        continue;
      }

      return resp;
    } catch (err) {
      // If aborted, don't retry
      if (err instanceof DOMException && err.name === "AbortError") throw err;
      // Network error: retry with backoff
      if (attempt < retries) {
        const delay = BASE_DELAY_MS * Math.pow(2, attempt);
        console.warn(`Network error. Retrying in ${delay}ms (attempt ${attempt + 1}/${retries})`, err);
        await sleep(delay);
        continue;
      }
      throw err;
    }
  }
  throw new Error("Max retries exceeded");
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export async function streamChat({ messages, onDelta, onDone, onError, onCourtesyEnd }: StreamChatParams): Promise<StreamResult | undefined> {
  // Get current session token for authenticated requests
  const { data: { session } } = await (await import("@/integrations/supabase/client")).supabase.auth.getSession();
  if (!session?.access_token) {
    onError?.("You must be logged in to use the chat.");
    return;
  }

  // Client-side timeout via AbortController
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), STREAM_TIMEOUT_MS);

  let resp: Response;
  try {
    resp = await fetchWithRetry(CHAT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ messages }),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timeoutId);
    if (err instanceof DOMException && err.name === "AbortError") {
      onError?.("A resposta demorou demais. Tente novamente com uma pergunta mais curta.");
    } else {
      onError?.("Serviço temporariamente indisponível. Tente novamente em alguns instantes.");
    }
    return;
  }

  if (!resp.ok || !resp.body) {
    clearTimeout(timeoutId);
    if (resp.status === 429) { onError?.("Rate limit excedido. Aguarde um momento e tente novamente."); return; }
    if (resp.status === 402) { onError?.("Créditos de IA esgotados. Entre em contato com o administrador."); return; }
    onError?.("Falha ao obter resposta. Tente novamente.");
    return;
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let textBuffer = "";
  let streamDone = false;
  let sources: any[] = [];
  let confidence = "high";
  let source_type: string | undefined;
  let source_types: string[] | undefined;
  let follow_ups: string[] | undefined;
  let receivedAnyContent = false;

  try {
    while (!streamDone) {
      const { done, value } = await reader.read();
      if (done) break;
      textBuffer += decoder.decode(value, { stream: true });

      let newlineIndex: number;
      while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
        let line = textBuffer.slice(0, newlineIndex);
        textBuffer = textBuffer.slice(newlineIndex + 1);

        if (line.endsWith("\r")) line = line.slice(0, -1);
        if (line.startsWith(":") || line.trim() === "") continue;
        if (!line.startsWith("data: ")) continue;

        const jsonStr = line.slice(6).trim();
        if (jsonStr === "[DONE]") { streamDone = true; break; }

        try {
          const parsed = JSON.parse(jsonStr);
          if (parsed.courtesy_end) { onCourtesyEnd?.(); continue; }
          if (parsed.sources) { sources = parsed.sources; }
          if (parsed.confidence) { confidence = parsed.confidence; }
          if (parsed.source_type) { source_type = parsed.source_type; }
          if (parsed.source_types) { source_types = parsed.source_types; }
          if (parsed.follow_ups) { follow_ups = parsed.follow_ups; }
          if (parsed.sources || parsed.confidence || parsed.source_type || parsed.source_types || parsed.follow_ups) continue;
          const content = parsed.choices?.[0]?.delta?.content as string | undefined;
          if (content) { receivedAnyContent = true; onDelta(content); }
        } catch {
          textBuffer = line + "\n" + textBuffer;
          break;
        }
      }
    }

    // Flush remaining
    if (textBuffer.trim()) {
      for (let raw of textBuffer.split("\n")) {
        if (!raw) continue;
        if (raw.endsWith("\r")) raw = raw.slice(0, -1);
        if (raw.startsWith(":") || raw.trim() === "") continue;
        if (!raw.startsWith("data: ")) continue;
        const jsonStr = raw.slice(6).trim();
        if (jsonStr === "[DONE]") continue;
        try {
          const parsed = JSON.parse(jsonStr);
          if (parsed.sources) { sources = parsed.sources; }
          if (parsed.source_type) { source_type = parsed.source_type; }
          if (parsed.source_types) { source_types = parsed.source_types; }
          if (parsed.follow_ups) { follow_ups = parsed.follow_ups; }
          if (parsed.sources || parsed.source_type || parsed.source_types || parsed.follow_ups) continue;
          const content = parsed.choices?.[0]?.delta?.content as string | undefined;
          if (content) { receivedAnyContent = true; onDelta(content); }
        } catch { /* ignore */ }
      }
    }
  } catch (err) {
    clearTimeout(timeoutId);
    if (err instanceof DOMException && err.name === "AbortError") {
      onError?.("A resposta demorou demais. Tente novamente com uma pergunta mais curta.");
    } else if (!receivedAnyContent) {
      onError?.("Falha ao obter resposta. Tente novamente.");
    }
    // If we received some content, just finish with what we have
    onDone();
    return receivedAnyContent ? { sources, confidence, source_type: source_type as any, source_types, follow_ups } : undefined;
  }

  clearTimeout(timeoutId);

  // If stream completed but no content was received, send a soft fallback (not a hard error)
  if (!receivedAnyContent) {
    onDelta("Não foi possível processar essa solicitação no momento. Tente reformular ou perguntar de outra forma.");
    onDone();
    return { sources, confidence, source_type: source_type as any, source_types, follow_ups };
  }

  onDone();
  return { sources, confidence, source_type: source_type as any, source_types, follow_ups };
}
