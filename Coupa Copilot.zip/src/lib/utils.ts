import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Extracts and humanizes the first name from a full name or email-derived string.
 * - "Vilcimar Pessoa da Silva" → "Vilcimar"
 * - "vilcimar.pessoa" → "Vilcimar"
 * - "" → ""
 */
export function getFirstName(nameOrLogin: string): string {
  if (!nameOrLogin?.trim()) return "";
  // If it looks like an email login (contains dots, no spaces), split by dot
  const cleaned = nameOrLogin.trim();
  const segment = cleaned.includes(" ")
    ? cleaned.split(" ")[0]
    : cleaned.split(".")[0];
  return segment.charAt(0).toUpperCase() + segment.slice(1).toLowerCase();
}
