export interface Message {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  sources?: { title: string; url: string; relevance_score: number }[];
  confidence?: "high" | "medium" | "low";
  tokens_used?: number;
  created_at: string;
  metadata?: {
    source_type?: "coupa_api" | "knowledge_base" | "general" | "web";
    source_types?: string[];
    follow_ups?: string[];
    is_error?: boolean;
  };
}

export interface Conversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface SuggestedQuestion {
  id: string;
  question: string;
  category: string;
  priority: number;
  is_active: boolean;
}
