import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { UserProvider, useUser } from "@/contexts/UserContext";
import { toast } from "sonner";
import Index from "./pages/Index.tsx";
import Auth from "./pages/Auth.tsx";
import LandingPage from "./pages/LandingPage.tsx";
import AdminLayout from "./components/admin/AdminLayout.tsx";
import KnowledgeBase from "./pages/admin/KnowledgeBase.tsx";
import PromptEditor from "./pages/admin/PromptEditor.tsx";
import ApiConfig from "./pages/admin/ApiConfig.tsx";
import DesignSystem from "./pages/admin/DesignSystem.tsx";
import UserManagement from "./pages/admin/UserManagement.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

function AdminGuard({ children }: { children: React.ReactNode }) {
  const { isAdmin, isLoading } = useUser();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAdmin) {
    toast.error("Acesso restrito a administradores");
    return <Navigate to="/chat" replace />;
  }

  return <>{children}</>;
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#030303]">
        <span className="text-white/60 font-light animate-pulse text-lg">Coupa Copilot</span>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <UserProvider>{children}</UserProvider>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#030303]">
        <span className="text-white/60 font-light animate-pulse text-lg">Coupa Copilot</span>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/chat" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<PublicRoute><LandingPage /></PublicRoute>} />
      <Route path="/login" element={<PublicRoute><Auth /></PublicRoute>} />
      <Route path="/chat" element={<ProtectedRoute><Index /></ProtectedRoute>} />
      <Route path="/admin" element={<ProtectedRoute><AdminGuard><AdminLayout /></AdminGuard></ProtectedRoute>}>
        <Route index element={<KnowledgeBase />} />
        <Route path="prompt" element={<PromptEditor />} />
        <Route path="design" element={<DesignSystem />} />
        <Route path="api" element={<ApiConfig />} />
        <Route path="users" element={<UserManagement />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Sonner />
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
