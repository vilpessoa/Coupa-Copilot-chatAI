import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Loader2, Trash2, ArrowLeft, RefreshCw, Globe, FileText,
  CheckCircle2, XCircle, ClipboardPaste, Upload, AlertTriangle,
  FileUp, Info
} from "lucide-react";
import { useNavigate } from "react-router-dom";

interface KnowledgeSource {
  id: string;
  url: string;
  title: string | null;
  status: string;
  source_type: string;
  created_at: string;
  last_crawled_at: string | null;
  knowledge_chunks: { count: number }[];
}

const ACCEPTED_FILE_TYPES = ".txt,.md,.csv,.pdf";
const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB

export default function Admin() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // URL scrape
  const [url, setUrl] = useState("");
  const [urlTitle, setUrlTitle] = useState("");
  const [scraping, setScraping] = useState(false);

  // Manual paste
  const [manualContent, setManualContent] = useState("");
  const [manualTitle, setManualTitle] = useState("");
  const [manualUrl, setManualUrl] = useState("");
  const [indexingManual, setIndexingManual] = useState(false);

  // File upload
  const [fileTitle, setFileTitle] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  // Sources
  const [sources, setSources] = useState<KnowledgeSource[]>([]);
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadSources = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "list" },
      });
      if (error) throw error;
      if (data?.sources) setSources(data.sources);
    } catch (err) {
      console.error("Failed to load sources:", err);
      toast.error("Falha ao carregar fontes");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadSources(); }, [loadSources]);

  // === URL Scrape ===
  const handleScrape = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    setScraping(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { url: url.trim(), title: urlTitle.trim() || undefined },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(`"${data.title}" — ${data.chunks_indexed} chunks indexados`);
        setUrl(""); setUrlTitle("");
        loadSources();
      } else throw new Error(data?.error || "Erro desconhecido");
    } catch (err: any) {
      toast.error(`Erro no scraping: ${err.message}`);
    } finally { setScraping(false); }
  };

  // === Manual Paste ===
  const handleManualIndex = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualContent.trim() || manualContent.trim().length < 20) {
      toast.error("Mínimo de 20 caracteres");
      return;
    }
    if (!manualTitle.trim()) {
      toast.error("Título é obrigatório");
      return;
    }
    setIndexingManual(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "manual-index", content: manualContent.trim(), title: manualTitle.trim(), url: manualUrl.trim() || undefined },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(`"${data.title}" — ${data.chunks_indexed} chunks indexados`);
        setManualContent(""); setManualTitle(""); setManualUrl("");
        loadSources();
      } else throw new Error(data?.error || "Erro desconhecido");
    } catch (err: any) {
      toast.error(`Erro ao indexar: ${err.message}`);
    } finally { setIndexingManual(false); }
  };

  // === File Upload ===
  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error("Falha ao ler arquivo"));
      reader.readAsText(file);
    });
  };

  const handleFileSelect = (file: File) => {
    if (file.size > MAX_FILE_SIZE) {
      toast.error("Arquivo muito grande. Máximo: 2MB");
      return;
    }
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!["txt", "md", "csv", "pdf"].includes(ext || "")) {
      toast.error("Formato inválido. Aceitos: .txt, .md, .csv, .pdf");
      return;
    }
    if (ext === "pdf") {
      toast.info("⚠️ PDFs são lidos como texto bruto. Se o conteúdo não aparecer corretamente, copie e cole o texto manualmente.");
    }
    setSelectedFile(file);
    if (!fileTitle.trim()) setFileTitle(file.name.replace(/\.[^.]+$/, ""));
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile || !fileTitle.trim()) return;

    setUploadingFile(true);
    try {
      const content = await readFileAsText(selectedFile);
      if (!content || content.trim().length < 20) {
        toast.error("Arquivo sem conteúdo suficiente (mín. 20 caracteres)");
        return;
      }
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: {
          action: "file-index",
          content: content.trim(),
          title: fileTitle.trim(),
          filename: selectedFile.name,
        },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(`"${data.title}" — ${data.chunks_indexed} chunks indexados`);
        setSelectedFile(null); setFileTitle("");
        if (fileInputRef.current) fileInputRef.current.value = "";
        loadSources();
      } else throw new Error(data?.error || "Erro desconhecido");
    } catch (err: any) {
      toast.error(`Erro ao indexar arquivo: ${err.message}`);
    } finally { setUploadingFile(false); }
  };

  const handleDelete = async (sourceId: string) => {
    setDeletingId(sourceId);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "delete", source_id: sourceId },
      });
      if (error) throw error;
      toast.success("Fonte removida");
      loadSources();
    } catch (err: any) {
      toast.error(`Erro ao deletar: ${err.message}`);
    } finally { setDeletingId(null); }
  };

  const estimateChunks = (text: string) => {
    const words = text.trim().split(/\s+/).filter(Boolean).length;
    return Math.max(1, Math.ceil(words / 450));
  };

  const getSourceTypeBadge = (type: string) => {
    switch (type) {
      case "manual": return <Badge variant="secondary">Manual</Badge>;
      case "file": return <Badge variant="outline">Arquivo</Badge>;
      default: return <Badge>URL</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <span className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"><CheckCircle2 className="h-3 w-3" /> Ativo</span>;
      case "error":
        return <span className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"><XCircle className="h-3 w-3" /> Erro</span>;
      default:
        return <span className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400"><Loader2 className="h-3 w-3 animate-spin" /> Processando</span>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate("/chat")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Base de Conhecimento</h1>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{user?.email}</span>
            <Button variant="ghost" size="sm" onClick={signOut}>Sair</Button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        {/* Info Banner */}
        <div className="flex items-start gap-3 p-4 rounded-lg border border-border bg-muted/50">
          <Info className="h-5 w-5 text-primary mt-0.5 shrink-0" />
          <div className="text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-1">Como funciona a Base de Conhecimento</p>
            <p>O conteúdo adicionado aqui será usado como contexto pelo Coupa Copilot para responder perguntas dos usuários. Quanto mais documentação relevante for indexada, melhores serão as respostas.</p>
          </div>
        </div>

        {/* 3 Cards Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Card A — URL */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Globe className="h-5 w-5 text-primary" />
                Adicionar por URL
              </CardTitle>
              <CardDescription>
                Extraia conteúdo de páginas públicas da web automaticamente.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="flex items-start gap-2 mb-4 p-2.5 rounded-md bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800">
                <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-400 mt-0.5 shrink-0" />
                <p className="text-xs text-yellow-700 dark:text-yellow-300">
                  Funciona apenas com páginas públicas. Para páginas protegidas por SSO (ex: Compass), use <strong>Colar Conteúdo</strong> ou <strong>Upload de Arquivo</strong>.
                </p>
              </div>
              <form onSubmit={handleScrape} className="space-y-3 flex-1 flex flex-col">
                <Input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com/docs/..."
                  required
                  disabled={scraping}
                />
                <Input
                  value={urlTitle}
                  onChange={(e) => setUrlTitle(e.target.value)}
                  placeholder="Título (opcional)"
                  disabled={scraping}
                />
                <div className="mt-auto pt-2">
                  <Button type="submit" disabled={scraping || !url.trim()} className="w-full">
                    {scraping ? <><Loader2 className="h-4 w-4 animate-spin" /> Processando...</> : <><Globe className="h-4 w-4" /> Indexar URL</>}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Card B — Manual Paste */}
          <Card className="flex flex-col md:col-span-2 lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <ClipboardPaste className="h-5 w-5 text-primary" />
                Colar Conteúdo
              </CardTitle>
              <CardDescription>
                Cole texto, Markdown ou HTML de páginas protegidas por SSO.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="mb-4 p-2.5 rounded-md bg-muted border border-border text-xs text-muted-foreground space-y-1">
                <p className="font-medium text-foreground">Passo a passo:</p>
                <p>1. Abra a página no Compass/portal Coupa</p>
                <p>2. Selecione todo o conteúdo (<kbd className="px-1 py-0.5 rounded bg-background border text-[10px]">Ctrl+A</kbd>)</p>
                <p>3. Copie (<kbd className="px-1 py-0.5 rounded bg-background border text-[10px]">Ctrl+C</kbd>) e cole abaixo</p>
              </div>
              <form onSubmit={handleManualIndex} className="space-y-3 flex-1 flex flex-col">
                <Input
                  value={manualTitle}
                  onChange={(e) => setManualTitle(e.target.value)}
                  placeholder="Título do conteúdo *"
                  required
                  disabled={indexingManual}
                />
                <Input
                  value={manualUrl}
                  onChange={(e) => setManualUrl(e.target.value)}
                  placeholder="URL de referência (opcional)"
                  disabled={indexingManual}
                />
                <Textarea
                  value={manualContent}
                  onChange={(e) => setManualContent(e.target.value)}
                  placeholder="Cole aqui o conteúdo da documentação..."
                  rows={6}
                  disabled={indexingManual}
                  className="font-mono text-xs flex-1 min-h-[120px]"
                />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {manualContent.length.toLocaleString()} chars
                    {manualContent.trim().length >= 20 && (
                      <span className="ml-2">• ~{estimateChunks(manualContent)} chunks</span>
                    )}
                  </span>
                  {manualContent.trim().length > 0 && manualContent.trim().length < 20 && (
                    <span className="text-destructive">Mín. 20 caracteres</span>
                  )}
                </div>
                <Button type="submit" disabled={indexingManual || manualContent.trim().length < 20 || !manualTitle.trim()} className="w-full">
                  {indexingManual ? <><Loader2 className="h-4 w-4 animate-spin" /> Indexando...</> : <><ClipboardPaste className="h-4 w-4" /> Indexar Conteúdo</>}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Card C — File Upload */}
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Upload className="h-5 w-5 text-primary" />
                Upload de Arquivo
              </CardTitle>
              <CardDescription>
                Envie arquivos de texto com a documentação.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="mb-4 text-xs text-muted-foreground space-y-1">
                <p><strong>Formatos aceitos:</strong> .txt, .md, .csv, .pdf</p>
                <p><strong>Tamanho máximo:</strong> 2MB</p>
                <p className="text-yellow-600 dark:text-yellow-400">⚠ PDFs devem conter texto selecionável (não imagens/scans)</p>
              </div>
              <form onSubmit={handleFileUpload} className="space-y-3 flex-1 flex flex-col">
                <Input
                  value={fileTitle}
                  onChange={(e) => setFileTitle(e.target.value)}
                  placeholder="Título do documento *"
                  required
                  disabled={uploadingFile}
                />
                {/* Drop zone */}
                <div
                  className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                    dragOver ? "border-primary bg-primary/5" : selectedFile ? "border-green-500 bg-green-50 dark:bg-green-900/20" : "border-border hover:border-primary/50"
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={handleFileDrop}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={ACCEPTED_FILE_TYPES}
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                  />
                  {selectedFile ? (
                    <div className="flex flex-col items-center gap-1">
                      <FileUp className="h-6 w-6 text-green-600 dark:text-green-400" />
                      <p className="text-sm font-medium text-foreground">{selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">{(selectedFile.size / 1024).toFixed(1)} KB</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <FileUp className="h-6 w-6 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Arraste um arquivo ou clique para selecionar</p>
                    </div>
                  )}
                </div>
                <div className="mt-auto pt-2">
                  <Button type="submit" disabled={uploadingFile || !selectedFile || !fileTitle.trim()} className="w-full">
                    {uploadingFile ? <><Loader2 className="h-4 w-4 animate-spin" /> Enviando...</> : <><Upload className="h-4 w-4" /> Indexar Arquivo</>}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Sources List */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Fontes Indexadas ({sources.length})
              </CardTitle>
              <Button variant="ghost" size="icon" onClick={loadSources} disabled={loading}>
                <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading && sources.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : sources.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Nenhuma fonte indexada. Use os métodos acima para adicionar conteúdo.
              </p>
            ) : (
              <div className="space-y-3">
                {sources.map((source) => {
                  const chunkCount = source.knowledge_chunks?.[0]?.count ?? 0;
                  return (
                    <div key={source.id} className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/30">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-sm text-foreground truncate">
                            {source.title || source.url}
                          </p>
                          {getSourceTypeBadge(source.source_type)}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{source.url}</p>
                        <div className="flex items-center gap-3 mt-1">
                          {getStatusBadge(source.status)}
                          <span className="text-xs text-muted-foreground">{chunkCount} chunks</span>
                          {source.last_crawled_at && (
                            <span className="text-xs text-muted-foreground">
                              {new Date(source.last_crawled_at).toLocaleDateString("pt-BR")}
                            </span>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(source.id)}
                        disabled={deletingId === source.id}
                        className="text-destructive hover:text-destructive"
                      >
                        {deletingId === source.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
