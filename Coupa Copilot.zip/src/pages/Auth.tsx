import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useDesignConfig } from "@/hooks/use-design-config";
import { hslStringToHex } from "@/lib/color-utils";
import coupaLogo from "@/assets/Coupa_logo_white.svg";
import { Mail, Lock, ArrowRight, AlertCircle, X, Eye, EyeOff, Building2, ChevronDown, Home } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";

const vertexSource = `
  attribute vec4 a_position;
  void main() { gl_Position = a_position; }
`;

const fragmentSource = `
precision mediump float;
uniform vec2 iResolution;
uniform float iTime;
uniform vec2 iMouse;
uniform vec3 u_color;

void mainImage(out vec4 fragColor, in vec2 fragCoord){
    vec2 uv = fragCoord / iResolution;
    vec2 centeredUV = (2.0 * fragCoord - iResolution.xy) / min(iResolution.x, iResolution.y);
    float time = iTime * 0.5;
    vec2 mouse = iMouse / iResolution;
    vec2 rippleCenter = 2.0 * mouse - 1.0;
    vec2 distortion = centeredUV;
    for (float i = 1.0; i < 8.0; i++) {
        distortion.x += 0.5 / i * cos(i * 2.0 * distortion.y + time + rippleCenter.x * 3.1415);
        distortion.y += 0.5 / i * cos(i * 2.0 * distortion.x + time + rippleCenter.y * 3.1415);
    }
    float wave = abs(sin(distortion.x + distortion.y + time));
    float glow = smoothstep(0.9, 0.2, wave);
    fragColor = vec4(u_color * glow, 1.0);
}

void main() { mainImage(gl_FragColor, gl_FragCoord.xy); }
`;

function SmokeyCanvas({ color }: {color: string;}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, hovering: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext("webgl");
    if (!gl) return;

    const compile = (type: number, src: string) => {
      const s = gl.createShader(type);
      if (!s) return null;
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {gl.deleteShader(s);return null;}
      return s;
    };

    const vs = compile(gl.VERTEX_SHADER, vertexSource);
    const fs = compile(gl.FRAGMENT_SHADER, fragmentSource);
    if (!vs || !fs) return;

    const prog = gl.createProgram()!;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
    gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
    const pos = gl.getAttribLocation(prog, "a_position");
    gl.enableVertexAttribArray(pos);
    gl.vertexAttribPointer(pos, 2, gl.FLOAT, false, 0, 0);

    const uRes = gl.getUniformLocation(prog, "iResolution");
    const uTime = gl.getUniformLocation(prog, "iTime");
    const uMouse = gl.getUniformLocation(prog, "iMouse");
    const uColor = gl.getUniformLocation(prog, "u_color");

    // Parse hex to RGB
    const hex = color.replace("#", "");
    const r = parseInt(hex.substring(0, 2), 16) / 255;
    const g = parseInt(hex.substring(2, 4), 16) / 255;
    const b = parseInt(hex.substring(4, 6), 16) / 255;
    gl.uniform3f(uColor, r, g, b);

    const start = Date.now();
    let animId: number;

    const render = () => {
      const w = canvas.clientWidth,h = canvas.clientHeight;
      canvas.width = w;canvas.height = h;
      gl.viewport(0, 0, w, h);
      gl.uniform2f(uRes, w, h);
      gl.uniform1f(uTime, (Date.now() - start) / 1000);
      const m = mouseRef.current;
      gl.uniform2f(uMouse, m.hovering ? m.x : w / 2, m.hovering ? h - m.y : h / 2);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      animId = requestAnimationFrame(render);
    };

    const onMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top, hovering: true };
    };
    const onLeave = () => {mouseRef.current.hovering = false;};

    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("mouseleave", onLeave);
    render();

    return () => {
      cancelAnimationFrame(animId);
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("mouseleave", onLeave);
    };
  }, [color]);

  return (
    <>
      <canvas ref={canvasRef} className="fixed inset-0 w-full h-full" style={{ zIndex: 0 }} />
      <div className="fixed inset-0 backdrop-blur-sm" style={{ zIndex: 1 }} />
    </>);

}

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [areaId, setAreaId] = useState("");
  const [areas, setAreas] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { config, isLoaded } = useDesignConfig();
  const navigate = useNavigate();

  // Fetch areas when switching to signup mode
  useEffect(() => {
    if (!isLogin) {
      supabase
        .from("areas")
        .select("id, name")
        .eq("is_active", true)
        .order("name")
        .then(({ data }) => {
          if (data) setAreas(data);
        });
    }
  }, [isLogin]);
  const shaderColor = hslStringToHex(config.primary_color || "245 100% 62%");

  const clearErrors = () => {
    setEmailError(null);
    setPasswordError(null);
    setGeneralError(null);
  };

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  const mapError = (msg: string) => {
    const lower = msg.toLowerCase();
    if (lower.includes("invalid login credentials")) {
      setGeneralError("Email ou senha incorretos");
      setEmailError(" ");
      setPasswordError(" ");
    } else if (lower.includes("email not confirmed")) {
      setEmailError("Verifique seu e-mail antes de entrar");
    } else if (lower.includes("user not found") || lower.includes("no user found")) {
      setEmailError("Não há cadastro com este e-mail");
    } else if (lower.includes("user already registered")) {
      setEmailError("Este e-mail já está cadastrado");
    } else if (lower.includes("password")) {
      setPasswordError(msg);
    } else {
      setGeneralError(msg);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearErrors();
    setLoading(true);
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: window.location.origin,
            data: areaId ? { area_id: areaId } : undefined,
          }
        });
        if (error) throw error;
        toast.success("Verifique seu e-mail para confirmar o cadastro.");
      }
    } catch (error: any) {
      mapError(error.message || "Erro na autenticação");
      triggerShake();
    } finally {
      setLoading(false);
    }
  };


  if (!isLoaded) {
    return <div className="min-h-screen bg-[#030303]" />;
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <SmokeyCanvas color={shaderColor} />

      {/* Glassmorphism Card */}
      <motion.div
        className="relative z-10 w-full max-w-md rounded-2xl border border-white/20 p-8 shadow-2xl"
        style={{ background: "rgba(255,255,255,0.1)", backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)" }}
        animate={shake ? { x: [0, -8, 8, -6, 6, -3, 3, 0] } : { x: 0 }}
        transition={{ duration: 0.4 }}>
        
        {/* Home link */}
        <button
          type="button"
          onClick={() => navigate("/")}
          className="absolute top-4 left-4 h-8 w-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-all duration-200 text-white/40 hover:text-white/80"
          title="Voltar ao início"
        >
          <Home className="h-4 w-4" />
        </button>

        {/* Header */}
        <div className="flex flex-col items-center gap-3 mb-8">
          <div className="h-16 w-16 rounded-2xl bg-primary/90 flex items-center justify-center shadow-lg overflow-hidden">
            {config.bot_avatar_url ?
            <img src={config.bot_avatar_url} alt="Avatar" className="h-full w-full object-cover" /> :

            <img src={coupaLogo} alt="Coupa" className="h-8 w-8" />
            }
          </div>
          <h1 className="text-2xl font-bold text-white">{config.app_name || "Coupa Copilot"}</h1>
          <p className="text-sm text-white/70">
            {isLogin ? "Faça login para continuar" : "Crie sua conta"}
          </p>
        </div>

        {/* General Error Banner */}
        {generalError &&
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-5 flex items-center gap-3 rounded-xl border border-red-400/30 bg-red-500/15 px-4 py-3">
          
            <AlertCircle className="h-5 w-5 shrink-0 text-red-300" />
            <span className="text-sm text-red-200">{generalError}</span>
            <button type="button" onClick={() => setGeneralError(null)} className="ml-auto text-red-300/60 hover:text-red-200">
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        }

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Email */}
          <div>
            <div className={`relative group rounded-xl transition-all duration-300 ${emailError ? "shadow-[0_0_0_1px_rgba(248,113,113,0.4),0_0_12px_-4px_rgba(248,113,113,0.2)]" : "focus-within:shadow-[0_0_0_1px_rgba(255,255,255,0.3),0_0_20px_-6px_rgba(255,255,255,0.08)]"}`}>
              <div className={`absolute left-3 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg flex items-center justify-center pointer-events-none transition-all duration-300 ${emailError ? "bg-red-400/10" : "bg-white/5 group-focus-within:bg-white/10"}`}>
                <Mail className={`h-4 w-4 transition-all duration-300 ${emailError ? "text-red-300/70" : "text-white/40 group-focus-within:text-white/80 group-focus-within:scale-110"}`} />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => {setEmail(e.target.value);setEmailError(null);}}
                required
                autoComplete="email"
                autoFocus
                placeholder=" "
                className={`peer w-full rounded-xl border bg-white/[0.03] py-4 pl-14 pr-10 text-sm text-white placeholder-transparent outline-none transition-all duration-300 focus:bg-white/[0.07] ${emailError ? "border-red-400/40" : "border-white/[0.12] hover:border-white/25 focus:border-white/40"}`} />
              <span className="pointer-events-none absolute left-14 top-1/2 -translate-y-1/2 text-sm text-white/30 transition-all duration-300 peer-focus:-top-0.5 peer-focus:-translate-y-full peer-focus:text-[11px] peer-focus:text-white/60 peer-[:not(:placeholder-shown)]:-top-0.5 peer-[:not(:placeholder-shown)]:-translate-y-full peer-[:not(:placeholder-shown)]:text-[11px] peer-[:not(:placeholder-shown)]:text-white/60">
                Email
              </span>
              {emailError && emailError.trim() &&
              <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="absolute right-3 top-1/2 -translate-y-1/2">
                <div className="h-6 w-6 rounded-full bg-red-400/15 flex items-center justify-center">
                  <AlertCircle className="h-3.5 w-3.5 text-red-400/80" />
                </div>
              </motion.div>
              }
            </div>
            {emailError && emailError.trim() &&
            <motion.p initial={{ opacity: 0, y: -6, height: 0 }} animate={{ opacity: 1, y: 0, height: "auto" }} className="mt-2 pl-3 text-xs text-red-300/80 flex items-center gap-1.5">
                <span className="inline-block h-1 w-1 rounded-full bg-red-400/60" />
                {emailError}
              </motion.p>
            }
          </div>

          {/* Password */}
          <div>
            <div className={`relative group rounded-xl transition-all duration-300 ${passwordError ? "shadow-[0_0_0_1px_rgba(248,113,113,0.4),0_0_12px_-4px_rgba(248,113,113,0.2)]" : "focus-within:shadow-[0_0_0_1px_rgba(255,255,255,0.3),0_0_20px_-6px_rgba(255,255,255,0.08)]"}`}>
              <div className={`absolute left-3 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg flex items-center justify-center pointer-events-none transition-all duration-300 ${passwordError ? "bg-red-400/10" : "bg-white/5 group-focus-within:bg-white/10"}`}>
                <Lock className={`h-4 w-4 transition-all duration-300 ${passwordError ? "text-red-300/70" : "text-white/40 group-focus-within:text-white/80 group-focus-within:scale-110"}`} />
              </div>
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => {setPassword(e.target.value);setPasswordError(null);}}
                required
                autoComplete={isLogin ? "current-password" : "new-password"}
                minLength={6}
                placeholder=" "
                className={`peer w-full rounded-xl border bg-white/[0.03] py-4 pl-14 pr-16 text-sm text-white placeholder-transparent outline-none transition-all duration-300 focus:bg-white/[0.07] ${passwordError ? "border-red-400/40" : "border-white/[0.12] hover:border-white/25 focus:border-white/40"}`} />
              <span className="pointer-events-none absolute left-14 top-1/2 -translate-y-1/2 text-sm text-white/30 transition-all duration-300 peer-focus:-top-0.5 peer-focus:-translate-y-full peer-focus:text-[11px] peer-focus:text-white/60 peer-[:not(:placeholder-shown)]:-top-0.5 peer-[:not(:placeholder-shown)]:-translate-y-full peer-[:not(:placeholder-shown)]:text-[11px] peer-[:not(:placeholder-shown)]:text-white/60">
                Senha
              </span>
              <button
                type="button"
                tabIndex={-1}
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors duration-200">
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
              {passwordError && passwordError.trim() &&
              <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="absolute right-10 top-1/2 -translate-y-1/2">
                <div className="h-6 w-6 rounded-full bg-red-400/15 flex items-center justify-center">
                  <AlertCircle className="h-3.5 w-3.5 text-red-400/80" />
                </div>
              </motion.div>
              }
            </div>
            {passwordError && passwordError.trim() &&
            <motion.p initial={{ opacity: 0, y: -6, height: 0 }} animate={{ opacity: 1, y: 0, height: "auto" }} className="mt-2 pl-3 text-xs text-red-300/80 flex items-center gap-1.5">
                <span className="inline-block h-1 w-1 rounded-full bg-red-400/60" />
                {passwordError}
              </motion.p>
            }
          </div>

          {/* Area (signup only) */}
          <AnimatePresence>
            {!isLogin && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="relative group rounded-xl transition-all duration-300 focus-within:shadow-[0_0_0_1px_rgba(255,255,255,0.3),0_0_20px_-6px_rgba(255,255,255,0.08)]">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg flex items-center justify-center pointer-events-none transition-all duration-300 bg-white/5 group-focus-within:bg-white/10">
                    <Building2 className="h-4 w-4 transition-all duration-300 text-white/40 group-focus-within:text-white/80 group-focus-within:scale-110" />
                  </div>
                  <select
                    value={areaId}
                    onChange={(e) => setAreaId(e.target.value)}
                    className={`w-full rounded-xl border bg-white/[0.03] py-4 pl-14 pr-10 text-sm outline-none transition-all duration-300 focus:bg-white/[0.07] border-white/[0.12] hover:border-white/25 focus:border-white/40 appearance-none cursor-pointer [&>option]:bg-[#1a1a2e] [&>option]:text-white ${areaId ? "text-white" : "text-white/30"}`}
                  >
                    <option value="">Selecione sua área</option>
                    {areas.map((area) => (
                      <option key={area.id} value={area.id}>{area.name}</option>
                    ))}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                    <ChevronDown className="h-4 w-4 text-white/40" />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Submit */}
          <Button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl py-3 text-sm font-semibold gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg">
            
            {loading ? "Aguarde..." : isLogin ? "Entrar" : "Criar conta"}
            {!loading && <ArrowRight className="h-4 w-4" />}
          </Button>
        </form>

        {/* Toggle */}
        <p className="mt-6 text-center text-sm text-white/60">
          {isLogin ? "Não tem conta? " : "Já tem conta? "}
          <button
            type="button"
            onClick={() => {setIsLogin(!isLogin);clearErrors();}}
            className="text-white font-medium underline underline-offset-2 hover:no-underline">
            
            {isLogin ? "Criar conta" : "Fazer login"}
          </button>
        </p>
      </motion.div>
    </div>);

}