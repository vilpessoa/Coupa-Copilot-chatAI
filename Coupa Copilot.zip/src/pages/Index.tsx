import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useChat } from "@/hooks/use-chat";
import { useAuth } from "@/hooks/use-auth";
import { useDesignConfig } from "@/hooks/use-design-config";
import { useUser } from "@/contexts/UserContext";
import { supabase } from "@/integrations/supabase/client";
import { ChatSidebar } from "@/components/chat/ChatSidebar";
import { ChatMessage } from "@/components/chat/ChatMessage";
import { ChatInput } from "@/components/chat/ChatInput";
import { TypingIndicator } from "@/components/chat/TypingIndicator";
import { WelcomeScreen } from "@/components/chat/WelcomeScreen";
import { ThemeToggle } from "@/components/ThemeToggle";
import { UserAvatar } from "@/components/UserAvatar";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { Menu, LogOut, Settings, ChevronDown, User, Shield, Camera } from "lucide-react";
import { toast } from "sonner";
import coupaLogo from "@/assets/Coupa_logo_white.svg";

const Index = () => {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const { config } = useDesignConfig();
  const { profile, isAdmin, refetchProfile } = useUser();
  const headerLogo = config.logo_url || coupaLogo;
  const {
    conversations,
    activeConversation,
    messages,
    isLoading,
    isStreaming,
    loadConversations,
    selectConversation,
    deleteConversation,
    newConversation,
    sendMessage
  } = useChat();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileSheetOpen, setProfileSheetOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const showWelcome = !activeConversation && messages.length === 0;

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      <ChatSidebar
        conversations={conversations}
        activeId={activeConversation?.id}
        onSelect={selectConversation}
        onNew={newConversation}
        onDelete={deleteConversation}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)} />

      <div className="flex flex-1 flex-col min-w-0">
        <header className="relative flex items-center h-16 px-4 border-b border-border bg-background/80 backdrop-blur-xl shadow-sm shrink-0 z-30">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-xl hover:bg-muted transition-colors"
            title="Menu">
            <Menu className="h-5 w-5 text-foreground" />
          </button>

          <div className="flex items-center gap-2.5">
            <img
              src={headerLogo}
              alt={config.app_name}
              className={config.logo_url ? "h-7 object-contain" : "h-5 w-5"} />
          </div>

          <div className="ml-auto flex items-center gap-3">
            <ThemeToggle />

            <Popover>
              <PopoverTrigger asChild>
                <button className="flex items-center gap-1.5 p-1 rounded-xl hover:bg-muted transition-colors">
                  {profile ? (
                    <UserAvatar user={{ full_name: profile.full_name, avatar_url: profile.avatar_url, role: profile.role }} size="sm" />
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                      <User className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                  <ChevronDown className="h-3 w-3 text-muted-foreground" />
                </button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-72 p-4">
                <div className="flex flex-col items-center gap-2 py-2">
                  {profile && (
                    <UserAvatar user={{ full_name: profile.full_name, avatar_url: profile.avatar_url, role: profile.role }} size="lg" />
                  )}
                  <div className="text-center mt-1">
                    <p className="text-sm font-bold text-foreground truncate">
                      {profile?.full_name || "Usuário"}
                    </p>
                    {isAdmin ? (
                      <p className="text-xs text-primary flex items-center justify-center gap-1 mt-0.5">
                        <Shield className="h-3 w-3" /> Administrador
                      </p>
                    ) : (
                      <p className="text-xs text-muted-foreground mt-0.5">Usuário</p>
                    )}
                    <p className="text-xs text-muted-foreground truncate mt-0.5">
                      {profile?.email}
                    </p>
                    {(profile?.area_name || profile?.job_title) && (
                      <p className="text-xs text-muted-foreground/70 truncate mt-0.5">
                        {[profile.area_name, profile.job_title].filter(Boolean).join(" — ")}
                      </p>
                    )}
                  </div>
                </div>
                <Separator className="my-2" />
                {isAdmin && (
                  <button
                    onClick={() => navigate("/admin")}
                    className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm text-foreground hover:bg-muted transition-colors">
                    <Settings className="h-4 w-4" />
                    Painel Admin
                  </button>
                )}
                <button
                  onClick={() => setProfileSheetOpen(true)}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm text-foreground hover:bg-muted transition-colors">
                  <User className="h-4 w-4" />
                  Meu Perfil
                </button>
                <Separator className="my-2" />
                <button
                  onClick={signOut}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors">
                  <LogOut className="h-4 w-4" />
                  Sair
                </button>
              </PopoverContent>
            </Popover>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {showWelcome ?
          <WelcomeScreen onSelectQuestion={sendMessage} /> :

          <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
              {messages.map((msg, i) =>
            <ChatMessage
              key={msg.id}
              message={msg}
              isStreaming={isStreaming && i === messages.length - 1 && msg.role === "assistant"}
              onFollowUp={sendMessage}
              onRetry={msg.metadata?.is_error ? () => {
                const lastUserMsg = messages.filter((m) => m.role === "user").pop();
                if (lastUserMsg) sendMessage(lastUserMsg.content);
              } : undefined} />

            )}
              {isLoading && (messages.length === 0 || messages[messages.length - 1].role !== "assistant") && <TypingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          }
        </div>

        <ChatInput onSend={sendMessage} isLoading={isStreaming} />
      </div>

      {/* My Profile Sheet */}
      {profile && (
        <MyProfileSheet
          open={profileSheetOpen}
          onOpenChange={setProfileSheetOpen}
          profile={profile}
          onSaved={refetchProfile}
        />
      )}
    </div>);
};

// ─── My Profile Sheet ───────────────────────────────
function MyProfileSheet({ open, onOpenChange, profile, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  profile: { id: string; full_name: string; avatar_url: string | null; job_title: string | null; email: string; area_name?: string | null; role: string };
  onSaved: () => Promise<void>;
}) {
  const [fullName, setFullName] = useState(profile.full_name);
  const [jobTitle, setJobTitle] = useState(profile.job_title || "");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(profile.avatar_url);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setFullName(profile.full_name);
      setJobTitle(profile.job_title || "");
      setAvatarPreview(profile.avatar_url);
      setAvatarFile(null);
    }
  }, [open, profile]);

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const validTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) { toast.error("Formato não suportado. Use JPG, PNG ou WebP"); return; }
    if (file.size > 2 * 1024 * 1024) { toast.error("A imagem deve ter no máximo 2MB"); return; }
    setAvatarFile(file);
    setAvatarPreview(URL.createObjectURL(file));
  };

  const handleSave = async () => {
    if (!fullName.trim()) { toast.error("Nome é obrigatório"); return; }
    setSaving(true);
    try {
      let avatarUrl = profile.avatar_url;
      if (avatarFile) {
        const ext = avatarFile.name.split(".").pop();
        const path = `${profile.id}/${Date.now()}.${ext}`;
        const { error: uploadErr } = await supabase.storage.from("avatars").upload(path, avatarFile, { upsert: true });
        if (uploadErr) throw uploadErr;
        const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(path);
        avatarUrl = urlData.publicUrl;
      }
      const { error } = await supabase.from("profiles").update({
        full_name: fullName.trim(),
        job_title: jobTitle.trim() || null,
        avatar_url: avatarUrl,
      }).eq("id", profile.id);
      if (error) throw error;
      toast.success("Perfil atualizado");
      await onSaved();
      onOpenChange(false);
    } catch (err: any) {
      toast.error(err.message || "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Meu Perfil</SheetTitle>
        </SheetHeader>
        <div className="space-y-6 py-6">
          <div className="flex flex-col items-center gap-3">
            <label className="relative cursor-pointer group">
              <div className="h-[120px] w-[120px] rounded-full bg-muted flex items-center justify-center overflow-hidden border-2 border-dashed border-border group-hover:border-primary transition-colors">
                {avatarPreview ? (
                  <>
                    <img src={avatarPreview} alt="Preview" className="h-full w-full object-cover" />
                    <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center gap-1 text-muted-foreground">
                    <Camera className="h-6 w-6" />
                    <span className="text-xs">Adicionar foto</span>
                  </div>
                )}
              </div>
              <input type="file" className="hidden" accept=".jpg,.jpeg,.png,.webp" onChange={handleAvatarChange} />
            </label>
          </div>

          <div className="space-y-4">
            <div>
              <Label>Nome completo</Label>
              <Input value={fullName} onChange={e => setFullName(e.target.value)} />
            </div>
            <div>
              <Label>Cargo/Função</Label>
              <Input value={jobTitle} onChange={e => setJobTitle(e.target.value)} placeholder="Ex: Analista, Coordenador" />
            </div>
            <div>
              <Label className="text-muted-foreground">E-mail (somente leitura)</Label>
              <Input value={profile.email} disabled />
            </div>
            {profile.area_name && (
              <div>
                <Label className="text-muted-foreground">Área (somente leitura)</Label>
                <Input value={profile.area_name} disabled />
              </div>
            )}
            <div>
              <Label className="text-muted-foreground">Permissão (somente leitura)</Label>
              <Input value={profile.role === "admin" ? "Administrador" : "Usuário"} disabled />
            </div>
          </div>
        </div>
        <SheetFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Salvando..." : "Salvar"}</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

export default Index;
