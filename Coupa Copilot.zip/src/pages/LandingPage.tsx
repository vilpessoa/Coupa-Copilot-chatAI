import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { useTheme } from "next-themes";
import { ArrowRight } from "lucide-react";
import CoupaLogo from "@/assets/Coupa_logo_white.svg";
import { ElegantShape } from "@/components/ui/elegant-shape";
import { TypingEffect } from "@/components/ui/typing-effect";
import { DisplayCards } from "@/components/ui/display-cards";
import { HoverBorderGradient } from "@/components/ui/hover-border-gradient";
import { useIsMobile } from "@/hooks/use-mobile";

/* ── helpers ── */
const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, delay, ease: "easeOut" as const },
});

const headlineWords: { text: string; delay: number; className?: string }[][] = [
  [
    { text: "Seu", delay: 0.7 },
    { text: "assistente", delay: 0.85 },
    { text: "inteligente", delay: 1.0 },
  ],
  [
    { text: "para", delay: 1.2 },
    { text: "o", delay: 1.35 },
    { text: "Coupa", delay: 1.5 },
  ],
];

/* ── component ── */
export default function LandingPage() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const prefersReducedMotion = useReducedMotion();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  /* mouse follow */
  const [mousePos, setMousePos] = useState({ x: -200, y: -200 });
  const [mouseVisible, setMouseVisible] = useState(false);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
    setMouseVisible(true);
  }, []);

  useEffect(() => {
    if (isMobile || prefersReducedMotion) return;
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseleave", () => setMouseVisible(false));
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseleave", () => setMouseVisible(false));
    };
  }, [isMobile, prefersReducedMotion, handleMouseMove]);

  /* ripple */
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const rippleId = useRef(0);

  const handleClick = useCallback(
    (e: React.MouseEvent) => {
      if (isMobile || prefersReducedMotion) return;
      const id = rippleId.current++;
      setRipples((r) => [...r.slice(-4), { id, x: e.clientX, y: e.clientY }]);
      setTimeout(() => setRipples((r) => r.filter((v) => v.id !== id)), 1000);
    },
    [isMobile, prefersReducedMotion],
  );

  return (
    <div
      className="min-h-screen flex flex-col justify-between bg-background overflow-hidden relative transition-colors duration-500"
      onClick={handleClick}
    >
      {/* ── Layer 1: Background Grid ── */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
        <defs>
          <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(100,116,139,0.1)" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        {/* decorative lines */}
        {[
          { x1: "0%", y1: "20%", x2: "100%", y2: "20%", delay: "0.5s" },
          { x1: "0%", y1: "80%", x2: "100%", y2: "80%", delay: "1s" },
          { x1: "20%", y1: "0%", x2: "20%", y2: "100%", delay: "1.5s" },
          { x1: "80%", y1: "0%", x2: "80%", y2: "100%", delay: "2s" },
        ].map((l, i) => (
          <line key={i} {...l} className="landing-grid-line" style={{ animationDelay: l.delay }} />
        ))}
        {/* dots */}
        {[
          { cx: "20%", cy: "20%" },
          { cx: "80%", cy: "20%" },
          { cx: "20%", cy: "80%" },
          { cx: "80%", cy: "80%" },
          { cx: "50%", cy: "50%", r: 1.5 },
        ].map((d, i) => (
          <circle
            key={i}
            cx={d.cx}
            cy={d.cy}
            r={d.r ?? 2}
            className="landing-pulse-dot"
            style={{ animationDelay: `${i * 0.6}s` }}
          />
        ))}
      </svg>

      {/* ── Layer 1b: Ambient Gradient ── */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/[0.05] via-transparent to-indigo-500/[0.05] dark:from-blue-500/[0.05] dark:to-indigo-500/[0.05] blur-3xl z-0" />

      {/* ── Layer 2: Floating Shapes ── */}
      <div className="z-[1]">
        <ElegantShape
          delay={0.3}
          width={600}
          height={140}
          rotate={12}
          gradient="from-blue-500/[0.12]"
          className="left-[-10%] md:left-[-5%] top-[15%] md:top-[20%]"
        />
        <ElegantShape
          delay={0.5}
          width={500}
          height={120}
          rotate={-15}
          gradient="from-indigo-500/[0.12]"
          className="right-[-5%] md:right-[0%] top-[70%] md:top-[75%]"
        />
        <ElegantShape
          delay={0.4}
          width={300}
          height={80}
          rotate={-8}
          gradient="from-cyan-500/[0.12]"
          className="left-[5%] md:left-[10%] bottom-[5%] md:bottom-[10%]"
        />
        {!isMobile && (
          <>
            <ElegantShape
              delay={0.6}
              width={200}
              height={60}
              rotate={20}
              gradient="from-blue-400/[0.10]"
              className="right-[15%] md:right-[20%] top-[10%] md:top-[15%]"
            />
            <ElegantShape
              delay={0.7}
              width={150}
              height={40}
              rotate={-25}
              gradient="from-indigo-400/[0.10]"
              className="left-[20%] md:left-[25%] top-[5%] md:top-[10%]"
            />
          </>
        )}
      </div>

      {/* ── Layer 3: Vignette ── */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/80 pointer-events-none z-[2]" />

      {/* ── Layer 4: Corner Elements ── */}
      {[
        {
          pos: "top-4 left-4 sm:top-6 sm:left-6 md:top-8 md:left-8",
          corner: "border-t border-l",
          dot: "top-0 left-0",
          delay: "4s",
        },
        {
          pos: "top-4 right-4 sm:top-6 sm:right-6 md:top-8 md:right-8",
          corner: "border-t border-r",
          dot: "top-0 right-0",
          delay: "4.2s",
        },
        {
          pos: "bottom-4 left-4 sm:bottom-6 sm:left-6 md:bottom-8 md:left-8",
          corner: "border-b border-l",
          dot: "bottom-0 left-0",
          delay: "4.4s",
        },
        {
          pos: "bottom-4 right-4 sm:bottom-6 sm:right-6 md:bottom-8 md:right-8",
          corner: "border-b border-r",
          dot: "bottom-0 right-0",
          delay: "4.6s",
        },
      ].map((c, i) => (
        <div
          key={i}
          className={`absolute ${c.pos} w-[40px] h-[40px] ${c.corner} border-foreground/[0.08] z-[3] landing-corner-fade`}
          style={{ animationDelay: c.delay }}
        >
          <div className={`absolute ${c.dot} w-[2px] h-[2px] bg-foreground/30 rounded-full`} />
        </div>
      ))}

      {/* ── Layer 5: Mouse-Follow Gradient ── */}
      {!isMobile && !prefersReducedMotion && (
        <div
          className="fixed pointer-events-none rounded-full w-60 h-60 blur-xl sm:w-80 sm:h-80 sm:blur-2xl md:w-96 md:h-96 md:blur-3xl z-[4] transition-opacity duration-300"
          style={{
            background: "radial-gradient(circle, rgba(156,163,175,0.05), rgba(107,114,128,0.05), transparent 70%)",
            transform: `translate(${mousePos.x - 192}px, ${mousePos.y - 192}px)`,
            opacity: mouseVisible ? 1 : 0,
            transition: "transform 70ms linear, opacity 300ms",
          }}
        />
      )}

      {/* ── Layer 6: Ripples ── */}
      {ripples.map((r) => (
        <div
          key={r.id}
          className="fixed w-1 h-1 rounded-full pointer-events-none z-50 landing-pulse-dot"
          style={{
            left: r.x,
            top: r.y,
            background: "rgba(203,213,225,0.6)",
          }}
        />
      ))}

      {/* ── Layer 7b: Cards behind hero ── */}
      <motion.div
        {...fadeUp(3.0)}
        className="absolute inset-0 z-[5] flex items-start justify-center pointer-events-none overflow-hidden"
        style={{ top: "68%" }}
      >
        <DisplayCards />
      </motion.div>

      {/* ── Layer 7: Main Content ── */}
      <div className="relative z-10 min-h-screen flex flex-col justify-between items-center px-6 py-10 sm:px-8 sm:py-12 md:px-16 md:py-20">
        {/* Badge */}
        <motion.div {...fadeUp(0.5)}>
          <HoverBorderGradient
            as="div"
            containerClassName="cursor-pointer"
            className="inline-flex items-center gap-2 px-3 py-1"
            onClick={(e: React.MouseEvent) => {
              e.stopPropagation();
              if (!mounted) return;
              const next = theme === 'dark' ? 'light' : 'dark';
              setTheme(next);
            }}
          >
            <img src={CoupaLogo} alt="Coupa" className="h-5 w-auto opacity-60 dark:invert-0 invert" />
            <span className="text-sm text-foreground/60 tracking-wide">Copilot</span>
          </HoverBorderGradient>
        </motion.div>

        {/* Hero */}
        <div className="text-center mt-auto mb-auto">
          <div className="space-y-3">
            {headlineWords.map((line, li) => (
              <h1
                key={li}
                className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extralight leading-relaxed tracking-tight"
              >
                {line.map((w, wi) => (
                  <span
                    key={wi}
                    className={`inline-block mr-[0.3em] pb-1 landing-word-appear hover:drop-shadow-[0_0_20px_rgba(203,213,225,0.5)] hover:-translate-y-0.5 transition-all duration-300 ${
                      li === 0
                        ? "bg-clip-text text-transparent bg-gradient-to-b from-foreground to-foreground/80"
                        : "bg-clip-text text-transparent bg-gradient-to-r from-blue-700 via-blue-600 to-blue-500 dark:from-foreground/60 dark:via-foreground/90 dark:to-foreground/60 drop-shadow-[0_0_25px_rgba(255,255,255,0.15)]"
                    }`}
                    style={{ animationDelay: `${w.delay}s` }}
                  >
                    {w.text}
                  </span>
                ))}
              </h1>
            ))}
          </div>

          <motion.div {...fadeUp(2.0)} className="mt-20 max-w-xl mx-auto px-4">
            <TypingEffect
              texts={[
                "Qual o status da minha requisição?",
                "Me mostre os contratos que vencem este mês",
                "Quais aprovações estão pendentes?",
                "Minha requisição já foi aprovada?",
              ]}
              className="text-sm sm:text-base md:text-lg text-foreground/50 font-light tracking-wide leading-relaxed [font-family:'Poppins',sans-serif]"
              typingSpeed={80}
              rotationInterval={2500}
            />
          </motion.div>

          <motion.div {...fadeUp(2.5)} className="mt-20">
            <button
              onClick={(e) => { e.stopPropagation(); navigate("/login"); }}
              role="link"
              aria-label="Acessar plataforma de login"
              className="inline-flex items-center gap-2 px-8 py-3 rounded-full text-white font-medium bg-gradient-to-r from-blue-600 to-blue-500 shadow-lg shadow-blue-500/25 border border-blue-400/30 hover:shadow-xl hover:shadow-blue-500/30 hover:scale-105 transition-all duration-300"
            >
              Acessar Plataforma
              <ArrowRight className="h-4 w-4" />
            </button>
          </motion.div>
        </div>

        {/* Footer */}
        <div className="w-full max-w-4xl mx-auto landing-corner-fade" style={{ animationDelay: "4.2s" }}>
          <div className="w-16 h-px bg-gradient-to-r from-transparent via-foreground/[0.15] to-transparent mx-auto mb-6" />
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-light text-foreground/40">Coupa Copilot</span>
              <span className="text-xs text-foreground/20">© 2025</span>
            </div>
            <div className="flex space-x-4">
              {[0.3, 0.5, 0.3].map((op, i) => (
                <div key={i} className="w-1 h-1 rounded-full bg-foreground/30" style={{ opacity: op }} />
              ))}
            </div>
            <span className="text-xs text-foreground/30">Hypera Pharma</span>
          </div>
        </div>
      </div>
    </div>
  );
}
