import { useState, useEffect, useCallback, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useUser } from "@/contexts/UserContext";
import { UserAvatar } from "@/components/UserAvatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Plus, Search, Users, Shield, UserCheck, UserX,
  MoreHorizontal, Pencil, Trash, Camera, X,
  AlertTriangle,
} from "lucide-react";
import { z } from "zod";

// ─── Types ────────────────────────────────────────────
interface Profile {
  id: string;
  full_name: string;
  email: string;
  avatar_url: string | null;
  area_id: string | null;
  job_title: string | null;
  role: string;
  is_active: boolean;
  last_sign_in_at: string | null;
  created_at: string;
  areas?: { name: string } | null;
}

interface Area {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  user_count?: number;
}

// ─── Validation ───────────────────────────────────────
const userFormSchema = z.object({
  full_name: z.string().trim().min(1, "Nome é obrigatório").max(200),
  email: z.string().trim().email("E-mail inválido").max(255),
  area_id: z.string().min(1, "Selecione uma área"),
  job_title: z.string().max(200).optional(),
  role: z.enum(["user", "admin"]),
});

const areaFormSchema = z.object({
  name: z.string().trim().min(1, "Nome é obrigatório").max(100),
  description: z.string().max(500).optional(),
});

// ─── Main Component ──────────────────────────────────
export default function UserManagement() {
  const { profile: currentUser, isAdmin } = useUser();
  const [tab, setTab] = useState("users");

  return (
    <div className="space-y-6">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="users">Usuários</TabsTrigger>
          <TabsTrigger value="areas">Áreas</TabsTrigger>
        </TabsList>
        <TabsContent value="users">
          <UsersTab currentUser={currentUser} />
        </TabsContent>
        <TabsContent value="areas">
          <AreasTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  USERS TAB
// ═══════════════════════════════════════════════════════
function UsersTab({ currentUser }: { currentUser: any }) {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [areas, setAreas] = useState<Area[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterArea, setFilterArea] = useState("all");
  const [filterRole, setFilterRole] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  // Sheet state
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Profile | null>(null);

  // Confirmation dialogs
  const [roleDialog, setRoleDialog] = useState<Profile | null>(null);
  const [statusDialog, setStatusDialog] = useState<Profile | null>(null);
  const [deleteDialog, setDeleteDialog] = useState<Profile | null>(null);
  const [deleteConfirmEmail, setDeleteConfirmEmail] = useState("");

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [profilesRes, areasRes] = await Promise.all([
      supabase.from("profiles").select("*, areas(name)").order("created_at", { ascending: false }),
      supabase.from("areas").select("*").eq("is_active", true).order("name"),
    ]);
    if (profilesRes.data) setProfiles(profilesRes.data as any);
    if (areasRes.data) setAreas(areasRes.data as any);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Counters
  const counts = useMemo(() => ({
    total: profiles.length,
    admins: profiles.filter(p => p.role === "admin").length,
    active: profiles.filter(p => p.is_active).length,
    inactive: profiles.filter(p => !p.is_active).length,
  }), [profiles]);

  // Filtered profiles
  const filtered = useMemo(() => {
    return profiles.filter(p => {
      const s = search.toLowerCase();
      if (s && !p.full_name.toLowerCase().includes(s) && !p.email.toLowerCase().includes(s)) return false;
      if (filterArea !== "all" && p.area_id !== filterArea) return false;
      if (filterRole !== "all" && p.role !== filterRole) return false;
      if (filterStatus === "active" && !p.is_active) return false;
      if (filterStatus === "inactive" && p.is_active) return false;
      return true;
    });
  }, [profiles, search, filterArea, filterRole, filterStatus]);

  // ─── Actions ──────────────────────────────────────
  const handleToggleRole = async () => {
    if (!roleDialog) return;
    const newRole = roleDialog.role === "admin" ? "user" : "admin";

    // Check last admin
    if (newRole === "user" && counts.admins <= 1) {
      toast.error("É necessário pelo menos um administrador no sistema");
      setRoleDialog(null);
      return;
    }

    // Update profiles.role
    const { error: profileError } = await supabase
      .from("profiles")
      .update({ role: newRole })
      .eq("id", roleDialog.id);

    if (profileError) { toast.error("Erro ao alterar permissão"); setRoleDialog(null); return; }

    // Sync user_roles
    if (newRole === "admin") {
      await supabase.from("user_roles").upsert({ user_id: roleDialog.id, role: "admin" as any });
    } else {
      await supabase.from("user_roles").delete().eq("user_id", roleDialog.id).eq("role", "admin" as any);
    }

    toast.success(`Permissão de ${roleDialog.full_name} alterada para ${newRole === "admin" ? "Administrador" : "Usuário"}`);
    setRoleDialog(null);
    fetchData();
  };

  const handleToggleStatus = async () => {
    if (!statusDialog) return;
    const newStatus = !statusDialog.is_active;
    const { error } = await supabase
      .from("profiles")
      .update({ is_active: newStatus })
      .eq("id", statusDialog.id);

    if (error) { toast.error("Erro ao alterar status"); setStatusDialog(null); return; }
    toast.success(`${statusDialog.full_name} foi ${newStatus ? "ativado" : "desativado"}`);
    setStatusDialog(null);
    fetchData();
  };

  const handleDelete = async () => {
    if (!deleteDialog) return;
    // Delete via edge function or admin API — for now delete profile
    const { error } = await supabase.from("profiles").delete().eq("id", deleteDialog.id);
    if (error) { toast.error("Erro ao excluir usuário"); setDeleteDialog(null); return; }
    toast.success(`${deleteDialog.full_name} foi excluído permanentemente`);
    setDeleteDialog(null);
    setDeleteConfirmEmail("");
    fetchData();
  };

  const openEdit = (user: Profile) => {
    setEditingUser(user);
    setSheetOpen(true);
  };

  const openNew = () => {
    setEditingUser(null);
    setSheetOpen(true);
  };

  return (
    <div className="space-y-6 mt-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Usuários</h1>
        <Button onClick={openNew} className="gap-2">
          <Plus className="h-4 w-4" /> Novo Usuário
        </Button>
      </div>

      {/* Counter cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <CounterCard icon={Users} label="Total de Usuários" value={counts.total} color="text-primary" />
        <CounterCard icon={Shield} label="Administradores" value={counts.admins} color="text-blue-600" />
        <CounterCard icon={UserCheck} label="Ativos" value={counts.active} color="text-emerald-600" />
        <CounterCard icon={UserX} label="Inativos" value={counts.inactive} color="text-destructive" />
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nome ou e-mail..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterArea} onValueChange={setFilterArea}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Área" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as áreas</SelectItem>
            {areas.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterRole} onValueChange={setFilterRole}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Permissão" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            <SelectItem value="admin">Administrador</SelectItem>
            <SelectItem value="user">Usuário</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[140px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="active">Ativo</SelectItem>
            <SelectItem value="inactive">Inativo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
      ) : filtered.length === 0 ? (
        <EmptyState
          isSearch={search.length > 0 || filterArea !== "all" || filterRole !== "all" || filterStatus !== "all"}
          onNew={openNew}
        />
      ) : (
        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Usuário</TableHead>
                <TableHead>E-mail</TableHead>
                <TableHead className="hidden md:table-cell">Área</TableHead>
                <TableHead className="hidden lg:table-cell">Cargo</TableHead>
                <TableHead>Permissão</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden lg:table-cell">Último Acesso</TableHead>
                <TableHead className="w-10" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(p => (
                <TableRow key={p.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <UserAvatar user={{ full_name: p.full_name, avatar_url: p.avatar_url, role: p.role }} size="sm" />
                      <span className="font-medium text-sm">{p.full_name || "—"}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{p.email}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm">{(p.areas as any)?.name || "—"}</TableCell>
                  <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">{p.job_title || "—"}</TableCell>
                  <TableCell>
                    <Badge variant={p.role === "admin" ? "default" : "secondary"} className={p.role === "admin" ? "bg-blue-100 text-blue-700 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400" : "bg-muted text-muted-foreground"}>
                      {p.role === "admin" ? "Admin" : "Usuário"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={p.is_active ? "default" : "destructive"} className={p.is_active ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-red-100 text-red-700 hover:bg-red-100 dark:bg-red-900/30 dark:text-red-400"}>
                      {p.is_active ? "Ativo" : "Inativo"}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                    {p.last_sign_in_at ? formatDistanceToNow(new Date(p.last_sign_in_at), { addSuffix: true, locale: ptBR }) : "Nunca"}
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEdit(p)}>
                          <Pencil className="h-4 w-4 mr-2" /> Editar
                        </DropdownMenuItem>
                        {currentUser?.id !== p.id && (
                          <DropdownMenuItem onClick={() => setRoleDialog(p)}>
                            <Shield className="h-4 w-4 mr-2" />
                            {p.role === "admin" ? "Remover Admin" : "Tornar Admin"}
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        {currentUser?.id !== p.id && (
                          <DropdownMenuItem onClick={() => setStatusDialog(p)}>
                            {p.is_active ? <UserX className="h-4 w-4 mr-2" /> : <UserCheck className="h-4 w-4 mr-2" />}
                            {p.is_active ? "Desativar" : "Ativar"}
                          </DropdownMenuItem>
                        )}
                        {currentUser?.id !== p.id && (
                          <DropdownMenuItem onClick={() => setDeleteDialog(p)} className="text-destructive focus:text-destructive">
                            <Trash className="h-4 w-4 mr-2" /> Excluir
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Sheet: Create/Edit User */}
      <UserFormSheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        editingUser={editingUser}
        areas={areas}
        onSuccess={() => { setSheetOpen(false); fetchData(); }}
      />

      {/* Dialog: Toggle Role */}
      <AlertDialog open={!!roleDialog} onOpenChange={() => setRoleDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Alterar permissão</AlertDialogTitle>
            <AlertDialogDescription>
              {roleDialog?.role === "admin"
                ? <>Deseja remover a permissão de administrador de <strong>{roleDialog?.full_name}</strong>?</>
                : <>Deseja tornar <strong>{roleDialog?.full_name}</strong> administrador?</>}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleToggleRole}>Confirmar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog: Toggle Status */}
      <AlertDialog open={!!statusDialog} onOpenChange={() => setStatusDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{statusDialog?.is_active ? "Desativar usuário" : "Ativar usuário"}</AlertDialogTitle>
            <AlertDialogDescription>
              {statusDialog?.is_active
                ? <>Deseja desativar <strong>{statusDialog?.full_name}</strong>? Ele não poderá mais acessar a plataforma, mas seu histórico será preservado.</>
                : <>Deseja reativar <strong>{statusDialog?.full_name}</strong>? Ele poderá acessar a plataforma novamente.</>}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleToggleStatus}
              className={statusDialog?.is_active ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : ""}
            >
              {statusDialog?.is_active ? "Desativar" : "Ativar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog: Delete User */}
      <AlertDialog open={!!deleteDialog} onOpenChange={() => { setDeleteDialog(null); setDeleteConfirmEmail(""); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Excluir usuário permanentemente
            </AlertDialogTitle>
            <AlertDialogDescription>
              Atenção: Esta ação é irreversível. Todos os dados e histórico de <strong>{deleteDialog?.full_name}</strong> serão excluídos permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="px-1">
            <Label className="text-sm text-muted-foreground">Digite o e-mail do usuário para confirmar</Label>
            <Input
              placeholder={deleteDialog?.email}
              value={deleteConfirmEmail}
              onChange={e => setDeleteConfirmEmail(e.target.value)}
              className="mt-1"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleteConfirmEmail !== deleteDialog?.email}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir permanentemente
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ─── Counter Card ─────────────────────────────────────
function CounterCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: number; color: string }) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-4">
        <div className={`h-10 w-10 rounded-lg bg-muted flex items-center justify-center ${color}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <p className="text-2xl font-bold text-foreground">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Empty State ──────────────────────────────────────
function EmptyState({ isSearch, onNew }: { isSearch: boolean; onNew: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {isSearch ? (
        <>
          <Search className="h-12 w-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-semibold text-foreground">Nenhum usuário encontrado</h3>
          <p className="text-sm text-muted-foreground mt-1">Tente ajustar os filtros ou o termo de busca</p>
        </>
      ) : (
        <>
          <Users className="h-12 w-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-semibold text-foreground">Nenhum usuário cadastrado</h3>
          <p className="text-sm text-muted-foreground mt-1">Clique em 'Novo Usuário' para adicionar o primeiro</p>
          <Button onClick={onNew} className="mt-4 gap-2"><Plus className="h-4 w-4" /> Novo Usuário</Button>
        </>
      )}
    </div>
  );
}

// ─── User Form Sheet ──────────────────────────────────
function UserFormSheet({
  open, onOpenChange, editingUser, areas, onSuccess,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editingUser: Profile | null;
  areas: Area[];
  onSuccess: () => void;
}) {
  const [form, setForm] = useState({ full_name: "", email: "", area_id: "", job_title: "", role: "user" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [removeAvatar, setRemoveAvatar] = useState(false);

  useEffect(() => {
    if (open) {
      if (editingUser) {
        setForm({
          full_name: editingUser.full_name,
          email: editingUser.email,
          area_id: editingUser.area_id || "",
          job_title: editingUser.job_title || "",
          role: editingUser.role,
        });
        setAvatarPreview(editingUser.avatar_url);
      } else {
        setForm({ full_name: "", email: "", area_id: "", job_title: "", role: "user" });
        setAvatarPreview(null);
      }
      setAvatarFile(null);
      setRemoveAvatar(false);
      setErrors({});
    }
  }, [open, editingUser]);

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const validTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) {
      toast.error("Formato não suportado. Use JPG, PNG ou WebP");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error("A imagem deve ter no máximo 2MB");
      return;
    }
    setAvatarFile(file);
    setRemoveAvatar(false);
    setAvatarPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async () => {
    const result = userFormSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach(i => { fieldErrors[String(i.path[0])] = i.message; });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSaving(true);

    try {
      let avatarUrl = editingUser?.avatar_url || null;

      // Upload avatar if changed
      if (avatarFile) {
        const userId = editingUser?.id || crypto.randomUUID();
        const ext = avatarFile.name.split(".").pop();
        const path = `${editingUser?.id || userId}/${Date.now()}.${ext}`;
        const { error: uploadErr } = await supabase.storage.from("avatars").upload(path, avatarFile, { upsert: true });
        if (uploadErr) throw uploadErr;
        const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(path);
        avatarUrl = urlData.publicUrl;
      } else if (removeAvatar) {
        avatarUrl = null;
      }

      if (editingUser) {
        // Update
        const { error } = await supabase.from("profiles").update({
          full_name: form.full_name,
          email: form.email,
          area_id: form.area_id || null,
          job_title: form.job_title || null,
          role: form.role,
          avatar_url: avatarUrl,
        }).eq("id", editingUser.id);

        if (error) {
          if (error.message?.includes("duplicate") || error.code === "23505") {
            setErrors({ email: "Já existe um usuário com este e-mail" });
            return;
          }
          throw error;
        }

        // Sync user_roles if role changed
        if (editingUser.role !== form.role) {
          if (form.role === "admin") {
            await supabase.from("user_roles").upsert({ user_id: editingUser.id, role: "admin" as any });
          } else {
            await supabase.from("user_roles").delete().eq("user_id", editingUser.id).eq("role", "admin" as any);
          }
        }

        toast.success("Usuário atualizado com sucesso");
      } else {
        // Create user via edge function (uses auth.admin.createUser)
        const { data, error } = await supabase.functions.invoke("manage-users", {
          body: {
            action: "create",
            full_name: form.full_name,
            email: form.email,
            area_id: form.area_id || null,
            job_title: form.job_title || null,
            role: form.role,
            avatar_url: avatarUrl,
          },
        });

        if (error) throw error;

        const result = data as any;
        if (result?.error) {
          if (result.error.includes("e-mail") || result.error.includes("email")) {
            setErrors({ email: result.error });
            return;
          }
          throw new Error(result.error);
        }

        toast.success("Usuário criado com sucesso");
      }

      onSuccess();
    } catch (err: any) {
      toast.error(err.message || "Erro ao salvar usuário");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle>{editingUser ? "Editar Usuário" : "Novo Usuário"}</SheetTitle>
        </SheetHeader>

        <div className="space-y-6 py-6">
          {/* Avatar upload */}
          <div className="flex flex-col items-center gap-3">
            <label className="relative cursor-pointer group">
              <div className="h-[120px] w-[120px] rounded-full bg-muted flex items-center justify-center overflow-hidden border-2 border-dashed border-border group-hover:border-primary transition-colors">
                {avatarPreview ? (
                  <>
                    <img src={avatarPreview} alt="Preview" className="h-full w-full object-cover" />
                    <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Camera className="h-6 w-6 text-white" />
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center gap-1 text-muted-foreground">
                    <Camera className="h-6 w-6" />
                    <span className="text-xs">Adicionar foto</span>
                  </div>
                )}
              </div>
              <input type="file" className="hidden" accept=".jpg,.jpeg,.png,.webp" onChange={handleAvatarChange} />
            </label>
            {avatarPreview && editingUser && (
              <button
                type="button"
                onClick={() => { setAvatarPreview(null); setAvatarFile(null); setRemoveAvatar(true); }}
                className="text-xs text-destructive hover:underline"
              >
                Remover foto
              </button>
            )}
          </div>

          {/* Fields */}
          <div className="space-y-4">
            <div>
              <Label>Nome completo *</Label>
              <Input
                placeholder="Nome completo do usuário"
                value={form.full_name}
                onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))}
                className={errors.full_name ? "border-destructive" : ""}
              />
              {errors.full_name && <p className="text-xs text-destructive mt-1">{errors.full_name}</p>}
            </div>

            <div>
              <Label>E-mail *</Label>
              <Input
                type="email"
                placeholder="email@empresa.com"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                className={errors.email ? "border-destructive" : ""}
              />
              {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
            </div>

            <div>
              <Label>Área *</Label>
              <Select value={form.area_id} onValueChange={v => setForm(f => ({ ...f, area_id: v }))}>
                <SelectTrigger className={errors.area_id ? "border-destructive" : ""}>
                  <SelectValue placeholder="Selecione a área" />
                </SelectTrigger>
                <SelectContent>
                  {areas.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                </SelectContent>
              </Select>
              {errors.area_id && <p className="text-xs text-destructive mt-1">{errors.area_id}</p>}
            </div>

            <div>
              <Label>Cargo/Função</Label>
              <Input
                placeholder="Ex: Analista, Coordenador, Gerente"
                value={form.job_title}
                onChange={e => setForm(f => ({ ...f, job_title: e.target.value }))}
              />
            </div>

            <div>
              <Label>Permissão *</Label>
              <Select value={form.role} onValueChange={v => setForm(f => ({ ...f, role: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Usuário</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <SheetFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSubmit} disabled={saving}>
            {saving ? "Salvando..." : editingUser ? "Salvar Alterações" : "Criar Usuário"}
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

// ═══════════════════════════════════════════════════════
//  AREAS TAB
// ═══════════════════════════════════════════════════════
function AreasTab() {
  const [areas, setAreas] = useState<(Area & { user_count: number })[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<Area | null>(null);
  const [form, setForm] = useState({ name: "", description: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [deactivateDialog, setDeactivateDialog] = useState<(Area & { user_count: number }) | null>(null);

  const fetchAreas = useCallback(async () => {
    setLoading(true);
    const { data: areasData } = await supabase.from("areas").select("*").order("name");
    if (!areasData) { setLoading(false); return; }

    // Count users per area
    const { data: profilesData } = await supabase.from("profiles").select("area_id");
    const countMap: Record<string, number> = {};
    profilesData?.forEach(p => { if (p.area_id) countMap[p.area_id] = (countMap[p.area_id] || 0) + 1; });

    setAreas(areasData.map(a => ({ ...a, user_count: countMap[a.id] || 0 })) as any);
    setLoading(false);
  }, []);

  useEffect(() => { fetchAreas(); }, [fetchAreas]);

  const openNew = () => { setEditingArea(null); setForm({ name: "", description: "" }); setErrors({}); setDialogOpen(true); };
  const openEdit = (area: Area) => {
    setEditingArea(area);
    setForm({ name: area.name, description: area.description || "" });
    setErrors({});
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    const result = areaFormSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach(i => { fieldErrors[String(i.path[0])] = i.message; });
      setErrors(fieldErrors);
      return;
    }
    setSaving(true);

    try {
      if (editingArea) {
        const { error } = await supabase.from("areas").update({ name: form.name, description: form.description || null }).eq("id", editingArea.id);
        if (error) {
          if (error.code === "23505") { setErrors({ name: "Já existe uma área com este nome" }); return; }
          throw error;
        }
        toast.success("Área atualizada");
      } else {
        const { error } = await supabase.from("areas").insert({ name: form.name, description: form.description || null });
        if (error) {
          if (error.code === "23505") { setErrors({ name: "Já existe uma área com este nome" }); return; }
          throw error;
        }
        toast.success("Área criada");
      }
      setDialogOpen(false);
      fetchAreas();
    } catch (err: any) {
      toast.error(err.message || "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (area: Area & { user_count: number }) => {
    if (area.is_active && area.user_count > 0) {
      setDeactivateDialog(area);
      return;
    }
    await toggleArea(area);
  };

  const toggleArea = async (area: Area) => {
    const { error } = await supabase.from("areas").update({ is_active: !area.is_active }).eq("id", area.id);
    if (error) { toast.error("Erro ao alterar status"); return; }
    toast.success(`Área ${!area.is_active ? "ativada" : "desativada"}`);
    setDeactivateDialog(null);
    fetchAreas();
  };

  return (
    <div className="space-y-6 mt-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Áreas</h1>
        <Button onClick={openNew} className="gap-2"><Plus className="h-4 w-4" /> Nova Área</Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
      ) : areas.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Users className="h-12 w-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-semibold">Nenhuma área cadastrada</h3>
          <Button onClick={openNew} className="mt-4 gap-2"><Plus className="h-4 w-4" /> Nova Área</Button>
        </div>
      ) : (
        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Usuários</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-10" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {areas.map(a => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">{a.name}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{a.description || "—"}</TableCell>
                  <TableCell>{a.user_count}</TableCell>
                  <TableCell>
                    <Badge variant={a.is_active ? "default" : "secondary"} className={a.is_active ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-900/30 dark:text-emerald-400" : ""}>
                      {a.is_active ? "Ativa" : "Inativa"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEdit(a)}><Pencil className="h-4 w-4 mr-2" /> Editar</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleToggleActive(a)}>
                          {a.is_active ? <UserX className="h-4 w-4 mr-2" /> : <UserCheck className="h-4 w-4 mr-2" />}
                          {a.is_active ? "Desativar" : "Ativar"}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Dialog: Create/Edit Area */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingArea ? "Editar Área" : "Nova Área"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Nome *</Label>
              <Input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Nome da área"
                className={errors.name ? "border-destructive" : ""}
              />
              {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
            </div>
            <div>
              <Label>Descrição</Label>
              <Textarea
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Descrição opcional"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSubmit} disabled={saving}>
              {saving ? "Salvando..." : editingArea ? "Salvar" : "Criar Área"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Alert: Deactivate area with users */}
      <AlertDialog open={!!deactivateDialog} onOpenChange={() => setDeactivateDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Desativar área</AlertDialogTitle>
            <AlertDialogDescription>
              Esta área possui <strong>{deactivateDialog?.user_count}</strong> usuários vinculados.
              Ao desativá-la, ela não aparecerá mais como opção para novos cadastros, mas os usuários atuais manterão sua área até serem editados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deactivateDialog && toggleArea(deactivateDialog)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Desativar mesmo assim
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
