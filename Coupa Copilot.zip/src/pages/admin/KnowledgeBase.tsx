import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Loader2, Trash2, RefreshCw, Globe, FileText,
  CheckCircle2, XCircle, ClipboardPaste, Upload,
  AlertTriangle, FileUp, Info, Eye, Database, BarChart3,
  Save, Sparkles, Pencil,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import * as XLSX from "xlsx";

interface KnowledgeSource {
  id: string;
  url: string;
  title: string | null;
  status: string;
  source_type: string;
  created_at: string;
  last_crawled_at: string | null;
  raw_content: string | null;
  knowledge_chunks: { count: number }[];
}

const ACCEPTED_FILE_TYPES = ".txt,.md,.csv,.pdf,.xlsx,.xls,.json";
const MAX_FILE_SIZE = 20 * 1024 * 1024; // 20MB
const BATCH_SIZE = 300_000; // chars per batch — safe for edge function body limit
const PDF_PAGES_PER_PART = 15; // pages per independent source for PDFs

interface PdfPageData {
  pageNum: number;
  text: string;
}

interface PdfExtraction {
  pages: PdfPageData[];
  totalPages: number;
  pagesWithText: number;
  pagesEmpty: number;
  totalChars: number;
}

export default function KnowledgeBase() {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // URL scrape
  const [url, setUrl] = useState("");
  const [urlTitle, setUrlTitle] = useState("");
  const [scraping, setScraping] = useState(false);

  // Manual paste
  const [manualContent, setManualContent] = useState("");
  const [manualTitle, setManualTitle] = useState("");
  const [manualUrl, setManualUrl] = useState("");
  const [indexingManual, setIndexingManual] = useState(false);

  // File upload
  const [fileTitle, setFileTitle] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  // Upload progress
  interface UploadProgress {
    phase: "extracting" | "uploading" | "done" | "error";
    message: string;
    currentPart: number;
    totalParts: number;
    totalPages?: number;
    pagesWithText?: number;
    pagesEmpty?: number;
    totalChars?: number;
    failedParts: number[];
    successCount: number;
  }
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null);

  // Sources
  const [sources, setSources] = useState<KnowledgeSource[]>([]);
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Preview / Chunk Editor
  const [previewSource, setPreviewSource] = useState<KnowledgeSource | null>(null);
  const [chunks, setChunks] = useState<{ id: string; content: string; chunk_index: number; metadata: any }[]>([]);
  const [loadingChunks, setLoadingChunks] = useState(false);
  const [editedChunks, setEditedChunks] = useState<Record<string, string>>({});
  const [savingChunkId, setSavingChunkId] = useState<string | null>(null);
  const [formattingChunkId, setFormattingChunkId] = useState<string | null>(null);

  const loadSources = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "list" },
      });
      if (error) throw error;
      if (data?.sources) setSources(data.sources);
    } catch (err) {
      console.error("Failed to load sources:", err);
      toast.error("Falha ao carregar fontes");
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { loadSources(); }, [loadSources]);

  // Stats
  const totalSources = sources.length;
  const totalChunks = sources.reduce((acc, s) => acc + (s.knowledge_chunks?.[0]?.count ?? 0), 0);
  const activeSources = sources.filter((s) => s.status === "active").length;

  // === URL Scrape ===
  const handleScrape = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    setScraping(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { url: url.trim(), title: urlTitle.trim() || undefined },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(`"${data.title}" — ${data.chunks_indexed} chunks`);
        setUrl(""); setUrlTitle("");
        loadSources();
      } else throw new Error(data?.error || "Erro desconhecido");
    } catch (err: any) {
      toast.error(`Erro no scraping: ${err.message}`);
    } finally { setScraping(false); }
  };

  // === Manual Paste ===
  const handleManualIndex = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualContent.trim() || manualContent.trim().length < 20) {
      toast.error("Mínimo de 20 caracteres");
      return;
    }
    if (!manualTitle.trim()) {
      toast.error("Título é obrigatório");
      return;
    }
    setIndexingManual(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "manual-index", content: manualContent.trim(), title: manualTitle.trim(), url: manualUrl.trim() || undefined },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(`"${data.title}" — ${data.chunks_indexed} chunks`);
        setManualContent(""); setManualTitle(""); setManualUrl("");
        loadSources();
      } else throw new Error(data?.error || "Erro desconhecido");
    } catch (err: any) {
      toast.error(`Erro ao indexar: ${err.message}`);
    } finally { setIndexingManual(false); }
  };

  // === File helpers ===
  const readFileAsText = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error("Falha ao ler arquivo"));
      reader.readAsText(file);
    });

  const extractPdfByPages = async (file: File): Promise<PdfExtraction> => {
    const [{ getDocument, GlobalWorkerOptions }, workerModule] = await Promise.all([
      import("pdfjs-dist"),
      import("pdfjs-dist/build/pdf.worker.min.mjs?url"),
    ]);

    GlobalWorkerOptions.workerSrc = workerModule.default;

    const fileData = new Uint8Array(await file.arrayBuffer());
    const pdf = await getDocument({ data: fileData }).promise;
    const pages: PdfPageData[] = [];
    let pagesWithText = 0;
    let pagesEmpty = 0;
    let totalChars = 0;

    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
      const page = await pdf.getPage(pageNumber);
      const textContent = await page.getTextContent();

      // Preserve structure: group items by approximate Y position for line breaks
      const items = textContent.items.filter((item: any) => "str" in item && !!item.str);

      let pageText = "";
      if (items.length > 0) {
        let lastY: number | null = null;
        const lines: string[] = [];
        let currentLine = "";

        for (const item of items) {
          const anyItem = item as any;
          const y = Math.round(anyItem.transform[5]); // Y coordinate
          if (lastY !== null && Math.abs(y - lastY) > 3) {
            // New line detected
            if (currentLine.trim()) lines.push(currentLine.trim());
            currentLine = anyItem.str;
          } else {
            // Same line - check if we need a space
            if (currentLine && !currentLine.endsWith(" ") && !anyItem.str.startsWith(" ")) {
              currentLine += " ";
            }
            currentLine += anyItem.str;
          }
          lastY = y;
        }
        if (currentLine.trim()) lines.push(currentLine.trim());
        pageText = lines.join("\n");
      }

      // Clean up excessive blank lines but keep structure
      pageText = pageText.replace(/\n{3,}/g, "\n\n").trim();

      pages.push({ pageNum: pageNumber, text: pageText });

      if (pageText.length > 10) {
        pagesWithText++;
        totalChars += pageText.length;
      } else {
        pagesEmpty++;
      }
    }

    return { pages, totalPages: pdf.numPages, pagesWithText, pagesEmpty, totalChars };
  };

  const readExcelAsText = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = new Uint8Array(reader.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const texts: string[] = [];
          workbook.SheetNames.forEach((name) => {
            const sheet = workbook.Sheets[name];
            const csv = XLSX.utils.sheet_to_csv(sheet);
            texts.push(`## Aba: ${name}\n${csv}`);
          });
          resolve(texts.join("\n\n"));
        } catch {
          reject(new Error("Falha ao processar planilha"));
        }
      };
      reader.onerror = () => reject(new Error("Falha ao ler arquivo"));
      reader.readAsArrayBuffer(file);
    });

  const readJsonAsText = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(reader.result as string);
          resolve(JSON.stringify(parsed, null, 2));
        } catch {
          reject(new Error("JSON inválido"));
        }
      };
      reader.onerror = () => reject(new Error("Falha ao ler arquivo"));
      reader.readAsText(file);
    });

  const handleFileSelect = (file: File) => {
    if (file.size > MAX_FILE_SIZE) {
      toast.error("Arquivo muito grande. Máximo: 20MB");
      return;
    }
    const ext = file.name.split(".").pop()?.toLowerCase();
    const allowed = ["txt", "md", "csv", "pdf", "xlsx", "xls", "json"];
    if (!allowed.includes(ext || "")) {
      toast.error(`Formato inválido. Aceitos: ${allowed.join(", ")}`);
      return;
    }
    if (ext === "pdf") {
      toast.info("PDF detectado — vamos extrair o texto automaticamente antes da indexação.");
    }
    setSelectedFile(file);
    if (!fileTitle.trim()) setFileTitle(file.name.replace(/\.[^.]+$/, ""));
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile || !fileTitle.trim()) return;
    setUploadingFile(true);
    setUploadProgress({ phase: "extracting", message: "Preparando arquivo...", currentPart: 0, totalParts: 0, failedParts: [], successCount: 0 });
    try {
      const ext = selectedFile.name.split(".").pop()?.toLowerCase();

      // === PDF: page-based extraction & partitioning ===
      if (ext === "pdf") {
        setUploadProgress(prev => prev ? { ...prev, message: "Extraindo texto do PDF..." } : prev);
        const extraction = await extractPdfByPages(selectedFile);

        if (extraction.totalChars < 20) {
          setUploadProgress({ phase: "error", message: `PDF sem texto extraível (${extraction.pagesEmpty} páginas vazias de ${extraction.totalPages}). Pode ser um PDF escaneado.`, currentPart: 0, totalParts: 0, failedParts: [], successCount: 0 });
          return;
        }

        setUploadProgress(prev => prev ? {
          ...prev,
          message: "Extração concluída. Preparando envio...",
          totalPages: extraction.totalPages,
          pagesWithText: extraction.pagesWithText,
          pagesEmpty: extraction.pagesEmpty,
          totalChars: extraction.totalChars,
        } : prev);

        // Split pages into blocks of PDF_PAGES_PER_PART
        const pageBlocks: PdfPageData[][] = [];
        for (let i = 0; i < extraction.pages.length; i += PDF_PAGES_PER_PART) {
          pageBlocks.push(extraction.pages.slice(i, i + PDF_PAGES_PER_PART));
        }

        // Further split blocks that exceed BATCH_SIZE
        const finalParts: { content: string; pageStart: number; pageEnd: number }[] = [];
        for (const block of pageBlocks) {
          const blockText = block
            .filter(p => p.text.length > 0)
            .map(p => `--- Página ${p.pageNum} ---\n${p.text}`)
            .join("\n\n");

          if (blockText.length <= BATCH_SIZE) {
            finalParts.push({
              content: blockText,
              pageStart: block[0].pageNum,
              pageEnd: block[block.length - 1].pageNum,
            });
          } else {
            // Rare case: split the block text by chars
            for (let i = 0; i < blockText.length; i += BATCH_SIZE) {
              finalParts.push({
                content: blockText.substring(i, i + BATCH_SIZE),
                pageStart: block[0].pageNum,
                pageEnd: block[block.length - 1].pageNum,
              });
            }
          }
        }

        const totalParts = finalParts.length;
        let successCount = 0;
        const failedParts: number[] = [];

        setUploadProgress(prev => prev ? { ...prev, phase: "uploading", totalParts, currentPart: 0, message: `Enviando 0/${totalParts}...` } : prev);

        for (let p = 0; p < totalParts; p++) {
          const part = finalParts[p];
          const partTitle = totalParts > 1
            ? `${fileTitle.trim()} — Parte ${p + 1} de ${totalParts} (pág. ${part.pageStart}-${part.pageEnd})`
            : fileTitle.trim();
          const partFilename = totalParts > 1
            ? `${selectedFile.name}_parte_${p + 1}`
            : selectedFile.name;

          setUploadProgress(prev => prev ? { ...prev, currentPart: p + 1, message: `Enviando parte ${p + 1}/${totalParts} (pág. ${part.pageStart}-${part.pageEnd})...` } : prev);

          try {
            const { data, error } = await supabase.functions.invoke("scrape-docs", {
              body: {
                action: "file-index",
                content: part.content,
                title: partTitle,
                filename: partFilename,
                source_type: "pdf",
                metadata: {
                  page_start: part.pageStart,
                  page_end: part.pageEnd,
                  total_pages: extraction.totalPages,
                  total_parts: totalParts,
                  part_number: p + 1,
                  pages_with_text: extraction.pagesWithText,
                  pages_empty: extraction.pagesEmpty,
                },
              },
            });
            if (error) throw error;
            if (!data?.success) throw new Error(data?.error || "Erro desconhecido");
            successCount++;
            setUploadProgress(prev => prev ? { ...prev, successCount } : prev);
          } catch (partErr: any) {
            console.error(`Falha na parte ${p + 1}:`, partErr);
            failedParts.push(p + 1);
            setUploadProgress(prev => prev ? { ...prev, failedParts: [...prev.failedParts, p + 1] } : prev);
          }
        }

        if (failedParts.length > 0) {
          setUploadProgress(prev => prev ? { ...prev, phase: "error", message: `${successCount}/${totalParts} partes indexadas. Falha nas partes: ${failedParts.join(", ")}.`, successCount, failedParts } : prev);
        } else {
          setUploadProgress(prev => prev ? { ...prev, phase: "done", message: `PDF indexado com sucesso! ${totalParts} parte(s) • ${extraction.totalPages} páginas`, successCount } : prev);
        }

      } else {
        // === Non-PDF files: char-based partitioning ===
        let content: string;
        let sourceType = "file";

        if (ext === "xlsx" || ext === "xls") {
          content = await readExcelAsText(selectedFile);
          sourceType = "excel";
        } else if (ext === "json") {
          content = await readJsonAsText(selectedFile);
          sourceType = "json";
        } else {
          content = await readFileAsText(selectedFile);
        }

        const normalizedContent = content.trim();
        if (!normalizedContent || normalizedContent.length < 20) {
          setUploadProgress({ phase: "error", message: "Arquivo sem conteúdo suficiente (mín. 20 caracteres)", currentPart: 0, totalParts: 0, failedParts: [], successCount: 0 });
          return;
        }

        const parts: string[] = [];
        if (normalizedContent.length <= BATCH_SIZE) {
          parts.push(normalizedContent);
        } else {
          for (let i = 0; i < normalizedContent.length; i += BATCH_SIZE) {
            parts.push(normalizedContent.substring(i, i + BATCH_SIZE));
          }
        }

        const totalParts = parts.length;
        let successCount = 0;
        const failedParts: number[] = [];

        setUploadProgress(prev => prev ? { ...prev, phase: "uploading", totalParts, currentPart: 0, message: totalParts > 1 ? `Enviando 0/${totalParts}...` : "Enviando arquivo..." } : prev);

        for (let p = 0; p < totalParts; p++) {
          const partTitle = totalParts > 1
            ? `${fileTitle.trim()} — Parte ${p + 1} de ${totalParts}`
            : fileTitle.trim();
          const partFilename = totalParts > 1
            ? `${selectedFile.name}_parte_${p + 1}`
            : selectedFile.name;

          if (totalParts > 1) {
            setUploadProgress(prev => prev ? { ...prev, currentPart: p + 1, message: `Enviando parte ${p + 1}/${totalParts}...` } : prev);
          } else {
            setUploadProgress(prev => prev ? { ...prev, currentPart: 1, message: "Indexando arquivo..." } : prev);
          }

          try {
            const { data, error } = await supabase.functions.invoke("scrape-docs", {
              body: {
                action: "file-index",
                content: parts[p],
                title: partTitle,
                filename: partFilename,
                source_type: sourceType,
              },
            });
            if (error) throw error;
            if (!data?.success) throw new Error(data?.error || "Erro desconhecido");
            successCount++;
            setUploadProgress(prev => prev ? { ...prev, successCount } : prev);
          } catch (partErr: any) {
            console.error(`Falha na parte ${p + 1}:`, partErr);
            failedParts.push(p + 1);
            setUploadProgress(prev => prev ? { ...prev, failedParts: [...prev.failedParts, p + 1] } : prev);
          }
        }

        if (failedParts.length > 0) {
          setUploadProgress(prev => prev ? { ...prev, phase: "error", message: `${successCount}/${totalParts} partes indexadas. Falha nas partes: ${failedParts.join(", ")}`, successCount, failedParts } : prev);
        } else {
          setUploadProgress(prev => prev ? { ...prev, phase: "done", message: `Arquivo indexado com sucesso! ${totalParts} parte(s)`, successCount } : prev);
        }
      }

      setSelectedFile(null); setFileTitle("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      loadSources();
    } catch (err: any) {
      setUploadProgress(prev => prev ? { ...prev, phase: "error", message: err.message } : { phase: "error", message: err.message, currentPart: 0, totalParts: 0, failedParts: [], successCount: 0 });
    } finally { setUploadingFile(false); }
  };

  const handleDelete = async (sourceId: string) => {
    setDeletingId(sourceId);
    try {
      await supabase.functions.invoke("scrape-docs", { body: { action: "delete", source_id: sourceId } });
      toast.success("Fonte removida");
      loadSources();
    } catch (err: any) {
      toast.error(`Erro ao deletar: ${err.message}`);
    } finally { setDeletingId(null); }
  };

  const estimateChunks = (text: string) => {
    const words = text.trim().split(/\s+/).filter(Boolean).length;
    return Math.max(1, Math.ceil(words / 450));
  };

  // === Chunk Editor ===
  const openChunkEditor = async (source: KnowledgeSource) => {
    setPreviewSource(source);
    setChunks([]);
    setEditedChunks({});
    setLoadingChunks(true);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "list-chunks", source_id: source.id },
      });
      if (error) throw error;
      setChunks(data?.chunks || []);
    } catch (err: any) {
      toast.error(`Erro ao carregar chunks: ${err.message}`);
    } finally {
      setLoadingChunks(false);
    }
  };

  const handleSaveChunk = async (chunkId: string) => {
    const content = editedChunks[chunkId];
    if (!content) return;
    setSavingChunkId(chunkId);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "update-chunk", chunk_id: chunkId, content },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error);
      setChunks(prev => prev.map(c => c.id === chunkId ? { ...c, content } : c));
      setEditedChunks(prev => { const n = { ...prev }; delete n[chunkId]; return n; });
      toast.success("Chunk salvo!");
    } catch (err: any) {
      toast.error(`Erro ao salvar: ${err.message}`);
    } finally { setSavingChunkId(null); }
  };

  const handleFormatChunk = async (chunkId: string) => {
    setFormattingChunkId(chunkId);
    try {
      const { data, error } = await supabase.functions.invoke("scrape-docs", {
        body: { action: "format-chunk-single", chunk_id: chunkId },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || "Formatação rejeitada");
      const formatted = data.formatted_content;
      setChunks(prev => prev.map(c => c.id === chunkId ? { ...c, content: formatted } : c));
      setEditedChunks(prev => { const n = { ...prev }; delete n[chunkId]; return n; });
      toast.success("Chunk formatado!");
    } catch (err: any) {
      toast.error(`Erro na formatação: ${err.message}`);
    } finally { setFormattingChunkId(null); }
  };

  const getSourceTypeLabel = (type: string) => {
    const map: Record<string, { label: string; variant: "default" | "secondary" | "outline" }> = {
      manual: { label: "Manual", variant: "secondary" },
      file: { label: "Arquivo", variant: "outline" },
      pdf: { label: "PDF", variant: "outline" },
      excel: { label: "Excel", variant: "outline" },
      json: { label: "JSON", variant: "outline" },
      compass_docs: { label: "URL", variant: "default" },
    };
    return map[type] || { label: type, variant: "default" as const };
  };

  const getStatusIcon = (status: string) => {
    if (status === "active") return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    if (status === "error") return <XCircle className="h-4 w-4 text-destructive" />;
    return <Loader2 className="h-4 w-4 animate-spin text-yellow-500" />;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Base de Conhecimento</h1>
        <p className="text-sm text-muted-foreground mt-1">Gerencie o conteúdo usado pelo assistente para responder perguntas.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="p-2 rounded-lg bg-primary/10"><Database className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-2xl font-bold">{totalSources}</p>
              <p className="text-xs text-muted-foreground">Fontes ({activeSources} ativas)</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="p-2 rounded-lg bg-primary/10"><BarChart3 className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-2xl font-bold">{totalChunks}</p>
              <p className="text-xs text-muted-foreground">Chunks indexados</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="p-2 rounded-lg bg-primary/10"><RefreshCw className="h-5 w-5 text-primary" /></div>
            <div>
              <p className="text-2xl font-bold">
                {sources.length > 0
                  ? new Date(Math.max(...sources.filter(s => s.last_crawled_at).map(s => new Date(s.last_crawled_at!).getTime()))).toLocaleDateString("pt-BR")
                  : "—"}
              </p>
              <p className="text-xs text-muted-foreground">Última atualização</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ingestion Tabs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Adicionar Conteúdo</CardTitle>
          <CardDescription>Escolha o método de ingestão para adicionar documentação à base.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="url">
            <TabsList className="mb-4">
              <TabsTrigger value="url" className="gap-1.5"><Globe className="h-4 w-4" /> URL</TabsTrigger>
              <TabsTrigger value="paste" className="gap-1.5"><ClipboardPaste className="h-4 w-4" /> Colar</TabsTrigger>
              <TabsTrigger value="upload" className="gap-1.5"><Upload className="h-4 w-4" /> Upload</TabsTrigger>
            </TabsList>

            {/* URL Tab */}
            <TabsContent value="url">
              <div className="flex items-start gap-2 mb-4 p-3 rounded-md bg-muted border border-border">
                <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-400 mt-0.5 shrink-0" />
                <p className="text-xs text-muted-foreground">
                  Funciona apenas com páginas públicas. Para páginas protegidas por SSO (ex: Compass), use <strong>Colar</strong> ou <strong>Upload</strong>.
                </p>
              </div>
              <form onSubmit={handleScrape} className="space-y-3 max-w-lg">
                <Input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/docs/..." required disabled={scraping} />
                <Input value={urlTitle} onChange={(e) => setUrlTitle(e.target.value)} placeholder="Título (opcional)" disabled={scraping} />
                <Button type="submit" disabled={scraping || !url.trim()}>
                  {scraping ? <><Loader2 className="h-4 w-4 animate-spin" /> Processando...</> : <><Globe className="h-4 w-4" /> Indexar URL</>}
                </Button>
              </form>
            </TabsContent>

            {/* Paste Tab */}
            <TabsContent value="paste">
              <div className="mb-4 p-3 rounded-md bg-muted border border-border text-xs text-muted-foreground space-y-1">
                <p className="font-medium text-foreground">Passo a passo:</p>
                <p>1. Abra a página no Compass/portal Coupa</p>
                <p>2. Selecione todo o conteúdo (Ctrl+A) → Copie (Ctrl+C) → Cole abaixo</p>
              </div>
              <form onSubmit={handleManualIndex} className="space-y-3 max-w-2xl">
                <Input value={manualTitle} onChange={(e) => setManualTitle(e.target.value)} placeholder="Título do conteúdo *" required disabled={indexingManual} />
                <Input value={manualUrl} onChange={(e) => setManualUrl(e.target.value)} placeholder="URL de referência (opcional)" disabled={indexingManual} />
                <Textarea value={manualContent} onChange={(e) => setManualContent(e.target.value)} placeholder="Cole aqui o conteúdo..." rows={8} disabled={indexingManual} className="font-mono text-xs" />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {manualContent.length.toLocaleString()} chars
                    {manualContent.trim().length >= 20 && <span className="ml-2">• ~{estimateChunks(manualContent)} chunks</span>}
                  </span>
                </div>
                <Button type="submit" disabled={indexingManual || manualContent.trim().length < 20 || !manualTitle.trim()}>
                  {indexingManual ? <><Loader2 className="h-4 w-4 animate-spin" /> Indexando...</> : <><ClipboardPaste className="h-4 w-4" /> Indexar Conteúdo</>}
                </Button>
              </form>
            </TabsContent>

            {/* Upload Tab */}
            <TabsContent value="upload">
              <div className="mb-4 text-xs text-muted-foreground space-y-1">
                <p><strong>Formatos aceitos:</strong> .txt, .md, .csv, .pdf, .xlsx, .xls, .json</p>
                <p><strong>Tamanho máximo:</strong> 20MB</p>
                <p>Arquivos grandes são enviados automaticamente em lotes.</p>
                <p className="text-yellow-600 dark:text-yellow-400">⚠ PDFs escaneados podem não conter texto extraível</p>
              </div>
              <form onSubmit={handleFileUpload} className="space-y-3 max-w-lg">
                <Input value={fileTitle} onChange={(e) => setFileTitle(e.target.value)} placeholder="Título do documento *" required disabled={uploadingFile} />
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                    uploadingFile ? "opacity-50 pointer-events-none border-border" :
                    dragOver ? "border-primary bg-primary/5" : selectedFile ? "border-green-500 bg-green-50 dark:bg-green-900/20" : "border-border hover:border-primary/50"
                  }`}
                  onClick={() => !uploadingFile && fileInputRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={handleFileDrop}
                >
                  <input ref={fileInputRef} type="file" accept={ACCEPTED_FILE_TYPES} className="hidden" onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])} />
                  {selectedFile ? (
                    <div className="flex flex-col items-center gap-1">
                      <FileUp className="h-6 w-6 text-green-600 dark:text-green-400" />
                      <p className="text-sm font-medium text-foreground">{selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">{(selectedFile.size / 1024).toFixed(1)} KB</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <FileUp className="h-6 w-6 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Arraste ou clique para selecionar</p>
                    </div>
                  )}
                </div>

                {/* Inline Progress Panel */}
                {uploadProgress && (
                  <div className={`rounded-lg border p-4 space-y-3 transition-all ${
                    uploadProgress.phase === "error" ? "border-destructive/50 bg-destructive/5" :
                    uploadProgress.phase === "done" ? "border-green-500/50 bg-green-50 dark:bg-green-900/10" :
                    "border-border bg-muted/50"
                  }`}>
                    {/* Phase icon + message */}
                    <div className="flex items-center gap-2.5">
                      {uploadProgress.phase === "extracting" && <Loader2 className="h-4 w-4 animate-spin text-primary shrink-0" />}
                      {uploadProgress.phase === "uploading" && <Loader2 className="h-4 w-4 animate-spin text-primary shrink-0" />}
                      {uploadProgress.phase === "done" && <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400 shrink-0" />}
                      {uploadProgress.phase === "error" && <XCircle className="h-4 w-4 text-destructive shrink-0" />}
                      <span className={`text-sm font-medium ${
                        uploadProgress.phase === "error" ? "text-destructive" :
                        uploadProgress.phase === "done" ? "text-green-700 dark:text-green-300" :
                        "text-foreground"
                      }`}>
                        {uploadProgress.message}
                      </span>
                    </div>

                    {/* Progress bar for uploading */}
                    {uploadProgress.phase === "uploading" && uploadProgress.totalParts > 0 && (
                      <div className="space-y-1.5">
                        <Progress value={(uploadProgress.currentPart / uploadProgress.totalParts) * 100} className="h-2" />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Parte {uploadProgress.currentPart} de {uploadProgress.totalParts}</span>
                          <span>{Math.round((uploadProgress.currentPart / uploadProgress.totalParts) * 100)}%</span>
                        </div>
                      </div>
                    )}

                    {/* PDF stats */}
                    {uploadProgress.totalPages && (
                      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><FileText className="h-3 w-3" /> {uploadProgress.totalPages} páginas</span>
                        <span className="flex items-center gap-1"><CheckCircle2 className="h-3 w-3 text-green-500" /> {uploadProgress.pagesWithText} com texto</span>
                        {(uploadProgress.pagesEmpty ?? 0) > 0 && (
                          <span className="flex items-center gap-1"><AlertTriangle className="h-3 w-3 text-yellow-500" /> {uploadProgress.pagesEmpty} vazias</span>
                        )}
                        {uploadProgress.totalChars && <span>{uploadProgress.totalChars.toLocaleString("pt-BR")} chars</span>}
                      </div>
                    )}

                    {/* Failed parts detail */}
                    {uploadProgress.failedParts.length > 0 && (
                      <p className="text-xs text-destructive">
                        Partes com falha: {uploadProgress.failedParts.join(", ")}
                      </p>
                    )}

                    {/* Done/error dismiss */}
                    {(uploadProgress.phase === "done" || uploadProgress.phase === "error") && (
                      <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setUploadProgress(null)}>
                        Fechar
                      </Button>
                    )}
                  </div>
                )}

                <Button type="submit" disabled={uploadingFile || !selectedFile || !fileTitle.trim()}>
                  {uploadingFile ? <><Loader2 className="h-4 w-4 animate-spin" /> Enviando...</> : <><Upload className="h-4 w-4" /> Indexar Arquivo</>}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Sources Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" /> Fontes Indexadas ({totalSources})</CardTitle>
            <Button variant="ghost" size="icon" onClick={loadSources} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading && sources.length === 0 ? (
            <div className="flex items-center justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : sources.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Nenhuma fonte indexada ainda.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Título</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Chunks</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sources.map((source) => {
                    const chunkCount = source.knowledge_chunks?.[0]?.count ?? 0;
                    const typeInfo = getSourceTypeLabel(source.source_type);
                    return (
                      <TableRow key={source.id}>
                        <TableCell className="max-w-[200px]">
                          <p className="font-medium text-sm truncate">{source.title || source.url}</p>
                          <p className="text-xs text-muted-foreground truncate">{source.url}</p>
                        </TableCell>
                        <TableCell><Badge variant={typeInfo.variant}>{typeInfo.label}</Badge></TableCell>
                        <TableCell><div className="flex items-center gap-1.5">{getStatusIcon(source.status)} <span className="text-xs capitalize">{source.status}</span></div></TableCell>
                        <TableCell className="text-right">{chunkCount}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{source.last_crawled_at ? new Date(source.last_crawled_at).toLocaleDateString("pt-BR") : "—"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button variant="ghost" size="icon" onClick={() => openChunkEditor(source)} title="Editar Chunks">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(source.id)} disabled={deletingId === source.id} className="text-destructive hover:text-destructive">
                              {deletingId === source.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Chunk Editor Dialog */}
      <Dialog open={!!previewSource} onOpenChange={() => { setPreviewSource(null); setChunks([]); setEditedChunks({}); }}>
        <DialogContent className="max-w-4xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="h-5 w-5" />
              {previewSource?.title || "Editor de Chunks"}
            </DialogTitle>
            <p className="text-xs text-muted-foreground">
              Tipo: {previewSource?.source_type} • {chunks.length} chunks carregados
            </p>
          </DialogHeader>

          <ScrollArea className="h-[65vh]">
            {loadingChunks ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">Carregando chunks...</span>
              </div>
            ) : chunks.length === 0 ? (
              <p className="text-center text-muted-foreground py-12">Nenhum chunk encontrado para esta fonte.</p>
            ) : (
              <div className="space-y-4 pr-4">
                {chunks.map((chunk) => {
                  const isEdited = editedChunks[chunk.id] !== undefined;
                  const currentContent = editedChunks[chunk.id] ?? chunk.content;
                  const pageInfo = chunk.metadata?.page_start || chunk.metadata?.chunk_index;
                  return (
                    <Card key={chunk.id} className={`transition-all ${isEdited ? "border-primary/50 shadow-sm" : ""}`}>
                      <CardHeader className="py-3 px-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs font-mono">#{chunk.chunk_index}</Badge>
                            {pageInfo !== undefined && (
                              <Badge variant="secondary" className="text-xs">
                                <FileText className="h-3 w-3 mr-1" />
                                Pág. {chunk.metadata?.page_start}{chunk.metadata?.page_end ? `-${chunk.metadata.page_end}` : ""}
                              </Badge>
                            )}
                            <span className="text-xs text-muted-foreground">{currentContent.length} chars</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost" size="sm" className="h-7 text-xs gap-1"
                              disabled={formattingChunkId === chunk.id}
                              onClick={() => handleFormatChunk(chunk.id)}
                            >
                              {formattingChunkId === chunk.id
                                ? <Loader2 className="h-3 w-3 animate-spin" />
                                : <Sparkles className="h-3 w-3" />}
                              Formatar com IA
                            </Button>
                            {isEdited && (
                              <Button
                                variant="default" size="sm" className="h-7 text-xs gap-1"
                                disabled={savingChunkId === chunk.id}
                                onClick={() => handleSaveChunk(chunk.id)}
                              >
                                {savingChunkId === chunk.id
                                  ? <Loader2 className="h-3 w-3 animate-spin" />
                                  : <Save className="h-3 w-3" />}
                                Salvar
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="px-4 pb-3 pt-0">
                        <Textarea
                          value={currentContent}
                          onChange={(e) => setEditedChunks(prev => ({ ...prev, [chunk.id]: e.target.value }))}
                          rows={Math.min(12, Math.max(4, currentContent.split("\n").length + 1))}
                          className="font-mono text-xs resize-y"
                          disabled={savingChunkId === chunk.id || formattingChunkId === chunk.id}
                        />
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
