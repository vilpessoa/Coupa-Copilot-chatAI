import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useDesignConfig } from "@/hooks/use-design-config";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Save, Upload, Trash2, Image, Type, Eye, Palette, MessageSquare, Check } from "lucide-react";
import coupaLogo from "@/assets/Coupa_logo_white.svg";
import { hexToHsl, hslStringToHex } from "@/lib/color-utils";

const COLOR_PRESETS = [
{ label: "Roxo Coupa", value: "245 100% 62%" },
{ label: "Azul Coupa", value: "213 100% 40%" },
{ label: "Índigo", value: "241 63% 42%" },
{ label: "Esmeralda", value: "160 84% 39%" },
{ label: "Laranja", value: "25 95% 53%" },
{ label: "Rosa", value: "330 81% 60%" }];


export default function DesignSystem() {
  const { config, refetch } = useDesignConfig();

  const [appName, setAppName] = useState("");
  const [botAvatarUrl, setBotAvatarUrl] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [primaryColor, setPrimaryColor] = useState("");
  const [welcomeSubtitle, setWelcomeSubtitle] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setAppName(config.app_name);
    setBotAvatarUrl(config.bot_avatar_url);
    setLogoUrl(config.logo_url);
    setPrimaryColor(config.primary_color);
    setWelcomeSubtitle(config.welcome_subtitle);
  }, [config]);

  const uploadFile = async (file: File, path: string) => {
    const ext = file.name.split(".").pop()?.toLowerCase() || "png";
    const filePath = `${path}.${ext}`;
    const { error } = await supabase.storage.
    from("design-assets").
    upload(filePath, file, { upsert: true, contentType: file.type });
    if (error) throw error;
    const { data: urlData } = supabase.storage.
    from("design-assets").
    getPublicUrl(filePath);
    return urlData.publicUrl + `?t=${Date.now()}`;
  };

  const handleAvatarUpload = async (file: File) => {
    setUploadingAvatar(true);
    try {
      const url = await uploadFile(file, "bot-avatar");
      setBotAvatarUrl(url);
      toast.success("Avatar enviado! Salve para aplicar.");
    } catch (err: any) {
      toast.error(`Erro no upload: ${err.message}`);
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleLogoUpload = async (file: File) => {
    setUploadingLogo(true);
    try {
      const url = await uploadFile(file, "logo");
      setLogoUrl(url);
      toast.success("Logo enviado! Salve para aplicar.");
    } catch (err: any) {
      toast.error(`Erro no upload: ${err.message}`);
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const updates = [
      { key: "app_name", value: appName.trim() || "Coupa Copilot" },
      { key: "bot_avatar_url", value: botAvatarUrl },
      { key: "logo_url", value: logoUrl },
      { key: "primary_color", value: primaryColor.trim() },
      { key: "welcome_subtitle", value: welcomeSubtitle.trim() }];

      for (const u of updates) {
        const { error } = await supabase.
        from("design_config" as any).
        update({ value: u.value, updated_at: new Date().toISOString() } as any).
        eq("key", u.key);
        if (error) throw error;
      }
      // Apply primary color immediately
      if (primaryColor.trim()) {
        document.documentElement.style.setProperty("--primary", primaryColor.trim());
        document.documentElement.style.setProperty("--ring", primaryColor.trim());
      }
      await refetch();
      toast.success("Configurações de design atualizadas.");
    } catch (err: any) {
      toast.error(`Erro ao salvar: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  // Preview color swatch
  const previewColor = primaryColor.trim() || "245 100% 62%";

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Design System</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Personalize a identidade visual do Coupa Copilot.
        </p>
      </div>

      {/* Preview */}
      <Card className="border-primary/30">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 p-4 rounded-xl bg-muted/50 border border-border">
            <div
              className="h-10 w-10 rounded-full flex items-center justify-center shrink-0 overflow-hidden"
              style={{ backgroundColor: `hsl(${previewColor})` }}>
              
              {botAvatarUrl ?
              <img src={botAvatarUrl} alt="Bot" className="h-full w-full object-cover" /> :

              <img src={coupaLogo} alt="Bot" className="h-5 w-5" />
              }
            </div>
            <div>
              <p className="font-semibold text-sm">
                <span className="gradient-text">{appName || "Coupa"}</span>
                {appName && appName.includes(" ") && <span className="text-foreground">{" "}{appName.split(" ").slice(1).join(" ")}</span>}
              </p>
              <p className="text-xs text-muted-foreground">está digitando...</p>
            </div>
            {logoUrl &&
            <div className="ml-auto">
                <img src={logoUrl} alt="Logo" className="h-8 max-w-[120px] object-contain" />
              </div>
            }
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* App Name */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Type className="h-4 w-4" />
              Nome do App
            </CardTitle>
            <CardDescription>Nome exibido no header, welcome screen e typing indicator.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="Coupa Copilot" />
            
          </CardContent>
        </Card>

        {/* Primary Color */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Cor Primária
            </CardTitle>
            <CardDescription>Define a cor principal aplicada em botões, avatar do bot, links, bordas ativas e destaques do chat.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={hslStringToHex(primaryColor || "245 100% 62%")}
                onChange={(e) => setPrimaryColor(hexToHsl(e.target.value))}
                className="h-10 w-10 rounded-lg border border-border shrink-0 cursor-pointer p-0.5 bg-background" />
              
              <Input
                value={primaryColor ? hslStringToHex(primaryColor) : ""}
                onChange={(e) => {
                  const v = e.target.value;
                  if (/^#[0-9a-fA-F]{6}$/.test(v)) {
                    setPrimaryColor(hexToHsl(v));
                  }
                }}
                placeholder="#7C3AED"
                className="font-mono text-sm uppercase"
                maxLength={7} />
              
            </div>
            
























            
          </CardContent>
        </Card>

        {/* Welcome Subtitle */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Subtítulo de Boas-Vindas
            </CardTitle>
            <CardDescription>Texto exibido abaixo do título na tela inicial do chat.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              value={welcomeSubtitle}
              onChange={(e) => setWelcomeSubtitle(e.target.value)}
              placeholder="Seu assistente inteligente para a plataforma Coupa. Selecione uma ação rápida ou digite sua pergunta."
              rows={3} />
            
          </CardContent>
        </Card>

        {/* Bot Avatar */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Image className="h-4 w-4" />
              Avatar do Bot
            </CardTitle>
            <CardDescription>Imagem exibida nas mensagens do assistente.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center overflow-hidden border-2 border-border">
                {botAvatarUrl ?
                <img src={botAvatarUrl} alt="Avatar" className="h-full w-full object-cover" /> :

                <img src={coupaLogo} alt="Default" className="h-6 w-6" />
                }
              </div>
              <div className="flex gap-2">
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleAvatarUpload(e.target.files[0])} />
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => avatarInputRef.current?.click()}
                  disabled={uploadingAvatar}>
                  
                  {uploadingAvatar ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  Upload
                </Button>
                {botAvatarUrl &&
                <Button variant="ghost" size="sm" onClick={() => setBotAvatarUrl("")}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                }
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Logo */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Image className="h-4 w-4" />
              Logo Principal
            </CardTitle>
            <CardDescription>Logo exibido no header e sidebar.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-12 w-24 rounded-lg bg-muted flex items-center justify-center overflow-hidden border border-border">
                {logoUrl ?
                <img src={logoUrl} alt="Logo" className="h-full max-w-full object-contain p-1" /> :

                <span className="text-xs text-muted-foreground">Sem logo</span>
                }
              </div>
              <div className="flex gap-2">
                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0])} />
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => logoInputRef.current?.click()}
                  disabled={uploadingLogo}>
                  
                  {uploadingLogo ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  Upload
                </Button>
                {logoUrl &&
                <Button variant="ghost" size="sm" onClick={() => setLogoUrl("")}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                }
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving} className="gap-2">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Salvar Configurações
        </Button>
      </div>
    </div>);

}