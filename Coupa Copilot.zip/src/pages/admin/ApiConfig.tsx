import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Loader2, CheckCircle2, XCircle, Plug, RefreshCw, Plus, Trash2,
  Shield, ToggleLeft, ToggleRight, Pencil, X, Save, AlertCircle, Eye, EyeOff,
} from "lucide-react";
import ScopeConnectionMap from "@/components/admin/ScopeConnectionMap";

// ─── Types ───
interface ApiScope {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
}

interface Credential {
  id: string;
  key_name: string;
  masked_hint: string;
  is_sensitive: boolean;
  updated_at: string;
}

const CREDENTIAL_LABELS: Record<string, string> = {
  COUPA_INSTANCE_URL: "URL da Instância Coupa",
  COUPA_CLIENT_ID: "Client ID (OAuth)",
  COUPA_CLIENT_SECRET: "Client Secret (OAuth)",
};

// ─── Credential Card ───
function CredentialRow({ cred, onSaved }: { cred: Credential; onSaved: () => void }) {
  const [editing, setEditing] = useState(false);
  const [newValue, setNewValue] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const isConfigured = !!cred.masked_hint;
  const label = CREDENTIAL_LABELS[cred.key_name] || cred.key_name;

  const handleSave = async () => {
    setError("");
    if (!newValue.trim()) { setError("O valor não pode ser vazio."); return; }
    if (cred.key_name === "COUPA_INSTANCE_URL" && !newValue.trim().startsWith("https://")) {
      setError("A URL deve começar com https://"); return;
    }

    setSaving(true);
    try {
      const { data, error: fnErr } = await supabase.functions.invoke("manage-credentials", {
        body: { action: "save", key_name: cred.key_name, value: newValue.trim() },
      });
      if (fnErr) throw fnErr;
      if (data?.error) throw new Error(data.error);

      toast.success("Credencial atualizada!");
      setNewValue("");
      setEditing(false);
      onSaved();
    } catch (e: any) {
      setError(e.message || "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-4 rounded-lg border border-border bg-muted/30 space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium">{label}</p>
          <p className="text-xs text-muted-foreground font-mono">{cred.key_name}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {isConfigured ? (
            <Badge variant="outline" className="gap-1 border-green-200 dark:border-green-800 text-green-700 dark:text-green-400">
              <CheckCircle2 className="h-3 w-3" /> Configurado
            </Badge>
          ) : (
            <Badge variant="outline" className="gap-1 border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-400">
              <AlertCircle className="h-3 w-3" /> Não configurado
            </Badge>
          )}
          {!editing && (
            <Button variant="ghost" size="sm" className="gap-1.5 h-8" onClick={() => setEditing(true)}>
              <Pencil className="h-3.5 w-3.5" /> Editar
            </Button>
          )}
        </div>
      </div>

      {/* Display masked value */}
      {!editing && isConfigured && (
        <p className="text-sm font-mono text-muted-foreground">
          {cred.is_sensitive ? cred.masked_hint : cred.masked_hint}
        </p>
      )}

      {/* Edit mode */}
      {editing && (
        <div className="space-y-2 pt-1 border-t border-border">
          <p className="text-xs text-muted-foreground">
            Insira o novo valor. O valor atual não é exibido por segurança.
          </p>
          <Input
            value={newValue}
            onChange={(e) => { setNewValue(e.target.value); setError(""); }}
            placeholder={cred.key_name === "COUPA_INSTANCE_URL" ? "https://instance.coupahost.com" : "Cole o novo valor aqui"}
            type={cred.is_sensitive ? "password" : "text"}
            className="font-mono text-sm"
            autoFocus
          />
          {error && <p className="text-xs text-destructive flex items-center gap-1"><AlertCircle className="h-3 w-3" /> {error}</p>}
          <div className="flex gap-2">
            <Button size="sm" onClick={handleSave} disabled={saving} className="gap-1.5">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Salvar
            </Button>
            <Button size="sm" variant="ghost" onClick={() => { setEditing(false); setNewValue(""); setError(""); }} className="gap-1.5">
              <X className="h-3.5 w-3.5" /> Cancelar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Component ───
export default function ApiConfig() {
  // Connection test
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Credentials
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [loadingCreds, setLoadingCreds] = useState(true);
  const [initialized, setInitialized] = useState(false);

  // Scopes
  const [scopes, setScopes] = useState<ApiScope[]>([]);
  const [loadingScopes, setLoadingScopes] = useState(true);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    initAndFetch();
    fetchScopes();
  }, []);

  const initAndFetch = async () => {
    setLoadingCreds(true);
    // Run init once to populate from env vars
    if (!initialized) {
      try {
        await supabase.functions.invoke("manage-credentials", { body: { action: "init" } });
      } catch (_) {}
      setInitialized(true);
    }
    await fetchCredentials();
  };

  const fetchCredentials = async () => {
    setLoadingCreds(true);
    try {
      const { data, error } = await supabase.functions.invoke("manage-credentials", {
        body: { action: "list" },
      });
      if (!error && data?.credentials) setCredentials(data.credentials);
    } catch (_) {}
    setLoadingCreds(false);
  };

  const fetchScopes = async () => {
    setLoadingScopes(true);
    const { data, error } = await supabase.from("api_scopes").select("*").order("created_at", { ascending: true });
    if (!error && data) setScopes(data);
    setLoadingScopes(false);
  };

  const addScope = async () => {
    if (!newName.trim()) return;
    setAdding(true);
    const { error } = await supabase.from("api_scopes").insert({ name: newName.trim(), description: newDesc.trim() });
    if (error) {
      toast.error(`Erro ao adicionar: ${error.message}`);
    } else {
      setNewName(""); setNewDesc(""); await fetchScopes();
      toast.success("Escopo adicionado!");
    }
    setAdding(false);
  };

  const toggleScope = async (scope: ApiScope) => {
    const { error } = await supabase.from("api_scopes").update({ is_active: !scope.is_active }).eq("id", scope.id);
    if (!error) setScopes((prev) => prev.map((s) => (s.id === scope.id ? { ...s, is_active: !s.is_active } : s)));
  };

  const deleteScope = async (id: string) => {
    const { error } = await supabase.from("api_scopes").delete().eq("id", id);
    if (!error) { setScopes((prev) => prev.filter((s) => s.id !== id)); toast.success("Escopo removido"); }
  };

  const testConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("chat", {
        body: { messages: [{ role: "user", content: "Teste de conexão: liste 1 requisição" }] },
      });
      if (error) throw error;
      setTestResult({ success: true, message: "Conexão com a API Coupa está funcionando!" });
    } catch (err: any) {
      setTestResult({ success: false, message: err.message || "Falha na conexão" });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Configuração API</h1>
        <p className="text-sm text-muted-foreground mt-1">Gerencie credenciais e escopos da API Coupa.</p>
      </div>

      {/* Credentials Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Plug className="h-5 w-5" /> Credenciais Coupa API</CardTitle>
          <CardDescription>Credenciais OAuth 2.0 para integração com a instância Coupa. Valores sensíveis são mascarados por segurança.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {loadingCreds ? (
            <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
          ) : (
            credentials.map((cred) => (
              <CredentialRow key={cred.id} cred={cred} onSaved={fetchCredentials} />
            ))
          )}
        </CardContent>
      </Card>

      {/* Connection Test */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><RefreshCw className="h-5 w-5" /> Teste de Conexão</CardTitle>
          <CardDescription>Verifique se as credenciais estão funcionando corretamente.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={testConnection} disabled={testing} className="gap-1.5">
            {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Testar Conexão
          </Button>

          {testResult && (
            <div className={`flex items-center gap-3 p-4 rounded-lg border ${
              testResult.success
                ? "bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800"
                : "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800"
            }`}>
              {testResult.success ? (
                <CheckCircle2 className="h-6 w-6 text-green-600 dark:text-green-400 shrink-0" />
              ) : (
                <XCircle className="h-6 w-6 text-red-600 dark:text-red-400 shrink-0" />
              )}
              <div>
                <p className={`text-sm font-semibold ${
                  testResult.success ? "text-green-800 dark:text-green-300" : "text-red-800 dark:text-red-300"
                }`}>
                  {testResult.success ? "Conexão bem-sucedida!" : "Falha na conexão"}
                </p>
                <p className={`text-xs mt-0.5 ${
                  testResult.success ? "text-green-700 dark:text-green-400" : "text-red-700 dark:text-red-400"
                }`}>
                  {testResult.message}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* API Scopes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Shield className="h-5 w-5" /> Escopos da API</CardTitle>
          <CardDescription>Defina quais operações da API Coupa o assistente pode acessar.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Add new scope - now at top */}
          <div className="flex items-end gap-2 pb-2 border-b border-border">
            <div className="flex-1 space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Nome do escopo</label>
              <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="ex: get_invoices" className="font-mono text-sm" />
            </div>
            <div className="flex-1 space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Descrição</label>
              <Input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} placeholder="ex: Buscar faturas" />
            </div>
            <Button onClick={addScope} disabled={adding || !newName.trim()} size="sm" className="gap-1.5 shrink-0">
              {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Adicionar
            </Button>
          </div>

          {/* Scopes list - below */}
          {loadingScopes ? (
            <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {scopes.map((scope) => (
                <div key={scope.id} className={`flex items-center gap-3 p-3 rounded-lg border transition-colors ${
                  scope.is_active ? "border-border bg-muted/30" : "border-border/50 bg-muted/10 opacity-60"
                }`}>
                  <button onClick={() => toggleScope(scope)} className="shrink-0 hover:opacity-80 transition-opacity"
                    title={scope.is_active ? "Desativar escopo" : "Ativar escopo"}>
                    {scope.is_active ? <ToggleRight className="h-5 w-5 text-green-600 dark:text-green-400" /> : <ToggleLeft className="h-5 w-5 text-muted-foreground" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium font-mono truncate">{scope.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{scope.description}</p>
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive" onClick={() => deleteScope(scope.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Scope Connection Map */}
      <ScopeConnectionMap scopes={scopes} />
    </div>
  );
}
