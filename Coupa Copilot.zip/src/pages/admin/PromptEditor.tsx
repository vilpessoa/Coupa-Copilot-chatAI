import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, Save, RotateCcw, Eye, EyeOff, MessageSquareText, Bot } from "lucide-react";
import logoOpenai from "@/assets/logo-openai.png";
import logoGemini from "@/assets/logo-gemini.png";

const DEFAULT_PROMPT = `Você é o Coupa Copilot, um assistente inteligente especializado na plataforma de e-Procurement Coupa.

REGRAS:
- Responda APENAS sobre a plataforma Coupa e seus módulos.
- Se a pergunta não for sobre o Coupa, responda educadamente que só pode ajudar com temas do Coupa.
- Responda sempre em português brasileiro.
- Formate suas respostas em Markdown quando apropriado.
- Seja claro, objetivo e profissional.`;

const DEFAULT_FORMAT_RULES = `FORMATAÇÃO DE TEXTO (OBRIGATÓRIO — siga rigorosamente):
- Deixe SEMPRE uma linha em branco entre cada parágrafo. Nunca junte dois parágrafos consecutivos sem uma linha em branco separando-os.
- Parágrafos curtos: máximo 2-3 frases por parágrafo. Quebre textos longos em múltiplos parágrafos.
- Para instruções passo-a-passo, SEMPRE use listas numeradas com uma linha em branco antes e depois da lista.
- Use ### para subtítulos quando a resposta tiver mais de 2 parágrafos. Deixe uma linha em branco antes e depois do subtítulo.
- Use **negrito** com moderação — apenas 1-2 termos-chave por parágrafo. Nunca aplique negrito em frases completas, parágrafos inteiros ou listas inteiras.
- Comece SEMPRE com um resumo direto de 1-2 frases, seguido de uma linha em branco.
- NUNCA escreva um bloco contínuo de texto sem separação visual.

EXEMPLO DE BOA FORMATAÇÃO:

Resumo curto aqui.

### Subtítulo

Primeiro parágrafo com 2-3 frases.

Segundo parágrafo separado por linha em branco.

1. Passo um
2. Passo dois
3. Passo três`;

const DEFAULT_INTERACTION_RULES = `REGRAS DE INTERAÇÃO INTELIGENTE:
- Para consultas vagas, busque os últimos 3-5 itens e pergunte qual ver em detalhe.
- Para consultas específicas, busque diretamente com filtros adequados.
- Se encontrar apenas 1 resultado, mostre os detalhes diretamente.
- Se encontrar muitos resultados (>5), mostre resumo dos 5 mais recentes.

PRIORIDADE DE FONTES:
1. Base de Conhecimento (RAG) — prioridade máxima
2. Conhecimentos gerais sobre Coupa — quando não houver na base
3. API Coupa — apenas quando o usuário solicitar dados específicos/em tempo real`;

const AVAILABLE_MODELS = [
  { value: "openai/gpt-5", label: "OpenAI GPT-5", description: "Mais robusto e argumentativo (recomendado)", logo: logoOpenai },
  { value: "openai/gpt-5-mini", label: "OpenAI GPT-5 Mini", description: "Bom equilíbrio custo/qualidade", logo: logoOpenai },
  { value: "openai/gpt-5.2", label: "OpenAI GPT-5.2", description: "Último modelo, raciocínio avançado", logo: logoOpenai },
  { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro", description: "Top Google, bom em contexto longo", logo: logoGemini },
  { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash", description: "Rápido, bom custo-benefício", logo: logoGemini },
  { value: "google/gemini-3-flash-preview", label: "Gemini 3 Flash (Preview)", description: "Preview, pode ser instável", logo: logoGemini },
  { value: "google/gemini-3.1-pro-preview", label: "Gemini 3.1 Pro (Preview)", description: "Preview avançado Google", logo: logoGemini },
];

const PROMPT_KEYS = [
  { key: "system_prompt", label: "Prompt Principal", description: "Instruções gerais do assistente", defaultValue: DEFAULT_PROMPT },
  { key: "format_rules", label: "Regras de Formatação", description: "Como o bot deve formatar as respostas", defaultValue: DEFAULT_FORMAT_RULES },
  { key: "interaction_rules", label: "Regras de Interação", description: "Como o bot deve se comportar e priorizar fontes", defaultValue: DEFAULT_INTERACTION_RULES },
];

export default function PromptEditor() {
  const [values, setValues] = useState<Record<string, string>>({});
  const [selectedModel, setSelectedModel] = useState("openai/gpt-5");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [savingModel, setSavingModel] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  useEffect(() => {
    loadPrompts();
  }, []);

  const loadPrompts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("system_prompt_config")
        .select("key, value");
      if (error) throw error;
      const map: Record<string, string> = {};
      PROMPT_KEYS.forEach((pk) => {
        const found = data?.find((d: any) => d.key === pk.key);
        map[pk.key] = found?.value || pk.defaultValue;
      });
      setValues(map);
      const modelRow = data?.find((d: any) => d.key === "chat_model");
      if (modelRow?.value) setSelectedModel(modelRow.value);
    } catch (err) {
      console.error("Failed to load prompts:", err);
      const map: Record<string, string> = {};
      PROMPT_KEYS.forEach((pk) => { map[pk.key] = pk.defaultValue; });
      setValues(map);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (key: string) => {
    setSaving(key);
    try {
      const { error } = await supabase
        .from("system_prompt_config")
        .upsert({ key, value: values[key], updated_at: new Date().toISOString() }, { onConflict: "key" });
      if (error) throw error;
      toast.success("Prompt atualizado com sucesso.");
    } catch (err: any) {
      toast.error(`Erro ao salvar: ${err.message}`);
    } finally {
      setSaving(null);
    }
  };

  const handleSaveModel = async () => {
    setSavingModel(true);
    try {
      const { error } = await supabase
        .from("system_prompt_config")
        .upsert({ key: "chat_model", value: selectedModel, updated_at: new Date().toISOString() }, { onConflict: "key" });
      if (error) throw error;
      toast.success(`Modelo atualizado! O assistente agora usa ${AVAILABLE_MODELS.find(m => m.value === selectedModel)?.label || selectedModel}.`);
    } catch (err: any) {
      toast.error(`Erro ao salvar: ${err.message}`);
    } finally {
      setSavingModel(false);
    }
  };

  const handleReset = (key: string) => {
    const pk = PROMPT_KEYS.find((p) => p.key === key);
    if (pk) {
      setValues((prev) => ({ ...prev, [key]: pk.defaultValue }));
      toast.info("Valor padrão restaurado. Salve para aplicar.");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const fullPrompt = PROMPT_KEYS.map((pk) => values[pk.key] || pk.defaultValue).join("\n\n");

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Refinar Prompt</h1>
          <p className="text-sm text-muted-foreground mt-1">Personalize como o assistente responde aos usuários.</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowPreview(!showPreview)} className="gap-1.5">
          {showPreview ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          {showPreview ? "Ocultar Preview" : "Preview Completo"}
        </Button>
      </div>

      {/* Model Selector Card - Destaque */}
      <Card className="border-primary/40 bg-primary/[0.03] dark:bg-primary/[0.05]">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Bot className="h-4 w-4" />
            Modelo de IA (LLM)
          </CardTitle>
          <CardDescription>Escolha qual modelo de linguagem o assistente utiliza. O modelo de fallback (Gemini 2.5 Pro) é acionado automaticamente em caso de falha.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3">
            <Select value={selectedModel} onValueChange={setSelectedModel}>
              <SelectTrigger className="w-full max-w-md">
                <div className="flex items-center gap-2">
                  {(() => {
                    const m = AVAILABLE_MODELS.find(m => m.value === selectedModel);
                    return m ? (
                      <>
                        <img src={m.logo} alt="" className="h-4 w-4 object-contain shrink-0" />
                        <span className="truncate">{m.label}</span>
                      </>
                    ) : <SelectValue />;
                  })()}
                </div>
              </SelectTrigger>
              <SelectContent>
                {AVAILABLE_MODELS.map((m) => (
                  <SelectItem key={m.value} value={m.value}>
                    <div className="flex items-center gap-2">
                      <img src={m.logo} alt="" className="h-4 w-4 object-contain shrink-0" />
                      <span className="font-medium">{m.label}</span>
                      <span className="text-muted-foreground text-xs">— {m.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handleSaveModel} disabled={savingModel} className="gap-1.5 shrink-0">
              {savingModel ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">Fallback automático: <strong>Google Gemini 2.5 Pro</strong> (ativado se o modelo principal falhar ou retornar vazio)</p>
        </CardContent>
      </Card>

      {showPreview && (
        <Card className="border-primary/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <MessageSquareText className="h-4 w-4" />
              Preview do Prompt Completo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="whitespace-pre-wrap text-sm font-mono bg-muted p-4 rounded-md max-h-[400px] overflow-auto">
              {fullPrompt}
            </pre>
          </CardContent>
        </Card>
      )}

      {PROMPT_KEYS.map((pk) => (
        <Card key={pk.key}>
          <CardHeader>
            <CardTitle className="text-base">{pk.label}</CardTitle>
            <CardDescription>{pk.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              value={values[pk.key] || ""}
              onChange={(e) => setValues((prev) => ({ ...prev, [pk.key]: e.target.value }))}
              rows={10}
              className="font-mono text-sm"
            />
            <div className="flex gap-2">
              <Button onClick={() => handleSave(pk.key)} disabled={saving === pk.key} className="gap-1.5">
                {saving === pk.key ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Salvar
              </Button>
              <Button variant="outline" onClick={() => handleReset(pk.key)} className="gap-1.5">
                <RotateCcw className="h-4 w-4" />
                Restaurar Padrão
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
