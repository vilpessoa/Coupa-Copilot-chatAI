import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";

export interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  avatar_url: string | null;
  area_id: string | null;
  area_name?: string | null;
  job_title: string | null;
  role: string;
  is_active: boolean;
  azure_id: string | null;
  last_sign_in_at: string | null;
  created_at: string;
  updated_at: string;
}

interface UserContextValue {
  profile: UserProfile | null;
  isAdmin: boolean;
  isLoading: boolean;
  refetchProfile: () => Promise<void>;
}

const UserContext = createContext<UserContextValue>({
  profile: null,
  isAdmin: false,
  isLoading: true,
  refetchProfile: async () => {},
});

export function useUser() {
  return useContext(UserContext);
}

export function UserProvider({ children }: { children: ReactNode }) {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const fetchProfile = useCallback(async () => {
    if (!user) {
      setProfile(null);
      setIsAdmin(false);
      setIsLoading(false);
      return;
    }

    try {
      // Fetch profile with area name
      const { data: profileData, error } = await supabase
        .from("profiles")
        .select("*, areas(name)")
        .eq("id", user.id)
        .maybeSingle();

      if (error) throw error;

      if (!profileData) {
        // Profile doesn't exist yet (trigger might not have fired)
        setProfile(null);
        setIsAdmin(false);
        setIsLoading(false);
        return;
      }

      // Check if user is inactive
      if (!profileData.is_active) {
        toast.error("Sua conta está desativada. Entre em contato com um administrador.");
        await signOut();
        return;
      }

      const areaData = profileData.areas as any;
      const p: UserProfile = {
        id: profileData.id,
        full_name: profileData.full_name,
        email: profileData.email,
        avatar_url: profileData.avatar_url,
        area_id: profileData.area_id,
        area_name: areaData?.name || null,
        job_title: profileData.job_title,
        role: profileData.role,
        is_active: profileData.is_active,
        azure_id: profileData.azure_id,
        last_sign_in_at: profileData.last_sign_in_at,
        created_at: profileData.created_at,
        updated_at: profileData.updated_at,
      };

      setProfile(p);

      // Check admin role via has_role function
      const { data: roleData } = await supabase.rpc("has_role", {
        _user_id: user.id,
        _role: "admin",
      });
      setIsAdmin(!!roleData);
    } catch (err) {
      console.error("Error fetching profile:", err);
    } finally {
      setIsLoading(false);
    }
  }, [user, signOut]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  return (
    <UserContext.Provider value={{ profile, isAdmin, isLoading, refetchProfile: fetchProfile }}>
      {children}
    </UserContext.Provider>
  );
}
