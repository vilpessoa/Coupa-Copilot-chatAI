import { useState, useCallback, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Message, Conversation } from "@/types/chat";
import { streamChat } from "@/lib/chat-stream";
import { toast } from "sonner";

export function useChat() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const loadConversations = useCallback(async () => {
    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .order("updated_at", { ascending: false });
    if (data && !error) setConversations(data as unknown as Conversation[]);
  }, []);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  const loadMessages = useCallback(async (conversationId: string) => {
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });
    if (data && !error) setMessages(data as unknown as Message[]);
  }, []);

  const selectConversation = useCallback(async (conversation: Conversation) => {
    setActiveConversation(conversation);
    await loadMessages(conversation.id);
  }, [loadMessages]);

  const createConversation = useCallback(async (firstMessage: string) => {
    const title = firstMessage.slice(0, 50) + (firstMessage.length > 50 ? "..." : "");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error("You must be logged in"); return null; }
    const { data, error } = await supabase.from("conversations").insert({ title, user_id: user.id }).select().single();
    if (data && !error) {
      const conv = data as unknown as Conversation;
      setActiveConversation(conv);
      setMessages([]);
      setConversations(prev => [conv, ...prev]);
      return conv;
    }
    return null;
  }, []);

  const deleteConversation = useCallback(async (id: string) => {
    await supabase.from("messages").delete().eq("conversation_id", id);
    await supabase.from("conversations").delete().eq("id", id);
    setConversations(prev => prev.filter(c => c.id !== id));
    if (activeConversation?.id === id) { setActiveConversation(null); setMessages([]); }
  }, [activeConversation]);

  const newConversation = useCallback(() => {
    setActiveConversation(null);
    setMessages([]);
  }, []);

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim() || isStreaming) return;

    let conversation = activeConversation;
    if (!conversation) {
      conversation = await createConversation(content);
      if (!conversation) { toast.error("Failed to create conversation"); return; }
    }

    const userMsg: Message = {
      id: crypto.randomUUID(),
      conversation_id: conversation.id,
      role: "user",
      content,
      created_at: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);
    setIsStreaming(true);

    await supabase.from("messages").insert({
      conversation_id: conversation.id,
      role: "user",
      content,
    });

    const apiMessages = [...messages, userMsg].map(m => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));

    let assistantContent = "";
    let courtesyContent = "";
    let isCourtesyPhase = true;
    const assistantId = crypto.randomUUID();

    try {
      const result = await streamChat({
        messages: apiMessages,
        onDelta: (chunk) => {
          if (isCourtesyPhase) {
            courtesyContent += chunk;
          } else {
            assistantContent += chunk;
          }
          const displayContent = isCourtesyPhase ? courtesyContent : assistantContent;
          setMessages(prev => {
            const last = prev[prev.length - 1];
            if (last?.role === "assistant" && last.id === assistantId) {
              return prev.map((m, i) =>
                i === prev.length - 1 ? { ...m, content: displayContent } : m
              );
            }
            return [
              ...prev,
              {
                id: assistantId,
                conversation_id: conversation!.id,
                role: "assistant" as const,
                content: displayContent,
                created_at: new Date().toISOString(),
              },
            ];
          });
        },
        onCourtesyEnd: () => {
          isCourtesyPhase = false;
          // Reset — real content will replace courtesy
        },
        onDone: () => {},
        onError: (error) => {
          // Show error as an inline assistant message instead of just a toast
          const errorId = assistantId;
          const errorContent = `⚠️ ${error}`;
          setMessages(prev => {
            const last = prev[prev.length - 1];
            if (last?.role === "assistant" && last.id === errorId) {
              return prev.map((m, i) =>
                i === prev.length - 1 ? { ...m, content: errorContent, metadata: { is_error: true } } : m
              );
            }
            return [
              ...prev,
              {
                id: errorId,
                conversation_id: conversation!.id,
                role: "assistant" as const,
                content: errorContent,
                created_at: new Date().toISOString(),
                metadata: { is_error: true },
              },
            ];
          });
        },
      });

      if (assistantContent && result) {
        // Parse follow-up suggestions from content
        const followUpMatch = assistantContent.match(/\[FOLLOW_UP:\s*(.+?)\]\s*$/);
        let followUps: string[] = [];
        let cleanContent = assistantContent;
        if (followUpMatch) {
          followUps = followUpMatch[1].split("|").map(s => s.trim()).filter(Boolean);
          cleanContent = assistantContent.replace(/\[FOLLOW_UP:\s*(.+?)\]\s*$/, "").trim();
        }

        // Merge with stream metadata
        if (result.follow_ups?.length) followUps = result.follow_ups;

        const metadata: any = {};
        if (result.source_type) metadata.source_type = result.source_type;
        if (result.source_types?.length) metadata.source_types = result.source_types;
        if (followUps.length) metadata.follow_ups = followUps;

        setMessages(prev =>
          prev.map(m =>
            m.id === assistantId
              ? { ...m, content: cleanContent, sources: result.sources?.length ? result.sources : undefined, confidence: (result.confidence as any) || "high", metadata: Object.keys(metadata).length ? metadata : undefined }
              : m
          )
        );

        await supabase.from("messages").insert({
          conversation_id: conversation.id,
          role: "assistant",
          content: cleanContent,
          sources: result.sources || null,
          confidence: result.confidence || "high",
          metadata: Object.keys(metadata).length ? metadata : null,
        });

        await supabase
          .from("conversations")
          .update({ updated_at: new Date().toISOString() })
          .eq("id", conversation.id);

        // Auto-rename title on first exchange
        if (messages.length === 0) {
          try {
            const { data: { session } } = await supabase.auth.getSession();
            if (session?.access_token) {
              const titleResp = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                  action: "generate_title",
                  messages: [
                    { role: "user", content },
                    { role: "assistant", content: cleanContent.slice(0, 200) },
                  ],
                }),
              });
              if (titleResp.ok) {
                const { title } = await titleResp.json();
                if (title) {
                  await supabase.from("conversations").update({ title }).eq("id", conversation.id);
                  setConversations(prev => prev.map(c => c.id === conversation!.id ? { ...c, title } : c));
                  setActiveConversation(prev => prev?.id === conversation!.id ? { ...prev, title } : prev);
                }
              }
            }
          } catch (e) {
            console.error("Title generation failed:", e);
          }
        }
      }
    } catch (e) {
      // Show error inline
      setMessages(prev => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant" && last.id === assistantId) {
          return prev.map((m, i) =>
            i === prev.length - 1 ? { ...m, content: "⚠️ Falha ao obter resposta. Tente novamente.", metadata: { is_error: true } } : m
          );
        }
        return [
          ...prev,
          {
            id: assistantId,
            conversation_id: conversation!.id,
            role: "assistant" as const,
            content: "⚠️ Falha ao obter resposta. Tente novamente.",
            created_at: new Date().toISOString(),
            metadata: { is_error: true },
          },
        ];
      });
    } finally {
      // ALWAYS reset streaming state, no matter what
      setIsLoading(false);
      setIsStreaming(false);
    }
  }, [activeConversation, messages, isStreaming, createConversation]);

  return {
    conversations,
    activeConversation,
    messages,
    isLoading,
    isStreaming,
    loadConversations,
    selectConversation,
    createConversation,
    deleteConversation,
    newConversation,
    sendMessage,
  };
}
