import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface DesignConfig {
  app_name: string;
  bot_avatar_url: string;
  logo_url: string;
  primary_color: string;
  welcome_subtitle: string;
}

const DEFAULTS: DesignConfig = {
  app_name: "Coupa Copilot",
  bot_avatar_url: "",
  logo_url: "",
  primary_color: "",
  welcome_subtitle: "",
};

let cachedConfig: DesignConfig | null = null;
let configLoaded = false;
const listeners = new Set<(c: DesignConfig) => void>();

function notify(config: DesignConfig) {
  cachedConfig = config;
  // Apply primary color to CSS custom properties
  if (config.primary_color) {
    document.documentElement.style.setProperty("--primary", config.primary_color);
    document.documentElement.style.setProperty("--ring", config.primary_color);
  }
  listeners.forEach((fn) => fn(config));
}

async function fetchConfig() {
  const { data } = await supabase
    .from("design_config" as any)
    .select("key, value");
  const map: Record<string, string> = {};
  if (data) {
    (data as any[]).forEach((row: any) => {
      map[row.key] = row.value;
    });
  }
  const config: DesignConfig = {
    app_name: map.app_name || DEFAULTS.app_name,
    bot_avatar_url: map.bot_avatar_url || DEFAULTS.bot_avatar_url,
    logo_url: map.logo_url || DEFAULTS.logo_url,
    primary_color: map.primary_color || DEFAULTS.primary_color,
    welcome_subtitle: map.welcome_subtitle || DEFAULTS.welcome_subtitle,
  };
  configLoaded = true;
  notify(config);
  return config;
}

// Initial fetch
let initPromise: Promise<DesignConfig> | null = null;

export function useDesignConfig() {
  const [config, setConfig] = useState<DesignConfig>(cachedConfig || DEFAULTS);

  useEffect(() => {
    listeners.add(setConfig);
    if (!initPromise) {
      initPromise = fetchConfig();
    } else if (cachedConfig) {
      setConfig(cachedConfig);
    }
    return () => { listeners.delete(setConfig); };
  }, []);

  const refetch = async () => {
    await fetchConfig();
  };

  return { config, refetch, isLoaded: configLoaded || cachedConfig !== null };
}
