
-- 1. Fix knowledge_sources: restrict to authenticated only
DROP POLICY IF EXISTS "Allow read access to knowledge_sources" ON public.knowledge_sources;
CREATE POLICY "authenticated_read_knowledge_sources"
  ON public.knowledge_sources FOR SELECT TO authenticated USING (true);

-- 2. Fix knowledge_chunks: restrict to authenticated only
DROP POLICY IF EXISTS "Allow read access to knowledge_chunks" ON public.knowledge_chunks;
CREATE POLICY "authenticated_read_knowledge_chunks"
  ON public.knowledge_chunks FOR SELECT TO authenticated USING (true);

-- 3. Fix suggested_questions: restrict to authenticated only
DROP POLICY IF EXISTS "Allow read access to suggested_questions" ON public.suggested_questions;
CREATE POLICY "authenticated_read_suggested_questions"
  ON public.suggested_questions FOR SELECT TO authenticated USING (true);

-- 4. Fix avatar upload path restriction
DROP POLICY IF EXISTS "authenticated_upload_avatars" ON storage.objects;
CREATE POLICY "authenticated_upload_avatars"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- 5. Fix azure_id self-update on profiles
DROP POLICY IF EXISTS "users_update_own_profile" ON public.profiles;
CREATE POLICY "users_update_own_profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (
    id = auth.uid()
    AND email = (SELECT p.email FROM profiles p WHERE p.id = auth.uid())
    AND role = (SELECT p.role FROM profiles p WHERE p.id = auth.uid())
    AND is_active = (SELECT p.is_active FROM profiles p WHERE p.id = auth.uid())
    AND NOT (area_id IS DISTINCT FROM (SELECT p.area_id FROM profiles p WHERE p.id = auth.uid()))
    AND NOT (azure_id IS DISTINCT FROM (SELECT p.azure_id FROM profiles p WHERE p.id = auth.uid()))
  );
