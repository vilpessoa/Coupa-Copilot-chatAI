
-- Drop the overly permissive SELECT policy
DROP POLICY IF EXISTS "authenticated_read_profiles" ON public.profiles;

-- Users can read their own profile
CREATE POLICY "users_read_own_profile" ON public.profiles
FOR SELECT TO authenticated
USING (id = auth.uid());

-- Admins can read all profiles
CREATE POLICY "admins_read_all_profiles" ON public.profiles
FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));
