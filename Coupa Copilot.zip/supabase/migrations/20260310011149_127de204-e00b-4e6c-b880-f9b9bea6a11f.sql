
-- Add tsvector column for full-text search
ALTER TABLE public.knowledge_chunks ADD COLUMN IF NOT EXISTS search_vector tsvector;

-- Create GIN index for fast FTS
CREATE INDEX IF NOT EXISTS idx_knowledge_chunks_search_vector ON public.knowledge_chunks USING gin(search_vector);

-- Create trigger to auto-populate search_vector on insert/update
CREATE OR REPLACE FUNCTION public.knowledge_chunks_search_vector_update()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public'
AS $$
BEGIN
  NEW.search_vector := to_tsvector('english', COALESCE(NEW.content, ''));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS knowledge_chunks_search_vector_trigger ON public.knowledge_chunks;
CREATE TRIGGER knowledge_chunks_search_vector_trigger
  BEFORE INSERT OR UPDATE OF content ON public.knowledge_chunks
  FOR EACH ROW
  EXECUTE FUNCTION public.knowledge_chunks_search_vector_update();

-- Populate search_vector for existing rows
UPDATE public.knowledge_chunks SET search_vector = to_tsvector('english', COALESCE(content, ''));

-- Create FTS matching function
CREATE OR REPLACE FUNCTION public.match_knowledge_chunks_fts(
  search_query text,
  match_count integer DEFAULT 5
)
RETURNS TABLE(id uuid, content text, source_id uuid, metadata jsonb, similarity double precision)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  tsquery_val tsquery;
BEGIN
  -- Convert search query to tsquery with prefix matching
  tsquery_val := plainto_tsquery('english', search_query);
  
  RETURN QUERY
  SELECT
    kc.id,
    kc.content,
    kc.source_id,
    kc.metadata,
    ts_rank_cd(kc.search_vector, tsquery_val)::double precision AS similarity
  FROM public.knowledge_chunks kc
  WHERE kc.search_vector @@ tsquery_val
  ORDER BY ts_rank_cd(kc.search_vector, tsquery_val) DESC
  LIMIT match_count;
END;
$$;
