
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, area_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    CASE 
      WHEN NEW.raw_user_meta_data->>'area_id' IS NOT NULL 
        AND NEW.raw_user_meta_data->>'area_id' != '' 
      THEN (NEW.raw_user_meta_data->>'area_id')::uuid 
      ELSE NULL 
    END
  );
  RETURN NEW;
END;
$function$;
