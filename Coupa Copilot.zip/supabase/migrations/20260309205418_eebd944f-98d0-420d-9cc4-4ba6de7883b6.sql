
-- Fix conversations: owner-scoped
DROP POLICY IF EXISTS "Allow all access to conversations" ON public.conversations;
CREATE POLICY "conversations_owner" ON public.conversations
  FOR ALL TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Fix messages: scoped through conversation ownership
DROP POLICY IF EXISTS "Allow all access to messages" ON public.messages;
CREATE POLICY "messages_owner" ON public.messages
  FOR ALL TO authenticated
  USING (
    conversation_id IN (
      SELECT id FROM public.conversations WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    conversation_id IN (
      SELECT id FROM public.conversations WHERE user_id = auth.uid()
    )
  );

-- Fix message_feedback: scoped through message -> conversation ownership
DROP POLICY IF EXISTS "Allow all feedback" ON public.message_feedback;
CREATE POLICY "feedback_owner" ON public.message_feedback
  FOR ALL TO authenticated
  USING (
    message_id IN (
      SELECT m.id FROM public.messages m
      JOIN public.conversations c ON c.id = m.conversation_id
      WHERE c.user_id = auth.uid()
    )
  )
  WITH CHECK (
    message_id IN (
      SELECT m.id FROM public.messages m
      JOIN public.conversations c ON c.id = m.conversation_id
      WHERE c.user_id = auth.uid()
    )
  );
