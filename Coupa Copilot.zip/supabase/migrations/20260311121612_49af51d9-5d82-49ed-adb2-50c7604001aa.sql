
-- Table to store API credentials securely
CREATE TABLE public.api_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text UNIQUE NOT NULL,
  value text NOT NULL DEFAULT '',
  masked_hint text NOT NULL DEFAULT '',
  is_sensitive boolean NOT NULL DEFAULT true,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.api_credentials ENABLE ROW LEVEL SECURITY;

-- Only admins can manage credentials
CREATE POLICY "admins_manage_credentials" ON public.api_credentials
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Seed with the 3 credential keys (empty values, admin will fill via UI)
INSERT INTO public.api_credentials (key_name, is_sensitive, masked_hint) VALUES
  ('COUPA_INSTANCE_URL', false, ''),
  ('COUPA_CLIENT_ID', true, ''),
  ('COUPA_CLIENT_SECRET', true, '');
