
CREATE TABLE public.api_scopes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.api_scopes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read api_scopes"
  ON public.api_scopes FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can manage api_scopes"
  ON public.api_scopes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.api_scopes (name, description) VALUES
  ('get_requisition', 'Buscar requisição por ID'),
  ('get_purchase_order', 'Buscar pedido de compra por ID'),
  ('search_requisitions', 'Pesquisar requisições com filtros'),
  ('search_purchase_orders', 'Pesquisar pedidos com filtros');
