-- 1. Replace trigger function to use 'simple' config (language-agnostic)
CREATE OR REPLACE FUNCTION public.knowledge_chunks_search_vector_update()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
BEGIN
  NEW.search_vector := to_tsvector('simple', COALESCE(NEW.content, ''));
  RETURN NEW;
END;
$function$;

-- 2. Replace FTS search function to use 'simple' + websearch_to_tsquery
CREATE OR REPLACE FUNCTION public.match_knowledge_chunks_fts(search_query text, match_count integer DEFAULT 5)
 RETURNS TABLE(id uuid, content text, source_id uuid, metadata jsonb, similarity double precision)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  tsquery_val tsquery;
BEGIN
  tsquery_val := websearch_to_tsquery('simple', search_query);
  
  RETURN QUERY
  SELECT
    kc.id,
    kc.content,
    kc.source_id,
    kc.metadata,
    ts_rank_cd(kc.search_vector, tsquery_val)::double precision AS similarity
  FROM public.knowledge_chunks kc
  WHERE kc.search_vector @@ tsquery_val
  ORDER BY ts_rank_cd(kc.search_vector, tsquery_val) DESC
  LIMIT match_count;
END;
$function$;

-- 3. Reindex all existing chunks with 'simple' config
UPDATE public.knowledge_chunks
SET search_vector = to_tsvector('simple', COALESCE(content, ''));