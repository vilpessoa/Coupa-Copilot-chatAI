
-- Delete orphaned conversations with null user_id (old test data)
DELETE FROM public.conversations WHERE user_id IS NULL;

-- Make user_id NOT NULL
ALTER TABLE public.conversations ALTER COLUMN user_id SET NOT NULL;
ALTER TABLE public.conversations ALTER COLUMN user_id SET DEFAULT auth.uid();
