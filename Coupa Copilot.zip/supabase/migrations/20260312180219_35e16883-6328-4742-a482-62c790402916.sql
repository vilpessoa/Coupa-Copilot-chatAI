
CREATE TABLE public.scope_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_scope_id UUID NOT NULL REFERENCES public.api_scopes(id) ON DELETE CASCADE,
  target_scope_id UUID NOT NULL REFERENCES public.api_scopes(id) ON DELETE CASCADE,
  relationship TEXT NOT NULL DEFAULT 'relacionado',
  description TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(source_scope_id, target_scope_id)
);

ALTER TABLE public.scope_connections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins_manage_scope_connections"
ON public.scope_connections
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "authenticated_read_scope_connections"
ON public.scope_connections
FOR SELECT
TO authenticated
USING (true);
