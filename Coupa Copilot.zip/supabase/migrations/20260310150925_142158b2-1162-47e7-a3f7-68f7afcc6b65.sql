-- Replace FTS function to use OR logic for more flexible matching
CREATE OR REPLACE FUNCTION public.match_knowledge_chunks_fts(search_query text, match_count integer DEFAULT 5)
 RETURNS TABLE(id uuid, content text, source_id uuid, metadata jsonb, similarity double precision)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  tsquery_val tsquery;
  words text[];
  or_query text;
BEGIN
  -- Split query into individual words and join with OR for flexible matching
  words := regexp_split_to_array(lower(trim(search_query)), '\s+');
  -- Filter out very short words (1-2 chars)
  words := ARRAY(SELECT unnest(words) WHERE length(unnest) > 2);
  
  IF array_length(words, 1) IS NULL OR array_length(words, 1) = 0 THEN
    RETURN;
  END IF;
  
  or_query := array_to_string(words, ' | ');
  tsquery_val := to_tsquery('simple', or_query);
  
  RETURN QUERY
  SELECT
    kc.id,
    kc.content,
    kc.source_id,
    kc.metadata,
    ts_rank_cd(kc.search_vector, tsquery_val)::double precision AS similarity
  FROM public.knowledge_chunks kc
  WHERE kc.search_vector @@ tsquery_val
  ORDER BY ts_rank_cd(kc.search_vector, tsquery_val) DESC
  LIMIT match_count;
END;
$function$;