ALTER TABLE public.knowledge_sources DROP CONSTRAINT IF EXISTS knowledge_sources_source_type_check;
ALTER TABLE public.knowledge_sources ADD CONSTRAINT knowledge_sources_source_type_check 
  CHECK (source_type = ANY (ARRAY['compass_docs','community','manual_upload','manual','file','excel','json','pdf']));