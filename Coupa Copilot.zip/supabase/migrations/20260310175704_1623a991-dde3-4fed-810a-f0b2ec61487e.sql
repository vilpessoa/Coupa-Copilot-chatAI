INSERT INTO public.system_prompt_config (key, value)
VALUES ('chat_model', 'openai/gpt-5')
ON CONFLICT (key) DO NOTHING;