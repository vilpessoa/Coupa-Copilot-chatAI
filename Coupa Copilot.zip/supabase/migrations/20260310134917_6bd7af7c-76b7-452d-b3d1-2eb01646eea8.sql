
CREATE TABLE public.tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  icon text DEFAULT 'lightbulb',
  is_active boolean NOT NULL DEFAULT true,
  priority integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.tips ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone_read_tips" ON public.tips FOR SELECT TO authenticated USING (true);
CREATE POLICY "admins_manage_tips" ON public.tips FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

INSERT INTO public.tips (title, description, icon, priority) VALUES
('Contratos', 'Você sabia que pode perguntar sobre contratos e seus termos?', 'file-text', 1),
('Fornecedores', 'Pesquise informações sobre seus fornecedores diretamente no chat.', 'users', 2),
('Relatórios', 'Peça resumos de gastos por período ou categoria.', 'bar-chart-3', 3),
('Aprovações', 'Consulte o status das suas aprovações pendentes em tempo real.', 'clipboard-check', 4);
