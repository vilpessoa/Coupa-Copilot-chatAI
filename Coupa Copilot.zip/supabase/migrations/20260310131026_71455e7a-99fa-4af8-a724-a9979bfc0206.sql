
-- Design config table
CREATE TABLE public.design_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL DEFAULT '',
  updated_at timestamptz DEFAULT now(),
  updated_by uuid
);

ALTER TABLE public.design_config ENABLE ROW LEVEL SECURITY;

-- Admins can read/write
CREATE POLICY "admins_manage_design" ON public.design_config
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- All authenticated users can read (needed for UI rendering)
CREATE POLICY "authenticated_read_design" ON public.design_config
  FOR SELECT TO authenticated
  USING (true);

-- Storage bucket for design assets
INSERT INTO storage.buckets (id, name, public) VALUES ('design-assets', 'design-assets', true);

-- Allow admins to upload to design-assets
CREATE POLICY "admins_upload_design_assets" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'design-assets' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admins_update_design_assets" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'design-assets' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admins_delete_design_assets" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'design-assets' AND public.has_role(auth.uid(), 'admin'));

-- Public read for design assets
CREATE POLICY "public_read_design_assets" ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'design-assets');

-- Insert default config values
INSERT INTO public.design_config (key, value) VALUES
  ('app_name', 'Coupa Copilot'),
  ('bot_avatar_url', ''),
  ('logo_url', ''),
  ('primary_color', '');
