
CREATE TABLE public.system_prompt_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL,
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id)
);
ALTER TABLE public.system_prompt_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins_manage_prompt" ON public.system_prompt_config
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Update source_type constraint for excel/json
ALTER TABLE public.knowledge_sources DROP CONSTRAINT IF EXISTS knowledge_sources_source_type_check;
ALTER TABLE public.knowledge_sources ADD CONSTRAINT knowledge_sources_source_type_check 
  CHECK (source_type = ANY (ARRAY['compass_docs'::text, 'community'::text, 'manual_upload'::text, 'manual'::text, 'file'::text, 'excel'::text, 'json'::text]));
