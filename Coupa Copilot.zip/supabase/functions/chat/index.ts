import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ═══════════════════════════════════════════
// COUPA API CLIENT — OAuth 2.0 + REST
// ═══════════════════════════════════════════
class CoupaAPI {
  private instanceUrl: string = "";
  private clientId: string = "";
  private clientSecret: string = "";
  private accessToken: string | null = null;
  private tokenExpiresAt = 0;
  private _initialized = false;

  async init() {
    if (this._initialized) return;
    this._initialized = true;

    try {
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const sb = createClient(supabaseUrl, serviceKey);
      const { data } = await sb.from("api_credentials").select("key_name, value");
      if (data?.length) {
        for (const row of data) {
          if (row.value) {
            if (row.key_name === "COUPA_INSTANCE_URL") this.instanceUrl = row.value.replace(/\/$/, "");
            else if (row.key_name === "COUPA_CLIENT_ID") this.clientId = row.value;
            else if (row.key_name === "COUPA_CLIENT_SECRET") this.clientSecret = row.value;
          }
        }
      }
    } catch (e) {
      console.warn("Failed to load credentials from DB, falling back to env vars:", e);
    }

    if (!this.instanceUrl) this.instanceUrl = (Deno.env.get("COUPA_INSTANCE_URL") || "").replace(/\/$/, "");
    if (!this.clientId) this.clientId = Deno.env.get("COUPA_CLIENT_ID") || "";
    if (!this.clientSecret) this.clientSecret = Deno.env.get("COUPA_CLIENT_SECRET") || "";
  }

  isConfigured(): boolean {
    return !!(this.instanceUrl && this.clientId && this.clientSecret);
  }

  private async getToken(): Promise<string> {
    if (this.accessToken && Date.now() < this.tokenExpiresAt) {
      return this.accessToken;
    }
    const response = await fetch(`${this.instanceUrl}/oauth2/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "client_credentials",
        client_id: this.clientId,
        client_secret: this.clientSecret,
      }),
    });
    if (!response.ok) {
      const txt = await response.text();
      console.error(`Coupa auth failed (${response.status}):`, txt);
      throw new Error("Coupa authentication failed");
    }
    const data = await response.json();
    this.accessToken = data.access_token;
    this.tokenExpiresAt = Date.now() + (data.expires_in * 1000) - 60000;
    return this.accessToken!;
  }

  async request(endpoint: string): Promise<any> {
    const token = await this.getToken();
    const url = `${this.instanceUrl}/api${endpoint}`;
    console.log(`Coupa API → GET ${url}`);
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
    });
    if (!response.ok) {
      const txt = await response.text();
      throw new Error(`Coupa API error ${response.status}: ${txt}`);
    }
    return response.json();
  }
}

const coupa = new CoupaAPI();

// ═══════════════════════════════════════════
// HELPERS — text normalization
// ═══════════════════════════════════════════
function normalize(s: string): string {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}

const NAME_STOPWORDS = new Set(["da", "de", "do", "dos", "das", "e"]);

function nameTokens(input: string): string[] {
  return normalize(input)
    .split(" ")
    .filter(t => t.length > 2 && !NAME_STOPWORDS.has(t));
}

function tokenMatchCount(candidate: string, tokens: string[]): number {
  if (!candidate || !tokens.length) return 0;
  const norm = normalize(candidate);
  const uniqueTokens = [...new Set(tokens)];
  return uniqueTokens.filter(t => norm.includes(t)).length;
}

function nameMatches(candidate: string, tokens: string[]): boolean {
  if (!candidate || !tokens.length) return false;
  const uniqueTokens = [...new Set(tokens)];
  const matches = tokenMatchCount(candidate, uniqueTokens);
  if (matches === 0) return false;
  if (uniqueTokens.length === 1) return true;

  const norm = normalize(candidate);
  const firstTokenMatches = norm.includes(uniqueTokens[0]);
  const ratio = matches / uniqueTokens.length;

  // Relaxed matching to tolerate name variations (e.g. missing middle names)
  return firstTokenMatches && (ratio >= 0.5 || matches >= 2);
}

// ═══════════════════════════════════════════
// USER LOOKUP — resolve name/email to Coupa user ID
// ═══════════════════════════════════════════
async function lookupCoupaUser(api: CoupaAPI, email?: string, fullname?: string): Promise<{ id: number; login: string; fullname: string } | null> {
  const queries: Promise<any[]>[] = [];
  const labels: string[] = [];

  // 1. Exact email
  if (email) {
    queries.push(api.request(`/users?email=${encodeURIComponent(email)}&limit=1`).then(d => Array.isArray(d) ? d : [d]).catch(() => []));
    labels.push(`email=${email}`);
  }

  // 2. Login prefix from email (e.g. ligia.silva)
  if (email && email.includes("@")) {
    const loginPrefix = email.split("@")[0];
    queries.push(api.request(`/users?login=${encodeURIComponent(loginPrefix)}&limit=1`).then(d => Array.isArray(d) ? d : [d]).catch(() => []));
    labels.push(`login=${loginPrefix}`);
  }

  // 3. Exact fullname
  if (fullname) {
    queries.push(api.request(`/users?fullname=${encodeURIComponent(fullname)}&limit=5`).then(d => Array.isArray(d) ? d : [d]).catch(() => []));
    labels.push(`fullname=${fullname}`);
  }

  // 4. Token-based fullname search (first + last name variations)
  const tokens = nameTokens(fullname || (email ? email.split("@")[0].replace(/[._]/g, " ") : ""));
  if (tokens.length >= 1) {
    // Try first token as login contains
    queries.push(api.request(`/users?login[contains]=${encodeURIComponent(tokens[0])}&limit=10`).then(d => Array.isArray(d) ? d : [d]).catch(() => []));
    labels.push(`login[contains]=${tokens[0]}`);

    // Try fullname contains with first+last tokens
    if (tokens.length >= 2) {
      const fnSearch = `${tokens[0]} ${tokens[tokens.length - 1]}`;
      queries.push(api.request(`/users?fullname[contains]=${encodeURIComponent(fnSearch)}&limit=10`).then(d => Array.isArray(d) ? d : [d]).catch(() => []));
      labels.push(`fullname[contains]=${fnSearch}`);
    }
  }

  if (!queries.length) return null;

  const results = await Promise.all(queries);

  // Check exact matches first (email, login prefix, fullname)
  for (let i = 0; i < results.length; i++) {
    const batch = results[i];
    if (batch.length > 0 && batch[0]?.id) {
      // For broad searches (contains), verify token match
      if (labels[i].includes("[contains]") && tokens.length >= 2) {
        const match = batch.find((u: any) => {
          const uName = u.fullname || u["full-name"] || u.login || "";
          return nameMatches(uName, tokens);
        });
        if (match) {
          console.log(`lookupCoupaUser: found via ${labels[i]} → id=${match.id}, login=${match.login}`);
          return { id: match.id, login: match.login || "", fullname: match.fullname || match["full-name"] || "" };
        }
        continue; // broad search didn't match well enough
      }
      const u = batch[0];
      console.log(`lookupCoupaUser: found via ${labels[i]} → id=${u.id}, login=${u.login}`);
      return { id: u.id, login: u.login || "", fullname: u.fullname || u["full-name"] || "" };
    }
  }

  if (fullname) {
    const candidates = await findCoupaUserCandidates(api, fullname);
    if (candidates.length > 0) {
      const [top, second] = candidates;
      const isClearlyBest = !second || (top.match_score >= 0.5 && (top.match_score - second.match_score) >= 0.15);
      if (isClearlyBest) {
        console.log(`lookupCoupaUser: fuzzy match selected id=${top.id}, login=${top.login}, score=${top.match_score.toFixed(2)}`);
        return { id: top.id, login: top.login, fullname: top.fullname };
      }
      console.log(`lookupCoupaUser: ambiguous fuzzy matches for "${fullname}" (${candidates.length} candidates)`);
    }
  }

  console.log(`lookupCoupaUser: no user found (tried ${labels.join(", ")})`);
  return null;
}

async function findCoupaUserCandidates(api: CoupaAPI, query: string): Promise<Array<{ id: number; login: string; fullname: string; match_score: number }>> {
  const tokens = nameTokens(query);
  if (!tokens.length) return [];

  const firstToken = tokens[0];
  const lookups = await Promise.all([
    api.request(`/users?fullname[contains]=${encodeURIComponent(firstToken)}&limit=25`).then(d => Array.isArray(d) ? d : [d]).catch(() => []),
    api.request(`/users?login[contains]=${encodeURIComponent(firstToken)}&limit=25`).then(d => Array.isArray(d) ? d : [d]).catch(() => []),
  ]);

  const byId = new Map<number, { id: number; login: string; fullname: string; match_score: number }>();
  for (const batch of lookups) {
    for (const u of batch) {
      if (!u?.id) continue;
      const fullname = u.fullname || u["full-name"] || "";
      const login = u.login || "";
      const bestCandidateName = fullname || login;
      const matchCount = tokenMatchCount(bestCandidateName, tokens);
      if (matchCount === 0) continue;
      const matchScore = Math.min(1, matchCount / Math.max(tokens.length, 1));

      const existing = byId.get(u.id);
      if (!existing || matchScore > existing.match_score) {
        byId.set(u.id, {
          id: u.id,
          login,
          fullname,
          match_score: matchScore,
        });
      }
    }
  }

  return Array.from(byId.values()).sort((a, b) => b.match_score - a.match_score);
}


// ═══════════════════════════════════════════
function formatPersonName(raw: string | null | undefined): string | null {
  if (!raw || typeof raw !== "string") return null;
  let name = raw.trim();
  if (!name) return null;

  // 1. Remove code prefixes like "7Q - ", "XU - ", "ABC1 - "
  name = name.replace(/^[A-Z0-9]{1,4}\s*-\s*/i, "");

  // 2. If it looks like a login (contains dots, no spaces), convert
  if (/^[a-z0-9._]+$/i.test(name) && name.includes(".")) {
    const parts = name.split(".")
      .filter(p => p.length > 1) // remove single-letter initials like "s" in "mauro.s.santos"
      .map(p => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase());
    return parts.join(" ") || name;
  }

  // 3. Remove standalone single-letter initials (V, A, M) but keep "A." style
  //    Keep first and last name, remove middle initials without dots
  const words = name.split(/\s+/);
  const cleaned = words.filter((w, i) => {
    // Keep first and last word always
    if (i === 0 || i === words.length - 1) return true;
    // Remove single uppercase letter without dot (middle initial like "V")
    if (/^[A-Z]$/.test(w)) return false;
    // Remove "A." or "M." style middle initials
    if (/^[A-Z]\.$/.test(w)) return false;
    return true;
  });

  // 4. Title Case
  return cleaned.map(w => {
    if (w.length <= 2 && w.endsWith(".")) return w.toUpperCase(); // keep "A." as-is
    return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
  }).join(" ");
}

// ═══════════════════════════════════════════
// TOOL REGISTRY — maps scope names → tool defs
// ═══════════════════════════════════════════
const TOOL_REGISTRY: Record<string, any> = {
  get_requisition: {
    type: "function",
    function: {
      name: "get_requisition",
      description: "Busca uma requisição de compra pelo ID no Coupa.",
      parameters: {
        type: "object",
        properties: { id: { type: "number", description: "ID numérico da requisição" } },
        required: ["id"], additionalProperties: false,
      },
    },
  },
  get_purchase_order: {
    type: "function",
    function: {
      name: "get_purchase_order",
      description: "Busca um pedido de compra (PO) pelo ID no Coupa.",
      parameters: {
        type: "object",
        properties: { id: { type: "number", description: "ID numérico do pedido de compra" } },
        required: ["id"], additionalProperties: false,
      },
    },
  },
  search_requisitions: {
    type: "function",
    function: {
      name: "search_requisitions",
      description: "Busca requisições com filtros. Use para listar requisições pendentes, por status, por período. Quando o usuário se referir a 'minhas', use requested_by com o email do usuário logado.",
      parameters: {
        type: "object",
        properties: {
          status: { type: "string", description: "Filtrar por status: draft, pending_approval, approved, ordered, received, etc." },
          date_from: { type: "string", description: "Data inicial ISO 8601" },
          date_to: { type: "string", description: "Data final ISO 8601" },
          requested_by: { type: "string", description: "Login ou email do solicitante" },
        },
        additionalProperties: false,
      },
    },
  },
  search_purchase_orders: {
    type: "function",
    function: {
      name: "search_purchase_orders",
      description: "Busca pedidos de compra com filtros. Quando o usuário se referir a 'meus', use requested_by com o email do usuário logado.",
      parameters: {
        type: "object",
        properties: {
          status: { type: "string", description: "Filtrar por status: draft, issued, soft_closed, closed, cancelled" },
          requested_by: { type: "string", description: "Login ou email do solicitante" },
        },
        additionalProperties: false,
      },
    },
  },
  get_supplier: {
    type: "function",
    function: {
      name: "get_supplier",
      description: "Busca um fornecedor pelo ID INTERNO do Coupa (não é o número do fornecedor). Para buscar por número do fornecedor, CNPJ ou nome, use search_suppliers.",
      parameters: {
        type: "object",
        properties: { id: { type: "number", description: "ID interno numérico do fornecedor no Coupa (não é o supplier number)" } },
        required: ["id"], additionalProperties: false,
      },
    },
  },
  search_suppliers: {
    type: "function",
    function: {
      name: "search_suppliers",
      description: "Busca fornecedores com filtros. Use 'number' para buscar pelo número/código do fornecedor, 'tax_id' para CNPJ/Tax ID, 'name' para nome, 'status' para status. Quando o usuário informar um código numérico de fornecedor, use o campo 'number'.",
      parameters: {
        type: "object",
        properties: {
          name: { type: "string", description: "Nome ou parte do nome do fornecedor" },
          number: { type: "string", description: "Número/código do fornecedor (supplier number) — busca exata" },
          tax_id: { type: "string", description: "CNPJ, Tax ID ou DUNS do fornecedor — busca exata" },
          status: { type: "string", description: "Filtrar por status: active, inactive" },
        },
        additionalProperties: false,
      },
    },
  },
  get_invoice: {
    type: "function",
    function: {
      name: "get_invoice",
      description: "Busca uma fatura/invoice pelo ID no Coupa.",
      parameters: {
        type: "object",
        properties: { id: { type: "number", description: "ID numérico da fatura" } },
        required: ["id"], additionalProperties: false,
      },
    },
  },
  search_invoices: {
    type: "function",
    function: {
      name: "search_invoices",
      description: "Busca faturas/invoices com filtros.",
      parameters: {
        type: "object",
        properties: {
          status: { type: "string", description: "Filtrar por status: draft, pending_approval, approved, voided, disputed" },
          supplier_name: { type: "string", description: "Nome do fornecedor" },
        },
        additionalProperties: false,
      },
    },
  },
  get_contract: {
    type: "function",
    function: {
      name: "get_contract",
      description: "Busca um contrato pelo ID no Coupa.",
      parameters: {
        type: "object",
        properties: { id: { type: "number", description: "ID numérico do contrato" } },
        required: ["id"], additionalProperties: false,
      },
    },
  },
  search_contracts: {
    type: "function",
    function: {
      name: "search_contracts",
      description: "Busca contratos com filtros.",
      parameters: {
        type: "object",
        properties: {
          status: { type: "string", description: "Filtrar por status: draft, published, expired, closed" },
          supplier_name: { type: "string", description: "Nome do fornecedor" },
        },
        additionalProperties: false,
      },
    },
  },
  search_approvals: {
    type: "function",
    function: {
      name: "search_approvals",
      description: "Busca aprovações pendentes ou históricas. Use para verificar quem precisa aprovar uma requisição, PO ou fatura, ou para verificar se um documento já foi aprovado. Pode filtrar por approvable_id, approvable_type, status, e pelo aprovador (email, nome ou login). Quando o usuário perguntar por aprovações pendentes DE um aprovador específico, use approver_email ou approver_name.",
      parameters: {
        type: "object",
        properties: {
          approvable_id: { type: "number", description: "ID do documento (requisição, PO, fatura) para buscar suas aprovações" },
          approvable_type: { type: "string", description: "Tipo do documento: RequisitionHeader, OrderHeader, InvoiceHeader" },
          status: { type: "string", description: "Filtrar por status: pending_approval, approved, rejected" },
          approver_email: { type: "string", description: "Email do aprovador (ex: ligia.silva@brainfarma.ind.br)" },
          approver_login: { type: "string", description: "Login do aprovador no Coupa (se conhecido, ex: m7_ligianvsilva)" },
          approver_name: { type: "string", description: "Nome completo do aprovador (ex: Ligia Do Nascimento Vieira Da Silva)" },
          requested_by: { type: "string", description: "Email ou login do solicitante (para buscar documentos pendentes de aprovação de um solicitante específico)" },
        },
        additionalProperties: false,
      },
    },
  },
  search_items: {
    type: "function",
    function: {
      name: "search_items",
      description: "Busca itens no catálogo/base de itens do Coupa. Use para encontrar materiais, produtos ou serviços disponíveis. Pode buscar por descrição, nome ou status.",
      parameters: {
        type: "object",
        properties: {
          description: { type: "string", description: "Nome ou descrição do item para busca (ex: 'papel A4', 'toner', 'caneta')" },
          active: { type: "boolean", description: "Filtrar apenas itens ativos (true) ou inativos (false)" },
        },
        additionalProperties: false,
      },
    },
  },
  get_item: {
    type: "function",
    function: {
      name: "get_item",
      description: "Busca um item específico pelo ID no Coupa.",
      parameters: {
        type: "object",
        properties: { id: { type: "number", description: "ID numérico do item" } },
        required: ["id"], additionalProperties: false,
      },
    },
  },
};

// ═══════════════════════════════════════════
// TOOL EXECUTION
// ═══════════════════════════════════════════
function validateId(id: any): number {
  const str = String(id);
  if (!/^\d+$/.test(str)) throw new Error("Invalid ID format");
  return parseInt(str, 10);
}

const VALID_REQ_STATUSES = new Set([
  "draft", "cart", "pending_buyer_action", "pending_approval",
  "approved", "ordered", "partially_received", "received",
  "abandoned", "withdrawn", "rejected",
]);
const VALID_PO_STATUSES = new Set(["draft", "issued", "soft_closed", "closed", "cancelled"]);
const VALID_SUPPLIER_STATUSES = new Set(["active", "inactive"]);
const VALID_INVOICE_STATUSES = new Set(["draft", "pending_approval", "approved", "voided", "disputed"]);
const VALID_CONTRACT_STATUSES = new Set(["draft", "published", "expired", "closed"]);
const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function validateStatus(status: string, allowed: Set<string>): string {
  const parts = status.split(",").map(s => s.trim()).filter(Boolean);
  for (const p of parts) {
    if (!allowed.has(p)) throw new Error(`Invalid status value: ${p}`);
  }
  return parts.join(",");
}

function validateDate(d: string): string {
  if (!ISO_DATE_RE.test(d)) throw new Error("Invalid date format");
  return d;
}

function summarizeRequisition(r: any) {
  const summary: any = {
    id: r.id, status: r.status, title: r.title,
    created_at: r["created-at"], updated_at: r["updated-at"],
    requested_by: formatPersonName(r["requested-by"]?.fullname || r["requested-by"]?.login),
    department: r.department?.name,
    total: r["estimated-total"]?.amount ? `${r["estimated-total"].amount} ${r["estimated-total"].currency}` : null,
    line_count: r["requisition-lines"]?.length || 0,
    // Cross-reference IDs for multi-tool intelligence
    supplier_id: r.supplier?.id || r["requisition-lines"]?.[0]?.supplier?.id || null,
    supplier_name: r.supplier?.name || r["requisition-lines"]?.[0]?.supplier?.name || null,
    lines: Array.isArray(r["requisition-lines"])
      ? r["requisition-lines"].slice(0, 10).map((l: any, i: number) => ({
          line: l["line-num"] ?? i + 1,
          description: l.description || l["item"]?.name || null,
          quantity: l.quantity ?? null,
          unit_price: l["unit-price"]?.amount ?? l["unit-price"] ?? null,
          total: l["total"]?.amount ? `${l["total"].amount} ${l["total"].currency || ""}`.trim() : null,
          currency: l["currency"]?.code || l["total"]?.currency || l["unit-price"]?.currency || null,
          supplier: l.supplier?.name || null,
          commodity: l.commodity?.name || null,
          need_by_date: l["need-by-date"] || null,
        }))
      : [],
  };
  // Enrich with approval data if available
  if (r["current-approval"]) {
    const ca = r["current-approval"];
    summary.current_approval = {
      status: ca.status,
      approver: formatPersonName(ca.approver?.fullname || ca.approver?.login || ca.approver?.name),
      position: ca.position,
      created_at: ca["created-at"],
    };
  }
  if (r["approval-chain"] || r["approvals"]) {
    const chain = r["approval-chain"] || r["approvals"];
    if (Array.isArray(chain) && chain.length > 0) {
      summary.approval_chain = chain.map((a: any) => ({
        status: a.status,
        approver: formatPersonName(a.approver?.fullname || a.approver?.login || a.approver?.name),
        position: a.position,
        approved_at: a["approved-at"] || a["updated-at"],
      }));
    }
  }
  return summary;
}

const APPROVABLE_TYPE_LABELS: Record<string, string> = {
  "RequisitionHeader": "Requisição",
  "OrderHeader": "Pedido de Compra",
  "InvoiceHeader": "Fatura",
  "OrderHeaderChangesVersion": "Alteração de Pedido",
  "ExpenseReport": "Relatório de Despesas",
};

function approvableIdLabel(type: string): string {
  if (type === "RequisitionHeader") return "requisicao";
  if (type === "OrderHeader" || type === "OrderHeaderChangesVersion") return "pedido";
  if (type === "InvoiceHeader") return "fatura";
  return "documento";
}

function summarizeApproval(a: any, enrichment?: any) {
  const type = a["approvable-type"] || "";
  const idLabel = approvableIdLabel(type);
  const result: any = {
    tipo: APPROVABLE_TYPE_LABELS[type] || type,
    [`${idLabel}_id`]: a["approvable-id"],
    status: a.status,
    aprovador: formatPersonName(a.approver?.fullname || a.approver?.login || a.approver?.name || a.approver?.email),
    posicao: a.position,
    criado_em: a["created-at"],
  };
  if (a.status !== "pending_approval") {
    result.aprovado_em = a["approved-at"] || a["updated-at"] || a["approval-date"];
  }
  // Merge enrichment data from the approvable document
  if (enrichment) {
    if (enrichment.solicitante) result.solicitante = enrichment.solicitante;
    if (enrichment.valor_total) result.valor_total = enrichment.valor_total;
    if (enrichment.fornecedor) result.fornecedor = enrichment.fornecedor;
    if (enrichment.departamento) result.departamento = enrichment.departamento;
    if (enrichment.itens) result.itens = enrichment.itens;
    if (enrichment.titulo) result.titulo = enrichment.titulo;
  }
  return result;
}

// Fetch enrichment data for approvable documents (requisitions, POs, etc.)
async function enrichApprovables(api: CoupaAPI, approvals: any[]): Promise<Map<string, any>> {
  const enrichments = new Map<string, any>();
  // Group by approvable-type + approvable-id to avoid duplicate fetches
  const toFetch = new Map<string, { type: string; id: number }>();
  for (const a of approvals) {
    const type = a["approvable-type"];
    const id = a["approvable-id"];
    if (type && id) {
      const key = `${type}:${id}`;
      if (!toFetch.has(key)) toFetch.set(key, { type, id });
    }
  }

  const typeEndpoints: Record<string, string> = {
    "RequisitionHeader": "/requisitions",
    "OrderHeader": "/purchase_orders",
    "InvoiceHeader": "/invoices",
  };

  const fetches = Array.from(toFetch.entries()).map(async ([key, { type, id }]) => {
    const endpoint = typeEndpoints[type];
    if (!endpoint) return;
    try {
      const doc = await api.request(`${endpoint}/${id}`);
      const enrichment: any = {};
      
      if (type === "RequisitionHeader") {
        enrichment.solicitante = formatPersonName(doc["requested-by"]?.fullname || doc["requested-by"]?.login);
        enrichment.valor_total = doc["estimated-total"]?.amount ? `${doc["estimated-total"].amount} ${doc["estimated-total"].currency || ""}`.trim() : null;
        enrichment.departamento = doc.department?.name || null;
        enrichment.titulo = doc.title || null;
        // Compile items
        const lines = doc["requisition-lines"];
        if (Array.isArray(lines) && lines.length > 0) {
          enrichment.itens = lines.slice(0, 8).map((l: any) => {
            const qty = l.quantity ?? 1;
            const desc = l.description || l.item?.name || "Item";
            const supplier = l.supplier?.name;
            return supplier ? `${qty}x ${desc} (${supplier})` : `${qty}x ${desc}`;
          }).join(", ");
          enrichment.fornecedor = lines[0]?.supplier?.name || doc.supplier?.name || null;
        }
      } else if (type === "OrderHeader") {
        enrichment.solicitante = formatPersonName(doc["requested-by"]?.fullname || doc["requested-by"]?.login);
        enrichment.valor_total = doc.total?.amount ? `${doc.total.amount} ${doc.total.currency || ""}`.trim() : null;
        enrichment.fornecedor = doc.supplier?.name || null;
        const lines = doc["order-lines"];
        if (Array.isArray(lines) && lines.length > 0) {
          enrichment.itens = lines.slice(0, 8).map((l: any) => {
            const qty = l.quantity ?? 1;
            const desc = l.description || l.item?.name || "Item";
            return `${qty}x ${desc}`;
          }).join(", ");
        }
      } else if (type === "InvoiceHeader") {
        enrichment.valor_total = doc.total?.amount ? `${doc.total.amount} ${doc.total.currency || ""}`.trim() : null;
        enrichment.fornecedor = doc.supplier?.name || null;
      }

      enrichments.set(key, enrichment);
    } catch (e) {
      console.warn(`Failed to enrich ${key}:`, e instanceof Error ? e.message : e);
    }
  });

  await Promise.all(fetches);
  return enrichments;
}

function summarizePO(po: any) {
  return {
    id: po.id, status: po.status, po_number: po["po-number"],
    created_at: po["created-at"], updated_at: po["updated-at"],
    supplier: po.supplier?.name,
    supplier_id: po.supplier?.id || null,
    requisition_id: po["requisition-header-id"] || po["requisition"]?.id || null,
    total: po.total?.amount ? `${po.total.amount} ${po.total.currency}` : null,
    ship_to: po["ship-to-address"]?.city,
    line_count: po["order-lines"]?.length || 0,
    lines: Array.isArray(po["order-lines"])
      ? po["order-lines"].slice(0, 10).map((l: any, i: number) => ({
          line: l["line-num"] ?? i + 1,
          description: l.description || l["item"]?.name || null,
          quantity: l.quantity ?? null,
          unit_price: l["price"]?.amount ?? l["unit-price"]?.amount ?? null,
          total: l["total"]?.amount ? `${l["total"].amount} ${l["total"].currency || ""}`.trim() : null,
          currency: l["currency"]?.code || l["total"]?.currency || null,
          supplier: l.supplier?.name || null,
          need_by_date: l["need-by-date"] || null,
        }))
      : [],
  };
}

function summarizeSupplier(s: any) {
  return {
    id: s.id, name: s.name, status: s.status,
    number: s.number, city: s["primary-address"]?.city,
    country: s["primary-address"]?.["country-code"],
    payment_term: s["payment-term"]?.code,
    created_at: s["created-at"],
  };
}

function summarizeItem(item: any) {
  return {
    id: item.id,
    name: item.name || item["item-name"] || null,
    description: item.description || null,
    status: item.active !== undefined ? (item.active ? "active" : "inactive") : (item.status || null),
    item_number: item["item-number"] || item.number || null,
    uom: item.uom?.code || item["unit-of-measure"]?.code || item.uom || null,
    price: item["list-price"]?.amount ? `${item["list-price"].amount} ${item["list-price"].currency || ""}`.trim() : null,
    supplier: item.supplier?.name || item["preferred-supplier"]?.name || null,
    supplier_id: item.supplier?.id || item["preferred-supplier"]?.id || null,
    commodity: item.commodity?.name || null,
    created_at: item["created-at"] || null,
  };
}

interface ToolContext {
  userEmail?: string;
  userFullName?: string;
}

async function executeTool(name: string, args: any, context?: ToolContext): Promise<string> {
  try {
    switch (name) {
      case "get_requisition": {
        const id = validateId(args.id);
        return JSON.stringify(summarizeRequisition(await coupa.request(`/requisitions/${id}`)));
      }
      case "get_purchase_order": {
        const id = validateId(args.id);
        return JSON.stringify(summarizePO(await coupa.request(`/purchase_orders/${id}`)));
      }
      case "get_invoice": {
        const id = validateId(args.id);
        return JSON.stringify(await coupa.request(`/invoices/${id}`));
      }
      case "get_supplier": {
        const id = validateId(args.id);
        return JSON.stringify(summarizeSupplier(await coupa.request(`/suppliers/${id}`)));
      }
      case "get_contract": {
        const id = validateId(args.id);
        return JSON.stringify(await coupa.request(`/contracts/${id}`));
      }
      case "search_requisitions": {
        const baseParams: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.status) baseParams.push(`status=${validateStatus(args.status, VALID_REQ_STATUSES)}`);
        if (args.date_from) baseParams.push(`created-at[gt_or_eq]=${validateDate(args.date_from)}`);
        if (args.date_to) baseParams.push(`created-at[lt_or_eq]=${validateDate(args.date_to)}`);

        if (args.requested_by && String(args.requested_by).includes("@")) {
          // Multi-filter: email, login prefix, fullname — parallel
          const email = String(args.requested_by);
          const loginPrefix = email.split("@")[0];
          const fullName = context?.userFullName || "";
          const variations: string[] = [
            `requested-by[login]=${encodeURIComponent(email)}`,
            `requested-by[login]=${encodeURIComponent(loginPrefix)}`,
          ];
          if (fullName) variations.push(`requested-by[fullname]=${encodeURIComponent(fullName)}`);

          const results = await Promise.all(
            variations.map(async (filter) => {
              try {
                const params = [...baseParams, filter];
                const data = await coupa.request(`/requisitions?${params.join("&")}`);
                return Array.isArray(data) ? data : [];
              } catch { return []; }
            })
          );

          // Deduplicate by ID
          const seen = new Set<number>();
          const merged: any[] = [];
          for (const batch of results) {
            for (const r of batch) {
              if (!seen.has(r.id)) { seen.add(r.id); merged.push(r); }
            }
          }
          // Sort by created-at desc and cap
          merged.sort((a, b) => (b["created-at"] || "").localeCompare(a["created-at"] || ""));
          const items = merged.slice(0, 10).map(summarizeRequisition);
          return JSON.stringify({ results: items, count: items.length });
        }

        if (args.requested_by) baseParams.push(`requested-by[login]=${encodeURIComponent(String(args.requested_by))}`);
        const data = await coupa.request(`/requisitions?${baseParams.join("&")}`);
        const items = Array.isArray(data) ? data.map(summarizeRequisition) : data;
        return JSON.stringify({ results: items, count: Array.isArray(data) ? data.length : 1 });
      }
      case "search_purchase_orders": {
        const baseParams: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.status) baseParams.push(`status=${validateStatus(args.status, VALID_PO_STATUSES)}`);

        if (args.requested_by && String(args.requested_by).includes("@")) {
          const email = String(args.requested_by);
          const loginPrefix = email.split("@")[0];
          const fullName = context?.userFullName || "";
          const variations: string[] = [
            `requested-by[login]=${encodeURIComponent(email)}`,
            `requested-by[login]=${encodeURIComponent(loginPrefix)}`,
          ];
          if (fullName) variations.push(`requested-by[fullname]=${encodeURIComponent(fullName)}`);

          const results = await Promise.all(
            variations.map(async (filter) => {
              try {
                const params = [...baseParams, filter];
                const data = await coupa.request(`/purchase_orders?${params.join("&")}`);
                return Array.isArray(data) ? data : [];
              } catch { return []; }
            })
          );

          const seen = new Set<number>();
          const merged: any[] = [];
          for (const batch of results) {
            for (const r of batch) {
              if (!seen.has(r.id)) { seen.add(r.id); merged.push(r); }
            }
          }
          merged.sort((a, b) => (b["created-at"] || "").localeCompare(a["created-at"] || ""));
          const items = merged.slice(0, 10).map(summarizePO);
          return JSON.stringify({ results: items, count: items.length });
        }

        if (args.requested_by) baseParams.push(`requested-by[login]=${encodeURIComponent(String(args.requested_by))}`);
        const data = await coupa.request(`/purchase_orders?${baseParams.join("&")}`);
        const items = Array.isArray(data) ? data.map(summarizePO) : data;
        return JSON.stringify({ results: items, count: Array.isArray(data) ? data.length : 1 });
      }
      case "search_purchase_orders": {
        const params: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.status) params.push(`status=${validateStatus(args.status, VALID_PO_STATUSES)}`);
        if (args.requested_by) params.push(`requested-by[login]=${encodeURIComponent(String(args.requested_by))}`);
        const data = await coupa.request(`/purchase_orders?${params.join("&")}`);
        const items = Array.isArray(data) ? data.map(summarizePO) : data;
        return JSON.stringify({ results: items, count: Array.isArray(data) ? data.length : 1 });
      }
      case "search_suppliers": {
        const params: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.name) params.push(`name[contains]=${encodeURIComponent(String(args.name))}`);
        if (args.number) params.push(`number=${encodeURIComponent(String(args.number))}`);
        if (args.tax_id) params.push(`tax-id=${encodeURIComponent(String(args.tax_id))}`);
        if (args.status) params.push(`status=${validateStatus(args.status, VALID_SUPPLIER_STATUSES)}`);
        const data = await coupa.request(`/suppliers?${params.join("&")}`);
        const items = Array.isArray(data) ? data.map(summarizeSupplier) : data;
        return JSON.stringify({ results: items, count: Array.isArray(data) ? data.length : 1 });
      }
      case "search_invoices": {
        const params: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.status) params.push(`status=${validateStatus(args.status, VALID_INVOICE_STATUSES)}`);
        if (args.supplier_name) params.push(`supplier[name][contains]=${encodeURIComponent(String(args.supplier_name))}`);
        const data = await coupa.request(`/invoices?${params.join("&")}`);
        return JSON.stringify({ results: Array.isArray(data) ? data : [data], count: Array.isArray(data) ? data.length : 1 });
      }
      case "search_contracts": {
        const params: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.status) params.push(`status=${validateStatus(args.status, VALID_CONTRACT_STATUSES)}`);
        if (args.supplier_name) params.push(`supplier[name][contains]=${encodeURIComponent(String(args.supplier_name))}`);
        const data = await coupa.request(`/contracts?${params.join("&")}`);
        return JSON.stringify({ results: Array.isArray(data) ? data : [data], count: Array.isArray(data) ? data.length : 1 });
      }
      case "search_approvals": {
        const baseParams: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.approvable_id) baseParams.push(`approvable-id=${validateId(args.approvable_id)}`);
        if (args.approvable_type) {
          const validTypes = new Set(["RequisitionHeader", "OrderHeader", "InvoiceHeader"]);
          if (!validTypes.has(args.approvable_type)) throw new Error("Invalid approvable_type");
          baseParams.push(`approvable-type=${args.approvable_type}`);
        }
        if (args.status) baseParams.push(`status=${validateStatus(args.status, new Set(["pending_approval", "approved", "rejected"]))}`);

        const hasApproverFilter = args.approver_email || args.approver_login || args.approver_name;

        if (hasApproverFilter) {
          const email = args.approver_email ? String(args.approver_email) : (args.approver_login ? String(args.approver_login) : "");
          const loginPrefix = email.includes("@") ? email.split("@")[0] : email;
          const approverName = args.approver_name ? String(args.approver_name) : "";

          // Step 1: Try direct approver filters (may all fail with 400)
          const variations: string[] = [];
          if (email) {
            variations.push(`approver[email]=${encodeURIComponent(email)}`);
            if (loginPrefix && loginPrefix !== email) {
              variations.push(`approver[login]=${encodeURIComponent(loginPrefix)}`);
            }
          }
          if (args.approver_login) {
            variations.push(`approver[login]=${encodeURIComponent(String(args.approver_login))}`);
          }
          if (approverName) {
            variations.push(`approver[fullname]=${encodeURIComponent(approverName)}`);
          }

          console.log(`search_approvals: trying ${variations.length} direct approver filter variations`);

          const results = await Promise.all(
            variations.map(async (filter) => {
              try {
                const params = [...baseParams, filter];
                const data = await coupa.request(`/approvals?${params.join("&")}`);
                return Array.isArray(data) ? data : [data];
              } catch (e) {
                console.warn(`Approver filter failed (${filter}):`, e instanceof Error ? e.message : e);
                return [];
              }
            })
          );

          const seen = new Set<number>();
          const merged: any[] = [];
          for (const batch of results) {
            for (const a of batch) {
              if (a?.id && !seen.has(a.id)) { seen.add(a.id); merged.push(a); }
            }
          }

          let ambiguityCandidates: Array<{ id: number | null; login: string; fullname: string; count?: number }> = [];

          // Step 2: If no results, lookup Coupa user by email/name to get real ID
          if (merged.length === 0) {
            console.log("search_approvals: direct filters returned 0 results, looking up Coupa user...");
            let coupaUser = await lookupCoupaUser(coupa, email || undefined, approverName || undefined);

            // If only a name was provided, proactively discover similar users for disambiguation
            if (!coupaUser && approverName && !email && !args.approver_login) {
              const candidates = await findCoupaUserCandidates(coupa, approverName);
              ambiguityCandidates = candidates.slice(0, 5).map(c => ({
                id: c.id,
                login: c.login,
                fullname: formatPersonName(c.fullname || c.login) || c.fullname || c.login,
              }));

              // If only one candidate exists, continue autonomously with that user
              if (candidates.length === 1) {
                coupaUser = {
                  id: candidates[0].id,
                  login: candidates[0].login,
                  fullname: candidates[0].fullname,
                };
                console.log(`search_approvals: single candidate auto-selected id=${coupaUser.id}`);
              }
            }

            if (coupaUser) {
              // Step 2a: Try approver[id]=<userId>
              try {
                console.log(`search_approvals: trying approver[id]=${coupaUser.id}`);
                const idParams = [...baseParams, `approver[id]=${coupaUser.id}`];
                if (!args.status) idParams.push("status=pending_approval");
                const data = await coupa.request(`/approvals?${idParams.join("&")}`);
                const arr = Array.isArray(data) ? data : [data];
                for (const a of arr) {
                  if (a?.id && !seen.has(a.id)) { seen.add(a.id); merged.push(a); }
                }
              } catch (e) {
                console.warn(`approver[id] filter failed:`, e instanceof Error ? e.message : e);
              }

              // Step 2b: If still no results, fetch pending approvals and filter client-side
              if (merged.length === 0) {
                console.log("search_approvals: approver[id] failed, fetching pending approvals for client-side filtering...");
                try {
                  const broadParams = ["limit=50", "dir=desc", "order_by=created_at", "status=pending_approval"];
                  if (args.approvable_type) broadParams.push(`approvable-type=${args.approvable_type}`);
                  const data = await coupa.request(`/approvals?${broadParams.join("&")}`);
                  const arr = Array.isArray(data) ? data : [];
                  for (const a of arr) {
                    const approverId = a?.approver?.id || a?.["approver-id"];
                    const approverLogin = a?.approver?.login || "";
                    if (approverId === coupaUser.id || approverLogin === coupaUser.login) {
                      if (a?.id && !seen.has(a.id)) { seen.add(a.id); merged.push(a); }
                    }
                  }
                  console.log(`search_approvals: client-side filtering found ${merged.length} approvals`);
                } catch (e) {
                  console.warn("Broad approvals fetch failed:", e instanceof Error ? e.message : e);
                }
              }
            }

            // Step 3: Final fallback — search requisitions with pending_approval and filter by current-approval
            if (merged.length === 0) {
              console.log("search_approvals: final fallback — searching requisitions with pending_approval status");
              try {
                // Use higher limit and order by updated_at to catch older still-pending RCs
                const reqData = await coupa.request(`/requisitions?limit=50&status=pending_approval&dir=desc&order_by=updated_at`);
                const reqs = Array.isArray(reqData) ? reqData : [];
                const matchingReqs: any[] = [];
                const reqApproverCandidates = new Map<string, { id: number | null; login: string; fullname: string; count: number }>();

                // Build normalized tokens for matching
                const searchTokens = nameTokens(approverName || (email ? email.split("@")[0].replace(/[._]/g, " ") : ""));

                for (const r of reqs) {
                  const ca = r["current-approval"] || r.current_approval;
                  if (!ca) continue;
                  const caApprover = ca.approver || {};
                  const caLogin = (caApprover.login || "").toLowerCase();
                  const caEmail = (caApprover.email || "").toLowerCase();
                  const caFullname = caApprover.fullname || caApprover["full-name"] || caApprover.name || "";
                  const matchEmail = email && (caEmail === email.toLowerCase() || caLogin === loginPrefix.toLowerCase());
                  const matchName = searchTokens.length > 0 && nameMatches(caFullname, searchTokens);
                  const matchId = coupaUser && caApprover.id === coupaUser.id;
                  const matchLogin = coupaUser && caLogin === coupaUser.login.toLowerCase();

                  if (searchTokens.length > 0 && caFullname && nameMatches(caFullname, searchTokens)) {
                    const key = String(caApprover.id || caLogin || normalize(caFullname));
                    const existing = reqApproverCandidates.get(key);
                    if (existing) existing.count += 1;
                    else {
                      reqApproverCandidates.set(key, {
                        id: caApprover.id ?? null,
                        login: caApprover.login || "",
                        fullname: formatPersonName(caFullname) || caFullname,
                        count: 1,
                      });
                    }
                  }

                  if (matchEmail || matchName || matchId || matchLogin) {
                    matchingReqs.push(r);
                  }
                }

                console.log(`search_approvals: fallback scanned ${reqs.length} requisitions, matched ${matchingReqs.length}`);

                if (matchingReqs.length > 0) {
                  console.log(`search_approvals: found ${matchingReqs.length} requisitions with matching approver`);
                  const approvalBatches = await Promise.all(
                    matchingReqs.slice(0, 10).map(async (r) => {
                      try {
                        const data = await coupa.request(`/approvals?approvable-type=RequisitionHeader&approvable-id=${r.id}&status=pending_approval`);
                        return Array.isArray(data) ? data : [data];
                      } catch { return []; }
                    })
                  );
                  for (const batch of approvalBatches) {
                    for (const a of batch) {
                      if (a?.id && !seen.has(a.id)) { seen.add(a.id); merged.push(a); }
                    }
                  }
                }

                if (merged.length === 0 && ambiguityCandidates.length === 0 && !email && !args.approver_login && reqApproverCandidates.size > 1) {
                  ambiguityCandidates = Array.from(reqApproverCandidates.values())
                    .sort((a, b) => b.count - a.count)
                    .slice(0, 5);
                  console.log(`search_approvals: ambiguous approver candidates found (${ambiguityCandidates.length})`);
                }
              } catch (e) {
                console.warn("Requisitions fallback failed:", e instanceof Error ? e.message : e);
              }
            }
          }

          if (merged.length === 0 && ambiguityCandidates.length > 1) {
            return JSON.stringify({
              results: [],
              count: 0,
              ambiguous_approver: true,
              message: `Encontrei mais de uma pessoa com nome semelhante a "${approverName}". Informe o e-mail para eu buscar o aprovador correto.`,
              candidates: ambiguityCandidates,
            });
          }

          merged.sort((a, b) => (b["created-at"] || "").localeCompare(a["created-at"] || ""));
          const top = merged.slice(0, 10);
          const enrichments = await enrichApprovables(coupa, top);
          const items = top.map(a => {
            const key = `${a["approvable-type"]}:${a["approvable-id"]}`;
            return summarizeApproval(a, enrichments.get(key));
          });
          return JSON.stringify({ results: items, count: items.length });
        }

        // No approver filter — simple query
        const data = await coupa.request(`/approvals?${baseParams.join("&")}`);
        const rawApprovals = Array.isArray(data) ? data : [data];
        const enrichments2 = await enrichApprovables(coupa, rawApprovals);
        const items = rawApprovals.map(a => {
          const key = `${a["approvable-type"]}:${a["approvable-id"]}`;
          return summarizeApproval(a, enrichments2.get(key));
        });
        return JSON.stringify({ results: items, count: items.length });
      }
      case "search_items": {
        const params: string[] = ["limit=10", "dir=desc", "order_by=created_at"];
        if (args.description) params.push(`description[contains]=${encodeURIComponent(String(args.description))}`);
        if (args.active !== undefined) params.push(`active=${args.active ? "true" : "false"}`);
        const data = await coupa.request(`/items?${params.join("&")}`);
        const items = Array.isArray(data) ? data.map(summarizeItem) : [summarizeItem(data)];
        return JSON.stringify({ results: items, count: items.length });
      }
      case "get_item": {
        const id = validateId(args.id);
        return JSON.stringify(summarizeItem(await coupa.request(`/items/${id}`)));
      }
      default:
        return JSON.stringify({ error: "Ferramenta não reconhecida." });
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    console.error(`Tool ${name} error:`, msg);
    if (msg.includes("404")) return JSON.stringify({ error: "Registro não encontrado. Verifique se o ID está correto." });
    if (msg.includes("403")) return JSON.stringify({ error: "Acesso negado. Sem permissão para este recurso." });
    if (msg.includes("429")) return JSON.stringify({ error: "Rate limit excedido. Tente novamente em alguns minutos." });
    if (msg.includes("Invalid")) return JSON.stringify({ error: "Parâmetro inválido fornecido." });
    return JSON.stringify({ error: "Erro ao consultar dados. Tente novamente." });
  }
}

// ═══════════════════════════════════════════
// SMART ROUTING — detect direct API queries
// ═══════════════════════════════════════════
const DIRECT_API_PATTERNS = [
  /\b(?:requisi[çc][ãa]o|req)\s*(?:#|n[°ºo]?\.?\s*)?\s*(\d{4,})/i,
  /\b(?:pedido|po|purchase\s*order|ordem\s*de\s*compra)\s*(?:#|n[°ºo]?\.?\s*)?\s*(\d{4,})/i,
  /\b(?:fornecedor|supplier)\s*(?:#|n[°ºo]?\.?\s*)?\s*(\d{4,})/i,
  /\b(?:fatura|invoice|nf)\s*(?:#|n[°ºo]?\.?\s*)?\s*(\d{4,})/i,
  /\b(?:contrato|contract)\s*(?:#|n[°ºo]?\.?\s*)?\s*(\d{4,})/i,
  /\b(?:status|detalhe|detalhes|buscar|consultar|ver|mostrar|qual)\b.{0,30}\b(\d{4,})\b/i,
  // Patterns for listing/searching entities
  /\b(?:listar?|buscar?|mostrar?|quais?|meus?|minhas?)\b.{0,30}\b(?:requisi[çc][õo]es|pedidos|fornecedores|faturas|contratos|aprova[çc][õo]es|itens|items|cat[áa]logo)/i,
  /\b(?:requisi[çc][õo]es|pedidos|fornecedores|faturas|contratos|aprova[çc][õo]es|itens|items)\b.{0,30}\b(?:pendentes?|aprovad[oa]s?|recentes?|aberto?s?|rejeitad[oa]s?|dispon[íi]ve[il]s?)/i,
  // Item/catalog search patterns
  /\b(?:item|itens|material|materiais|produto|produtos|cat[áa]logo|comprar|papel|toner|caneta)\b/i,
  // Approval-related patterns (cadeia, fluxo, aprovação + entity)
  /\b(?:cadeia|fluxo|hist[óo]rico)\s*(?:de\s*)?(?:aprova[çc][ãa]o|aprova[çc][õo]es)/i,
  /\b(?:aprova[çc][ãa]o|aprova[çc][õo]es|aprovadores?)\b.{0,40}\b(?:rc|req|requisi[çc][ãa]o|pedido|po|fatura|invoice|contrato)\b/i,
  /\b(?:rc|req|requisi[çc][ãa]o|pedido|po|fatura|invoice|contrato)\b.{0,40}\b(?:aprova[çc][ãa]o|aprova[çc][õo]es|aprovadores?)\b/i,
  /\b(?:quem\s+aprov|quem\s+precisa\s+aprov|aprovadores?\s+d)/i,
  // Reminder / action patterns
  /\b(?:lembrete|enviar\s+lembrete|cobrar|notificar)\b.{0,40}\b(?:aprovad|requisit|pedido|fornec)/i,
  // Follow-up / contextual patterns (user clicking suggested actions)
  /\b(?:ver\s+(?:detalhes|itens|linhas|aprovad)|explicar\s+(?:status|situa)|listar\s+aprovad)/i,
  // Short entity references with IDs (RC 174556, PO 12345)
  /\b(?:rc|po|nf|oc)\s+\d{4,}\b/i,
];

function isDirectApiQuery(message: string): boolean {
  return DIRECT_API_PATTERNS.some(p => p.test(message));
}

// ═══════════════════════════════════════════
// SYSTEM PROMPT
// ═══════════════════════════════════════════
const STATUS_MAP = `
MAPA DE STATUS (use para traduzir):
- draft → 📝 Rascunho
- cart → 🛒 Carrinho
- pending_buyer_action → ⏳ Pendente ação do comprador
- pending_approval → 🔄 Pendente de aprovação
- approved → ✅ Aprovada
- ordered → 📦 Pedido realizado
- partially_received → 📬 Parcialmente recebida
- received → ✅ Recebida
- abandoned → 🚫 Abandonada
- withdrawn → ↩️ Retirada
- rejected → ❌ Rejeitada
- issued → 📤 Emitida
- soft_closed → 🔒 Soft-closed
- closed → 🔒 Fechada
- cancelled → 🚫 Cancelada
- voided → 🚫 Anulada
- disputed → ⚠️ Disputada
- active → ✅ Ativo
- inactive → ⚪ Inativo
`;

// ═══════════════════════════════════════════
// MAIN HANDLER
// ═══════════════════════════════════════════
serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // ─── JWT Validation ───
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseAuth.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub;
    const userEmail = (claimsData.claims as any).email || "";
    let userFullName = (claimsData.claims as any).user_metadata?.full_name || (claimsData.claims as any).user_metadata?.name || "";

    console.log(`Authenticated user: ${userId}, email: ${userEmail}, name: ${userFullName}`);

    const body = await req.json();
    const { messages, action } = body;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // ─── Generate Title Action ───
    if (action === "generate_title") {
      const titleResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash-lite",
          messages: [
            { role: "system", content: "Gere um título curto (3-6 palavras, máximo 40 caracteres) em português para esta conversa. Baseie-se na INTENÇÃO do usuário. Retorne APENAS o título, sem aspas, sem pontuação final." },
            { role: "user", content: messages[0]?.content || "" },
          ],
        }),
      });
      if (!titleResponse.ok) {
        return new Response(JSON.stringify({ error: "Failed to generate title" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const titleData = await titleResponse.json();
      const title = titleData.choices?.[0]?.message?.content?.trim()?.slice(0, 60) || "Nova conversa";
      return new Response(JSON.stringify({ title }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch real name from profiles table
    if (!userFullName) {
      const { data: profileRow } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("id", userId)
        .maybeSingle();
      if (profileRow?.full_name) userFullName = profileRow.full_name;
    }

    const userFirstName = (() => {
      const raw = (userFullName || userEmail.split("@")[0] || "").trim();
      if (!raw) return "";
      const seg = raw.includes(" ") ? raw.split(" ")[0] : raw.split(".")[0];
      return seg.charAt(0).toUpperCase() + seg.slice(1).toLowerCase();
    })();
    console.log(`[Chat] firstName resolved: ${userFirstName}`);


    const lastUserMessage = [...messages].reverse().find((m: any) => m.role === "user")?.content || "";
    const isDirect = isDirectApiQuery(lastUserMessage);
    console.log(`[Router] Direct API query: ${isDirect}, message: "${lastUserMessage.slice(0, 80)}"`);

    const [, , scopesResult, promptConfigs, connectionsResult] = await Promise.all([
      coupa.init(),
      Promise.resolve(),
      supabase.from("api_scopes").select("id, name").eq("is_active", true),
      supabase.from("system_prompt_config").select("key, value").in("key", ["system_prompt", "format_rules", "interaction_rules", "chat_model"]),
      supabase.from("scope_connections").select("source_scope_id, target_scope_id, relationship"),
    ]);

    const coupaAvailable = coupa.isConfigured();

    // Map Coupa OAuth scopes → internal tool names
    const SCOPE_TO_TOOLS: Record<string, string[]> = {
      "core.requisition.read":      ["get_requisition", "search_requisitions"],
      "core.purchase_order.read":   ["get_purchase_order", "search_purchase_orders"],
      "core.supplier.read":         ["get_supplier", "search_suppliers"],
      "core.invoice.read":          ["get_invoice", "search_invoices"],
      "core.contract.read":         ["get_contract", "search_contracts"],
      "core.approval.read":         ["search_approvals"],
      "core.item.read":             ["search_items", "get_item"],
    };

    // Build active tools from scopes
    const scopeIdToName = new Map((scopesResult.data || []).map((s: any) => [s.id, s.name]));
    const activeScopes = new Set((scopesResult.data || []).map((s: any) => s.name));
    const enabledToolNames = new Set<string>();
    for (const scope of activeScopes) {
      const tools = SCOPE_TO_TOOLS[scope];
      if (tools) tools.forEach(t => enabledToolNames.add(t));
      // Fallback: if scope name matches a tool name directly, enable it
      else if (TOOL_REGISTRY[scope]) enabledToolNames.add(scope);
    }
    const activeTools = [...enabledToolNames]
      .filter(name => TOOL_REGISTRY[name])
      .map(name => TOOL_REGISTRY[name]);
    console.log(`[Scopes] Active: ${[...activeScopes].join(", ")} → mapped tools: ${[...enabledToolNames].join(", ")} (${activeTools.length} total)`);

    // Build dynamic entity relationship block from scope_connections
    let entityRelationships = "";
    const conns = connectionsResult.data || [];
    if (conns.length > 0) {
      const lines = conns.map((c: any) => {
        const srcName = scopeIdToName.get(c.source_scope_id) || c.source_scope_id;
        const tgtName = scopeIdToName.get(c.target_scope_id) || c.target_scope_id;
        return `- ${srcName} → ${c.relationship} → ${tgtName}`;
      });
      entityRelationships = `\nRELACIONAMENTO ENTRE ENTIDADES (use para cruzar dados automaticamente):
${lines.join("\n")}

REGRA: Quando o usuário perguntar algo que envolve DUAS entidades (ex: "fornecedor da requisição X", "aprovação do pedido Y"), chame MÚLTIPLAS ferramentas em sequência para cruzar os dados. Use os IDs retornados (supplier_id, requisition_id, approvable_id) para buscar a entidade relacionada. Não peça confirmação intermediária.\n`;
    }

    // ─── RAG Context — SKIP for direct API queries ───
    let contextText = "";
    let sources: any[] = [];
    let confidence = "high";

    if (!isDirect) {
      try {
        if (lastUserMessage.trim()) {
          // Keyword translation + FTS in parallel
          // Static PT→EN keyword mapping (replaces AI translation call to save ~2s)
          const KEYWORD_MAP: Record<string, string> = {
            "requisição": "requisition", "requisicao": "requisition", "requisições": "requisitions", "requisicoes": "requisitions",
            "pedido": "purchase order", "pedidos": "purchase orders",
            "ordem": "order", "ordens": "orders",
            "fornecedor": "supplier", "fornecedores": "suppliers",
            "fatura": "invoice", "faturas": "invoices",
            "contrato": "contract", "contratos": "contracts",
            "aprovação": "approval", "aprovacao": "approval", "aprovações": "approvals", "aprovacoes": "approvals",
            "aprovador": "approver", "aprovadores": "approvers",
            "comprador": "buyer", "compradores": "buyers",
            "solicitante": "requester", "solicitação": "request",
            "recebimento": "receipt", "recebimentos": "receipts",
            "catálogo": "catalog", "catalogo": "catalog",
            "orçamento": "budget", "orcamento": "budget",
            "centro de custo": "cost center", "departamento": "department",
            "item": "item", "itens": "items", "linha": "line", "linhas": "lines",
            "status": "status", "pendente": "pending", "aprovado": "approved", "rejeitado": "rejected",
            "rascunho": "draft", "emitido": "issued", "cancelado": "cancelled",
            "pagamento": "payment", "prazo": "term", "vencimento": "due date",
            "endereço": "address", "entrega": "delivery", "envio": "shipping",
            "moeda": "currency", "valor": "amount", "total": "total", "preço": "price",
            "configurar": "configure", "configuração": "configuration", "setup": "setup",
            "fluxo": "workflow", "processo": "process", "cadeia": "chain",
            "integração": "integration", "integracao": "integration", "api": "api",
            "usuário": "user", "usuario": "user", "permissão": "permission", "permissao": "permission",
            "relatório": "report", "relatorio": "report", "análise": "analysis", "analise": "analysis",
            "notificação": "notification", "notificacao": "notification", "lembrete": "reminder",
            "criar": "create", "editar": "edit", "excluir": "delete", "buscar": "search",
          };

          const words = lastUserMessage.toLowerCase().replace(/[^a-záàâãéèêíïóôõúüç0-9\s]/g, "").split(/\s+/).filter(w => w.length > 2);
          const englishTerms = new Set<string>();
          for (const w of words) {
            if (KEYWORD_MAP[w]) englishTerms.add(KEYWORD_MAP[w]);
          }
          // Also check two-word combos
          const lowerMsg = lastUserMessage.toLowerCase();
          for (const [pt, en] of Object.entries(KEYWORD_MAP)) {
            if (pt.includes(" ") && lowerMsg.includes(pt)) englishTerms.add(en);
          }
          const searchTerms = englishTerms.size > 0
            ? [...englishTerms].join(" ") + " " + words.filter(w => !KEYWORD_MAP[w] && w.length > 3).join(" ")
            : lastUserMessage;
          console.log(`[RAG] Static keyword mapping: "${searchTerms.trim()}"`);

          // FTS search
          const { data: chunks, error: ftsError } = await supabase.rpc("match_knowledge_chunks_fts", {
            search_query: searchTerms, match_count: 5,
          });

          let allChunks = chunks || [];
          if (searchTerms !== lastUserMessage) {
            const { data: ptChunks } = await supabase.rpc("match_knowledge_chunks_fts", {
              search_query: lastUserMessage, match_count: 3,
            });
            if (ptChunks?.length) {
              const existingIds = new Set(allChunks.map((c: any) => c.id));
              for (const c of ptChunks) {
                if (!existingIds.has(c.id)) allChunks.push(c);
              }
            }
          }

          if (ftsError) console.error("[RAG] FTS error:", ftsError);
          console.log(`[RAG] FTS returned ${allChunks.length} chunks`);

          const MIN_RELEVANCE = 0.1;
          let relevantChunks = allChunks.filter((c: any) => c.similarity >= MIN_RELEVANCE);

          // Keyword filter
          const stopwords = new Set(["o","a","os","as","de","do","da","dos","das","em","no","na","nos","nas","um","uma","que","qual","quais","como","para","pra","por","com","se","e","ou","ao","à","é","esta","desta","deste","esse","essa","isso","aqui","ali","lá","me","te","nos","vos","meu","minha","seu","sua","ele","ela","eles","elas","nós","eu","tu","você","não","sim","mais","muito","bem","mas","já","também","só","ainda","até","sobre","entre","depois","antes","agora","quando","onde","porque","porquê","quero","ver","saber","pode","posso","favor","obrigado","obrigada","olá","oi","bom","boa","dia","tarde","noite","fechar","pra","pro"]);
          const queryWords = lastUserMessage.toLowerCase().replace(/[^a-záàâãéèêíïóôõúüç0-9\s]/g, "").split(/\s+/).filter(w => w.length > 2 && !stopwords.has(w));
          if (queryWords.length > 0 && relevantChunks.length > 0) {
            const keywordFiltered = relevantChunks.filter((c: any) => {
              const cl = c.content.toLowerCase();
              return queryWords.some((kw: string) => cl.includes(kw));
            });
            if (keywordFiltered.length > 0) relevantChunks = keywordFiltered;
          }

          if (relevantChunks.length > 0) {
            // Sort by similarity descending and cap to top 5 chunks for LLM context
            relevantChunks.sort((a: any, b: any) => b.similarity - a.similarity);
            relevantChunks = relevantChunks.slice(0, 5);

            const formattedChunks = relevantChunks.map((c: any, i: number) => `[${i + 1}] ${c.content}`).join("\n\n");
            contextText = `\n\nCONTEXTO DA BASE DE CONHECIMENTO COUPA (FONTE PRINCIPAL — traduza para português se necessário):\n\n${formattedChunks}`;

            // Aggregate MAX similarity per source_id
            const simBySource = new Map<string, number>();
            for (const c of relevantChunks) {
              const prev = simBySource.get(c.source_id) || 0;
              if (c.similarity > prev) simBySource.set(c.source_id, c.similarity);
            }

            const sourceIds = [...simBySource.keys()];
            const { data: sourcesData } = await supabase.from("knowledge_sources").select("id, title, url").in("id", sourceIds);
            if (sourcesData) {
              sources = sourcesData
                .map((s: any) => ({
                  title: s.title || s.url, url: s.url,
                  relevance_score: simBySource.get(s.id) || 0,
                }))
                .sort((a: any, b: any) => b.relevance_score - a.relevance_score);

              // Relative cutoff: drop sources < 50% of top source score
              if (sources.length > 0) {
                const topScore = sources[0].relevance_score;
                sources = sources.filter((s: any) => s.relevance_score >= topScore * 0.5);
              }

              // Cap at 3 sources max
              sources = sources.slice(0, 3);
            }
            const maxSim = Math.max(...relevantChunks.map((c: any) => c.similarity));
            confidence = maxSim < 0.01 ? "low" : maxSim < 0.1 ? "medium" : "high";
          }
        }
      } catch (e) {
        console.error("RAG error (continuing):", e);
      }
    } else {
      console.log("[Router] Skipping RAG — direct API query detected");
    }

    // ─── Build system prompt ───
    let sourceType: "coupa_api" | "knowledge_base" | "general" = contextText ? "knowledge_base" : "general";
    const sourceTypes: string[] = [];

    let customSystemPrompt = "";
    let customFormatRules = "";
    let customInteractionRules = "";
    let configuredModel = "openai/gpt-5";
    const FALLBACK_MODEL = "google/gemini-2.5-pro";
    if (promptConfigs.data) {
      for (const pc of promptConfigs.data) {
        if (pc.key === "system_prompt") customSystemPrompt = pc.value;
        if (pc.key === "format_rules") customFormatRules = pc.value;
        if (pc.key === "interaction_rules") customInteractionRules = pc.value;
        if (pc.key === "chat_model" && pc.value) configuredModel = pc.value;
      }
    }

    const basePrompt = customSystemPrompt || `Você é o Coupa Copilot, um assistente inteligente especializado na plataforma de e-Procurement Coupa.

REGRAS:
- Responda APENAS sobre a plataforma Coupa e seus módulos.
- Se a pergunta não for sobre o Coupa, responda educadamente que só pode ajudar com temas do Coupa.
- Responda sempre em português brasileiro.
- Formate suas respostas em Markdown quando apropriado.
- Seja claro, objetivo e profissional.`;

    const formatRules = customFormatRules || `FORMATAÇÃO DE TEXTO (OBRIGATÓRIO):
- Comece com um resumo direto de 1-2 frases.
- Linha em branco entre parágrafos, itens e subtítulos.
- Use ### para subtítulos. Use **negrito** com moderação — apenas 1-2 termos essenciais por parágrafo, nunca em frases inteiras.
- Listas numeradas para passos.
- NUNCA texto corrido sem formatação.`;

    const interactionRules = customInteractionRules || `REGRAS DE INTERAÇÃO:
- Consultas VAGAS: busque últimos 3-5 itens e PERGUNTE qual ver em detalhe.
- Consultas ESPECÍFICAS: busque diretamente com filtros.
- 1 resultado → mostre detalhes completos. >5 resultados → resumo dos 5 mais recentes.

PRIORIDADE DE FONTES:
1. API Coupa (dados em tempo real) — quando o usuário pedir dados específicos (IDs, números, nomes de fornecedores, requisições, POs etc.), USE DIRETAMENTE as ferramentas. Não sugira navegar manualmente.
2. Base de Conhecimento (RAG) — para dúvidas conceituais, tutoriais e processos.
3. Conhecimentos gerais sobre Coupa — como fallback.`;

    const systemPrompt = `${basePrompt}

USUÁRIO LOGADO:
- Email: ${userEmail}
- Nome completo: ${userFullName || userFirstName}
- Primeiro nome: ${userFirstName}
Ao se referir ao usuário, use o primeiro nome dele (${userFirstName}).
Quando o usuário disser "meu", "minha", "meus", "minhas", "para mim", use o email dele como filtro "requested_by". O sistema buscará automaticamente por variações (email, login, nome completo).

${formatRules}

${interactionRules}

- Ao final de TODA resposta, gere 2-3 sugestões de ação para o USUÁRIO no formato:
[FOLLOW_UP: ação1 | ação2 | ação3]
REGRAS PARA FOLLOW-UPS:
  - OBRIGATÓRIO: Use verbos no IMPERATIVO/INFINITIVO (comandos diretos para o usuário executar).
  - PROIBIDO: Formato interrogativo, perguntas, ou frases como "Quer que eu...", "Deseja saber...", "Você quer...".
  - Exemplos CORRETOS: "Explicar diferença entre X e Y" | "Ver detalhes do pedido" | "Listar aprovações pendentes"
  - Exemplos ERRADOS: "Quer que eu explique X?" | "Você deseja ver Y?" | "Posso te ajudar com Z?"
${coupaAvailable && activeTools.length > 0 ? `
DADOS EM TEMPO REAL:
- Você tem ferramentas (tools) para consultar dados reais da instância Coupa.
- USE AS FERRAMENTAS quando o usuário solicitar dados específicos em tempo real.
- Formate resultados com emojis e Markdown. Traduza status usando o mapa abaixo.
- Se uma ferramenta retornar erro, EXPLIQUE ao usuário e sugira alternativas.
- Quando uma ferramenta retornar dados com sucesso, APRESENTE-OS DIRETAMENTE. NÃO peça confirmação adicional ao usuário sobre como filtrar.
${STATUS_MAP}${entityRelationships}` : ""}
${contextText}

REGRA CRÍTICA: NUNCA deixe o usuário sem resposta. Use conhecimento geral sobre Coupa se necessário.

REGRA ABSOLUTA — FORMATO DA RESPOSTA:
- NUNCA inclua parâmetros de busca ou JSON bruto na resposta (ex: {"created_by":..., "limit":5}).
- NUNCA narre seu processo interno (ex: "Consultando requisições...", "Buscando dados...", "Tentando incluir rascunhos...").
- NUNCA mostre nomes de campos técnicos da API (ex: requested_by, include_drafts, order_by, created_at).
- Vá DIRETO ao resultado formatado. Se não encontrar dados, diga apenas o resultado final.

LEMBRETE: Formate TODA resposta em Markdown com ### subtítulos, listas numeradas, linhas em branco. Use negrito com moderação.`;

    // ─── Fire courtesy LLM in parallel (fast model, non-streaming) ───
    const courtesyPromise = fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-lite",
        messages: [
          { role: "system", content: `Você é um assistente chamado Coupa Copilot. O usuário se chama '${userFirstName}'. Ele acabou de enviar uma mensagem. Gere UMA frase curta (máx 15 palavras) reconhecendo e pedindo que aguarde enquanto busca a informação. REGRAS OBRIGATÓRIAS: NUNCA comece com "Olá", "Oi", "Hey" ou qualquer saudação. Vá direto ao ponto, ex: "${userFirstName}, vou verificar isso para você..." ou "Deixa eu consultar essa informação..." ou "Um momento, estou buscando os dados...". Pode usar o nome do usuário no início, mas SEM saudação. Contextualize brevemente o tema da pergunta. Não responda a pergunta em si. Apenas texto simples, sem markdown.` },
          { role: "user", content: lastUserMessage.slice(0, 200) },
        ],
      }),
    }).then(r => r.ok ? r.json() : null)
      .then(d => d?.choices?.[0]?.message?.content?.trim() || null)
      .catch(() => null);

    // ─── Return streaming response IMMEDIATELY so courtesy reaches client fast ───
    const { readable, writable } = new TransformStream();
    const responseHeaders = { ...corsHeaders, "Content-Type": "text/event-stream" };

    // All processing happens inside the async writer
    (async () => {
      const writer = writable.getWriter();
      const encoder = new TextEncoder();

      try {
        // Send courtesy message first (with 3s timeout)
        try {
          const courtesyText = await Promise.race([
            courtesyPromise,
            new Promise<null>(resolve => setTimeout(() => resolve(null), 3000)),
          ]);
          if (courtesyText) {
            const ev = { choices: [{ delta: { content: courtesyText } }] };
            await writer.write(encoder.encode(`data: ${JSON.stringify(ev)}\n\n`));
            await writer.write(encoder.encode(`data: {"courtesy_end":true}\n\n`));
          }
        } catch { /* skip courtesy on error */ }

        // ─── AI call (with tools if available) ───
        const primaryModel = configuredModel;
        const aiBody: any = {
          model: primaryModel,
          messages: [{ role: "system", content: systemPrompt }, ...messages],
        };

        if (coupaAvailable && activeTools.length > 0) {
          aiBody.tools = activeTools;
          aiBody.parallel_tool_calls = true;
          if (isDirect) {
            aiBody.tool_choice = "required";
            console.log("[Router] Forçando tool_choice=required para consulta direta");
          }
        }

        const firstCallController = new AbortController();
        const firstCallTimeout = setTimeout(() => firstCallController.abort(), 25000);

        let firstData: any;
        let toolDetectionFailed = false;

        try {
          const firstResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
            body: JSON.stringify(aiBody),
            signal: firstCallController.signal,
          });
          clearTimeout(firstCallTimeout);

          if (!firstResponse.ok) {
            const status = firstResponse.status;
            if (status === 429 || status === 402) {
              const errMsg = status === 429 ? "Rate limit exceeded." : "AI credits exhausted.";
              await writer.write(encoder.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: `⚠️ ${errMsg}` } }] })}\n\n`));
              return;
            }
            await firstResponse.text();
            toolDetectionFailed = true;
          } else {
            firstData = await firstResponse.json();
          }
        } catch (e) {
          clearTimeout(firstCallTimeout);
          console.warn("First AI call failed, falling back:", e);
          toolDetectionFailed = true;
        }

        const firstChoice = !toolDetectionFailed ? firstData?.choices?.[0] : null;

        // ─── Tool calls detected ───
        if (firstChoice?.finish_reason === "tool_calls" || firstChoice?.message?.tool_calls?.length > 0) {
          sourceType = "coupa_api";
          sourceTypes.push("coupa_api");
          const toolCalls = firstChoice.message.tool_calls;
          const cleanedFirstMessage = { ...firstChoice.message, content: null };
          console.log(`AI requested ${toolCalls.length} tool call(s)`);

          const MAX_TOOL_RESULT_CHARS = 8000;
          const toolResults = await Promise.all(
            toolCalls.map(async (tc: any) => {
              const args = typeof tc.function.arguments === "string" ? JSON.parse(tc.function.arguments) : tc.function.arguments;
              console.log(`Executing tool: ${tc.function.name}`, args);
              let result = await executeTool(tc.function.name, args, { userEmail, userFullName });

              try {
                await supabase.from("audit_logs").insert({
                  user_id: userId, action: "tool_call", entity_type: tc.function.name,
                  entity_id: args.id ? String(args.id) : null,
                  details: { args, success: !result.includes('"error"') },
                });
              } catch (e) { console.error("Audit log error:", e); }

              if (result.length > MAX_TOOL_RESULT_CHARS) {
                try {
                  const parsed = JSON.parse(result);
                  if (Array.isArray(parsed)) {
                    result = JSON.stringify({ results: parsed.slice(0, 20), total_count: parsed.length, truncated: true });
                  } else {
                    result = result.slice(0, MAX_TOOL_RESULT_CHARS) + '... [TRUNCATED]';
                  }
                } catch {
                  result = result.slice(0, MAX_TOOL_RESULT_CHARS) + '... [TRUNCATED]';
                }
              }
              return { role: "tool", tool_call_id: tc.id, content: result };
            })
          );

          // Second AI call with tool results — streaming (with fallback)
          async function tryToolStream(model: string): Promise<Response> {
            return await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
              method: "POST",
              headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
              body: JSON.stringify({
                model,
                messages: [{ role: "system", content: systemPrompt }, ...messages, cleanedFirstMessage, ...toolResults],
                stream: true,
              }),
            });
          }

          let secondResponse = await tryToolStream(primaryModel);

          if (!secondResponse.ok) {
            const t = await secondResponse.text();
            console.error("AI second call error:", secondResponse.status, t);
            if (primaryModel !== FALLBACK_MODEL) {
              console.warn("Retrying second call with fallback model");
              secondResponse = await tryToolStream(FALLBACK_MODEL);
              if (!secondResponse.ok) {
                await secondResponse.text();
                await writer.write(encoder.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: "⚠️ Erro ao processar dados da API." } }] })}\n\n`));
                return;
              }
            } else {
              await writer.write(encoder.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: "⚠️ Erro ao processar dados da API." } }] })}\n\n`));
              return;
            }
          }

          // Stream to client with content filtering
          const DEBUG_PATTERNS = /^(Consultando|Buscando|Tentando|Fazendo|Chamando|Filtrando|Verificando|Processando|Executando|Acessando)\b/;
          const JSON_PATTERN = /^\s*\{[\s\S]*("created_by"|"requested_by"|"limit"|"include_drafts"|"order_by"|"status"|"fields"|"offset"|"return_object")/;
          const FORMATTED_START = /^(#{1,4}\s|[\*\-•]\s|\*\*|📋|✅|❌|⚠️|🔍|📊|📄|💡|\d+[\.\)]\s|>\s)/;

          const reader = secondResponse.body!.getReader();
          const decoder = new TextDecoder();
          let buffer = "";
          let contentBuffer = "";
          let formattedStarted = false;

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });

            let newlineIdx: number;
            while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
              const line = buffer.slice(0, newlineIdx);
              buffer = buffer.slice(newlineIdx + 1);

              if (!line.startsWith("data: ") || line.trim() === "") {
                if (formattedStarted) await writer.write(encoder.encode(line + "\n"));
                continue;
              }

              const jsonStr = line.slice(6).trim();
              if (jsonStr === "[DONE]") {
                await writer.write(encoder.encode(line + "\n"));
                continue;
              }

              try {
                const parsed = JSON.parse(jsonStr);
                const content = parsed.choices?.[0]?.delta?.content as string | undefined;
                if (!content) {
                  if (formattedStarted) await writer.write(encoder.encode(line + "\n"));
                  continue;
                }

                contentBuffer += content;

                if (!formattedStarted) {
                  const lines = contentBuffer.split("\n");
                  for (let i = 0; i < lines.length; i++) {
                    const l = lines[i].trim();
                    if (!l) continue;
                    if (FORMATTED_START.test(l)) {
                      formattedStarted = true;
                      const cleanContent = lines.slice(i).join("\n");
                      const cleanEvent = { choices: [{ delta: { content: cleanContent } }] };
                      await writer.write(encoder.encode(`data: ${JSON.stringify(cleanEvent)}\n\n`));
                      contentBuffer = "";
                      break;
                    }
                    if (JSON_PATTERN.test(l) || DEBUG_PATTERNS.test(l)) continue;
                    if (l.length > 30 && !l.startsWith("{") && !l.startsWith("[")) {
                      formattedStarted = true;
                      const cleanEvent = { choices: [{ delta: { content: contentBuffer } }] };
                      await writer.write(encoder.encode(`data: ${JSON.stringify(cleanEvent)}\n\n`));
                      contentBuffer = "";
                      break;
                    }
                  }
                } else {
                  await writer.write(encoder.encode(line + "\n"));
                  contentBuffer = "";
                }
              } catch {
                if (formattedStarted) await writer.write(encoder.encode(line + "\n"));
              }
            }
          }

          if (!formattedStarted && contentBuffer.trim()) {
            const cleanEvent = { choices: [{ delta: { content: contentBuffer } }] };
            await writer.write(encoder.encode(`data: ${JSON.stringify(cleanEvent)}\n\n`));
          }

          const meta: any = { source_type: sourceType, source_types: sourceTypes.filter(t => t !== "knowledge_base") };
          meta.confidence = "high";
          await writer.write(encoder.encode(`data: ${JSON.stringify(meta)}\n\n`));
          return; // done with tool-call path
        }

        // ─── No tool calls: stream directly ───
        async function tryStream(model: string): Promise<Response> {
          return await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
            body: JSON.stringify({ ...aiBody, model, tools: undefined, stream: true }),
          });
        }

        let streamResponse = await tryStream(primaryModel);
        if (!streamResponse.ok) {
          console.warn(`Primary model failed (${streamResponse.status}), trying fallback`);
          await streamResponse.text();
          streamResponse = await tryStream(FALLBACK_MODEL);
          if (!streamResponse.ok) {
            await streamResponse.text();
            await writer.write(encoder.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: "⚠️ Falha ao obter resposta. Tente novamente." } }] })}\n\n`));
            return;
          }
        }

        const reader = streamResponse.body!.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          await writer.write(value);
        }
        const finalSourceTypes = contextText ? ["knowledge_base", "general"] : ["general"];
        const meta: any = { source_type: sourceType, source_types: finalSourceTypes };
        if (sources.length > 0) { meta.sources = sources; meta.confidence = confidence; }
        await writer.write(encoder.encode(`data: ${JSON.stringify(meta)}\n\n`));
      } catch (e) {
        console.error("Stream processing error:", e);
        try {
          await writer.write(encoder.encode(`data: ${JSON.stringify({ choices: [{ delta: { content: "⚠️ Erro interno. Tente novamente." } }] })}\n\n`));
        } catch { /* writer may be closed */ }
      } finally {
        try { await writer.close(); } catch { /* ignore */ }
      }
    })();

    return new Response(readable, { headers: responseHeaders });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
