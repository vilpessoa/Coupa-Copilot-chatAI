import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function stripHtmlToText(html: string): string {
  let text = html.replace(/<script[\s\S]*?<\/script>/gi, "");
  text = text.replace(/<style[\s\S]*?<\/style>/gi, "");
  text = text.replace(/<nav[\s\S]*?<\/nav>/gi, "");
  text = text.replace(/<footer[\s\S]*?<\/footer>/gi, "");
  text = text.replace(/<header[\s\S]*?<\/header>/gi, "");
  text = text.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, "\n# $1\n");
  text = text.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, "\n## $1\n");
  text = text.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, "\n### $1\n");
  text = text.replace(/<h4[^>]*>([\s\S]*?)<\/h4>/gi, "\n#### $1\n");
  text = text.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, "- $1\n");
  text = text.replace(/<br\s*\/?>/gi, "\n");
  text = text.replace(/<\/p>/gi, "\n\n");
  text = text.replace(/<\/div>/gi, "\n");
  text = text.replace(/<[^>]+>/g, "");
  text = text.replace(/&amp;/g, "&");
  text = text.replace(/&lt;/g, "<");
  text = text.replace(/&gt;/g, ">");
  text = text.replace(/&quot;/g, '"');
  text = text.replace(/&#39;/g, "'");
  text = text.replace(/&nbsp;/g, " ");
  text = text.replace(/\n{3,}/g, "\n\n");
  return text.trim();
}

function chunkText(text: string, chunkSize = 500, overlap = 50): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length <= chunkSize) return [words.join(" ")];
  const chunks: string[] = [];
  let i = 0;
  while (i < words.length) {
    const end = Math.min(i + chunkSize, words.length);
    chunks.push(words.slice(i, end).join(" "));
    i += chunkSize - overlap;
  }
  return chunks;
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function authenticateAdmin(req: Request) {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw { status: 401, message: "Unauthorized" };

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: authHeader } },
  });

  const token = authHeader.replace("Bearer ", "");
  const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
  if (claimsError || !claimsData?.claims) throw { status: 401, message: "Unauthorized" };

  const userId = claimsData.claims.sub;
  const serviceClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

  const { data: roleData } = await serviceClient
    .from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
  if (!roleData) throw { status: 403, message: "Admin access required" };

  return serviceClient;
}

async function indexContent(
  serviceClient: ReturnType<typeof createClient>,
  content: string,
  title: string,
  sourceUrl: string,
  sourceType: string,
) {
  const cleanContent = content.includes("<") ? stripHtmlToText(content) : content.trim();
  const chunks = chunkText(cleanContent);

  // Upsert source
  const { data: existing } = await serviceClient
    .from("knowledge_sources").select("id").eq("url", sourceUrl).maybeSingle();

  let sourceId: string;
  if (existing) {
    sourceId = existing.id;
    await serviceClient.from("knowledge_chunks").delete().eq("source_id", sourceId);
    await serviceClient.from("knowledge_sources").update({
      title, status: "pending", raw_content: cleanContent.substring(0, 50000),
      last_crawled_at: new Date().toISOString(), source_type: sourceType,
    }).eq("id", sourceId);
  } else {
    const { data: newSource, error } = await serviceClient.from("knowledge_sources").insert({
      url: sourceUrl, title, status: "pending", source_type: sourceType,
      raw_content: cleanContent.substring(0, 50000), last_crawled_at: new Date().toISOString(),
    }).select("id").single();
    if (error) throw error;
    sourceId = newSource.id;
  }

  let successCount = 0;
  for (let i = 0; i < chunks.length; i++) {
    const { error } = await serviceClient.from("knowledge_chunks").insert({
      source_id: sourceId, content: chunks[i], chunk_index: i,
      metadata: { url: sourceUrl, title, chunk_index: i, total_chunks: chunks.length },
    });
    if (!error) successCount++;
    else console.error(`Chunk ${i} error:`, error);
  }

  await serviceClient.from("knowledge_sources")
    .update({ status: successCount > 0 ? "active" : "error" }).eq("id", sourceId);

  return { source_id: sourceId, title, chunks_total: chunks.length, chunks_indexed: successCount };
}

/** Append additional content chunks to an existing source (for multi-part uploads) */
async function appendContent(
  serviceClient: ReturnType<typeof createClient>,
  sourceId: string,
  content: string,
  isLast: boolean,
) {
  const cleanContent = content.trim();
  const chunks = chunkText(cleanContent);

  // Get current max chunk_index for this source
  const { data: maxChunkData } = await serviceClient
    .from("knowledge_chunks")
    .select("chunk_index")
    .eq("source_id", sourceId)
    .order("chunk_index", { ascending: false })
    .limit(1)
    .maybeSingle();

  const startIndex = (maxChunkData?.chunk_index ?? -1) + 1;

  let successCount = 0;
  for (let i = 0; i < chunks.length; i++) {
    const { error } = await serviceClient.from("knowledge_chunks").insert({
      source_id: sourceId, content: chunks[i], chunk_index: startIndex + i,
      metadata: { chunk_index: startIndex + i },
    });
    if (!error) successCount++;
    else console.error(`Append chunk ${startIndex + i} error:`, error);
  }

  // Also append to raw_content (up to 50k total)
  if (cleanContent.length > 0) {
    const { data: sourceData } = await serviceClient
      .from("knowledge_sources").select("raw_content").eq("id", sourceId).single();
    const currentRaw = sourceData?.raw_content || "";
    if (currentRaw.length < 50000) {
      const appendable = cleanContent.substring(0, 50000 - currentRaw.length);
      if (appendable.length > 0) {
        await serviceClient.from("knowledge_sources")
          .update({ raw_content: currentRaw + "\n" + appendable }).eq("id", sourceId);
      }
    }
  }

  if (isLast) {
    await serviceClient.from("knowledge_sources")
      .update({ status: "active", last_crawled_at: new Date().toISOString() }).eq("id", sourceId);
  }

  return { source_id: sourceId, chunks_appended: successCount };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const serviceClient = await authenticateAdmin(req);
    const body = await req.json();
    const { action } = body;

    // LIST
    if (action === "list") {
      const { data: sources, error } = await serviceClient
        .from("knowledge_sources").select("*, knowledge_chunks(count)").order("created_at", { ascending: false });
      if (error) throw error;
      const sourcesWithPreview = (sources || []).map((s: any) => ({
        ...s,
        raw_content: s.raw_content ? s.raw_content.substring(0, 10000) : null,
      }));
      return jsonResponse({ success: true, sources: sourcesWithPreview });
    }

    // DELETE
    if (action === "delete") {
      const { source_id } = body;
      if (!source_id) return jsonResponse({ error: "source_id required" }, 400);
      await serviceClient.from("knowledge_chunks").delete().eq("source_id", source_id);
      await serviceClient.from("knowledge_sources").delete().eq("id", source_id);
      return jsonResponse({ success: true });
    }

    // MANUAL INDEX
    if (action === "manual-index") {
      const { content, title: t, url: u } = body;
      if (!content || content.trim().length < 20) return jsonResponse({ error: "Mínimo de 20 caracteres" }, 400);
      const finalTitle = t?.trim() || "Conteúdo manual";
      const finalUrl = u?.trim() || `manual://${Date.now()}`;
      console.log(`Manual index: "${finalTitle}", ${content.length} chars`);
      const result = await indexContent(serviceClient, content, finalTitle, finalUrl, "manual");
      return jsonResponse({ success: true, ...result });
    }

    // FILE INDEX (creates source + indexes first batch)
    if (action === "file-index") {
      const { content, title: t, filename, source_type: st, part, total_parts, metadata: fileMeta } = body;
      if (!content || content.trim().length < 20) return jsonResponse({ error: "Arquivo sem conteúdo suficiente" }, 400);
      const finalTitle = t?.trim() || filename || "Arquivo enviado";
      const finalUrl = `file://${filename || Date.now()}`;
      const finalType = st || "file";
      const isSinglePart = !total_parts || total_parts <= 1;
      console.log(`File index: "${finalTitle}", ${content.length} chars, type: ${finalType}, part: ${part || 1}/${total_parts || 1}`);
      if (fileMeta) console.log(`Metadata:`, JSON.stringify(fileMeta));

      const cleanContent = content.trim();
      const chunks = chunkText(cleanContent);

      // Upsert source
      const { data: existing } = await serviceClient
        .from("knowledge_sources").select("id").eq("url", finalUrl).maybeSingle();

      let sourceId: string;
      if (existing) {
        sourceId = existing.id;
        await serviceClient.from("knowledge_chunks").delete().eq("source_id", sourceId);
        await serviceClient.from("knowledge_sources").update({
          title: finalTitle, status: isSinglePart ? "pending" : "uploading",
          raw_content: cleanContent.substring(0, 50000),
          last_crawled_at: new Date().toISOString(), source_type: finalType,
        }).eq("id", sourceId);
      } else {
        const { data: newSource, error } = await serviceClient.from("knowledge_sources").insert({
          url: finalUrl, title: finalTitle, status: isSinglePart ? "pending" : "uploading",
          source_type: finalType, raw_content: cleanContent.substring(0, 50000),
          last_crawled_at: new Date().toISOString(),
        }).select("id").single();
        if (error) throw error;
        sourceId = newSource.id;
      }

      let successCount = 0;
      for (let i = 0; i < chunks.length; i++) {
        const chunkMeta: Record<string, unknown> = {
          url: finalUrl, title: finalTitle, chunk_index: i, total_chunks: chunks.length,
        };
        // Merge file metadata (page_start, page_end, total_pages, etc.)
        if (fileMeta) Object.assign(chunkMeta, fileMeta);

        const { error } = await serviceClient.from("knowledge_chunks").insert({
          source_id: sourceId, content: chunks[i], chunk_index: i,
          metadata: chunkMeta,
        });
        if (!error) successCount++;
        else console.error(`Chunk ${i} error:`, error);
      }

      if (isSinglePart) {
        await serviceClient.from("knowledge_sources")
          .update({ status: successCount > 0 ? "active" : "error" }).eq("id", sourceId);
      } else {
        // Multi-part: mark active immediately since each part is independent
        await serviceClient.from("knowledge_sources")
          .update({ status: successCount > 0 ? "active" : "error" }).eq("id", sourceId);
      }

      return jsonResponse({ success: true, source_id: sourceId, title: finalTitle, chunks_total: chunks.length, chunks_indexed: successCount });
    }

    // LIST CHUNKS for a source
    if (action === "list-chunks") {
      const { source_id } = body;
      if (!source_id) return jsonResponse({ error: "source_id required" }, 400);
      const { data: chunks, error } = await serviceClient
        .from("knowledge_chunks").select("id, content, chunk_index, metadata")
        .eq("source_id", source_id).order("chunk_index");
      if (error) throw error;
      return jsonResponse({ success: true, chunks: chunks || [] });
    }

    // UPDATE CHUNK content
    if (action === "update-chunk") {
      const { chunk_id, content } = body;
      if (!chunk_id || !content) return jsonResponse({ error: "chunk_id and content required" }, 400);
      const { error } = await serviceClient.from("knowledge_chunks").update({ content }).eq("id", chunk_id);
      if (error) throw error;
      return jsonResponse({ success: true });
    }

    // FORMAT SINGLE CHUNK with AI
    if (action === "format-chunk-single") {
      const { chunk_id } = body;
      if (!chunk_id) return jsonResponse({ error: "chunk_id required" }, 400);

      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
      if (!LOVABLE_API_KEY) return jsonResponse({ error: "AI not configured" }, 500);

      const { data: chunk, error: chunkErr } = await serviceClient
        .from("knowledge_chunks").select("id, content").eq("id", chunk_id).single();
      if (chunkErr || !chunk) return jsonResponse({ error: "Chunk not found" }, 404);

      const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash-lite",
          messages: [
            {
              role: "system",
              content: "Você é um formatador de texto conservador. Sua tarefa é APENAS melhorar a formatação do texto sem alterar nenhum conteúdo factual.\n\nRegras estritas:\n- NÃO adicionar, remover ou alterar fatos, números, nomes ou informações\n- NÃO resumir ou reescrever o conteúdo\n- APENAS corrigir: quebras de linha, espaçamento, bullets/listas, cabeçalhos, pontuação óbvia\n- Manter o texto original se já estiver bem formatado\n- Retornar SOMENTE o texto formatado, sem explicações"
            },
            { role: "user", content: `Formate este texto preservando todo o conteúdo:\n\n${chunk.content}` }
          ],
        }),
      });

      if (!aiResp.ok) return jsonResponse({ error: `AI error: ${aiResp.status}` }, 500);
      const aiData = await aiResp.json();
      const formattedText = aiData.choices?.[0]?.message?.content?.trim();
      if (!formattedText) return jsonResponse({ error: "AI returned empty response" }, 500);

      const lengthRatio = formattedText.length / chunk.content.length;
      if (lengthRatio < 0.7 || lengthRatio > 1.3) {
        return jsonResponse({ success: false, error: `Formatação rejeitada: alteração de ${Math.round((1 - lengthRatio) * -100)}% no tamanho`, original_length: chunk.content.length, formatted_length: formattedText.length });
      }

      await serviceClient.from("knowledge_chunks").update({ content: formattedText }).eq("id", chunk_id);
      return jsonResponse({ success: true, formatted_content: formattedText });
    }

    // FORMAT CHUNKS (AI-based conservative formatting cleanup)
    if (action === "format-chunks") {
      const { source_id } = body;
      if (!source_id) return jsonResponse({ error: "source_id required" }, 400);

      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
      if (!LOVABLE_API_KEY) return jsonResponse({ error: "AI not configured" }, 500);

      const { data: chunks, error: chunksError } = await serviceClient
        .from("knowledge_chunks").select("id, content, chunk_index")
        .eq("source_id", source_id).order("chunk_index");
      if (chunksError) throw chunksError;
      if (!chunks || chunks.length === 0) return jsonResponse({ error: "No chunks found" }, 404);

      let formatted = 0;
      for (const chunk of chunks) {
        try {
          const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "google/gemini-2.5-flash-lite",
              messages: [
                {
                  role: "system",
                  content: `Você é um formatador de texto conservador. Sua tarefa é APENAS melhorar a formatação do texto sem alterar nenhum conteúdo factual.

Regras estritas:
- NÃO adicionar, remover ou alterar fatos, números, nomes ou informações
- NÃO resumir ou reescrever o conteúdo
- APENAS corrigir: quebras de linha, espaçamento, bullets/listas, cabeçalhos, pontuação óbvia
- Manter o texto original se já estiver bem formatado
- Retornar SOMENTE o texto formatado, sem explicações`
                },
                { role: "user", content: `Formate este texto preservando todo o conteúdo:\n\n${chunk.content}` }
              ],
            }),
          });

          if (!aiResp.ok) {
            console.error(`AI format error for chunk ${chunk.chunk_index}: ${aiResp.status}`);
            continue;
          }

          const aiData = await aiResp.json();
          const formattedText = aiData.choices?.[0]?.message?.content?.trim();
          if (!formattedText) continue;

          // Safety check: if the formatted text is too different (>30% length change), keep original
          const lengthRatio = formattedText.length / chunk.content.length;
          if (lengthRatio < 0.7 || lengthRatio > 1.3) {
            console.log(`Chunk ${chunk.chunk_index}: skipped (length ratio ${lengthRatio.toFixed(2)})`);
            continue;
          }

          await serviceClient.from("knowledge_chunks")
            .update({ content: formattedText }).eq("id", chunk.id);
          formatted++;
        } catch (e) {
          console.error(`Format chunk ${chunk.chunk_index} error:`, e);
        }
      }

      return jsonResponse({ success: true, total_chunks: chunks.length, formatted });
    }

    // FILE INDEX APPEND (adds chunks to existing source)
    if (action === "file-index-append") {
      const { source_id, content, is_last } = body;
      if (!source_id) return jsonResponse({ error: "source_id required" }, 400);
      if (!content || content.trim().length === 0) return jsonResponse({ error: "content required" }, 400);
      console.log(`File index append: source=${source_id}, ${content.length} chars, is_last=${is_last}`);
      const result = await appendContent(serviceClient, source_id, content, !!is_last);
      return jsonResponse({ success: true, ...result });
    }

    // SCRAPE URL (default — public pages only)
    const { url, title } = body;
    if (!url || typeof url !== "string") return jsonResponse({ error: "url is required" }, 400);

    console.log("Scraping URL:", url);
    const pageResp = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
      redirect: "follow",
    });
    if (!pageResp.ok) return jsonResponse({ error: `Failed to fetch URL: ${pageResp.status}` }, 400);

    const html = await pageResp.text();
    const text = stripHtmlToText(html);
    if (!text || text.length < 50) return jsonResponse({ error: "Page has insufficient content" }, 400);

    const pageTitle = title || html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || url;
    console.log(`Extracted ${text.length} chars, title: "${pageTitle}"`);

    const result = await indexContent(serviceClient, text, pageTitle, url, "compass_docs");
    return jsonResponse({ success: true, ...result });

  } catch (error: any) {
    if (error.status) return jsonResponse({ error: error.message }, error.status);
    console.error("scrape-docs error:", error);
    return jsonResponse({ error: error instanceof Error ? error.message : "Unknown error" }, 500);
  }
});
