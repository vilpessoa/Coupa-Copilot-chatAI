import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function makeMaskedHint(value: string, isSensitive: boolean): string {
  if (!value) return "";
  if (!isSensitive) return value;
  if (value.length <= 4) return "••••";
  return "••••••••" + value.slice(-4);
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseAuth.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub as string;

    // Admin check via service role
    const supabase = createClient(supabaseUrl, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { action } = body;

    // ─── LIST: return masked hints only ───
    if (action === "list") {
      const { data, error } = await supabase
        .from("api_credentials")
        .select("id, key_name, masked_hint, is_sensitive, updated_at")
        .order("key_name");

      if (error) throw error;
      return new Response(JSON.stringify({ credentials: data }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── SAVE: update a credential value ───
    if (action === "save") {
      const { key_name, value } = body;

      // Validate
      const ALLOWED_KEYS = ["COUPA_INSTANCE_URL", "COUPA_CLIENT_ID", "COUPA_CLIENT_SECRET"];
      if (!ALLOWED_KEYS.includes(key_name)) {
        return new Response(JSON.stringify({ error: "Invalid key_name" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (!value || typeof value !== "string" || !value.trim()) {
        return new Response(JSON.stringify({ error: "Value cannot be empty" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const trimmed = value.trim();

      // URL validation
      if (key_name === "COUPA_INSTANCE_URL" && !trimmed.startsWith("https://")) {
        return new Response(JSON.stringify({ error: "URL must start with https://" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Get is_sensitive flag
      const { data: existing } = await supabase
        .from("api_credentials")
        .select("is_sensitive")
        .eq("key_name", key_name)
        .single();

      const isSensitive = existing?.is_sensitive ?? true;
      const maskedHint = makeMaskedHint(trimmed, isSensitive);

      const { error } = await supabase
        .from("api_credentials")
        .update({ value: trimmed, masked_hint: maskedHint, updated_at: new Date().toISOString() })
        .eq("key_name", key_name);

      if (error) throw error;

      return new Response(JSON.stringify({ success: true, masked_hint: maskedHint }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── INIT: populate from env vars (one-time migration) ───
    if (action === "init") {
      const envMap: Record<string, boolean> = {
        COUPA_INSTANCE_URL: false,
        COUPA_CLIENT_ID: true,
        COUPA_CLIENT_SECRET: true,
      };

      let updated = 0;
      for (const [keyName, isSensitive] of Object.entries(envMap)) {
        const envValue = Deno.env.get(keyName) || "";
        if (!envValue) continue;

        const { data: existing } = await supabase
          .from("api_credentials")
          .select("value")
          .eq("key_name", keyName)
          .single();

        // Only populate if currently empty
        if (existing && !existing.value) {
          const maskedHint = makeMaskedHint(envValue, isSensitive);
          await supabase
            .from("api_credentials")
            .update({ value: envValue, masked_hint: maskedHint, updated_at: new Date().toISOString() })
            .eq("key_name", keyName);
          updated++;
        }
      }

      return new Response(JSON.stringify({ success: true, updated }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("manage-credentials error:", e);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
